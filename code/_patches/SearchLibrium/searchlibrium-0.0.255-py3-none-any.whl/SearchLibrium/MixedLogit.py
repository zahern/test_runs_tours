from typing import Optional
import itertools
import os
import numpy as np
import scipy.stats as ss
from scipy.optimize import minimize, differential_evolution
from typing import Callable, Tuple
import inspect
import weakref
from collections import OrderedDict

# Set env var SL_QUIET=1 to suppress per-fit progress/debug prints (useful when
# the model is fit hundreds of times inside a metaheuristic search, which
# otherwise floods the log).
_SL_QUIET = bool(os.environ.get("SL_QUIET"))


# files
try:
    from RandomP import RandomParameters
    from Halton import HaltonSequence, Draws

    from _choice_model import  DiscreteChoiceModel
    from _device import device as dev
    from boxcox_functions import boxcox_param_deriv_mixed, boxcox_transformation_mixed, truncate, truncate_lower
    from multinomial_logit import MultinomialLogit
except ImportError:
    from .RandomP import RandomParameters
    from .Halton import HaltonSequence, Draws

    from ._choice_model import DiscreteChoiceModel
    from ._device import device as dev
    from .boxcox_functions import boxcox_param_deriv_mixed, boxcox_transformation_mixed, truncate, truncate_lower
    from .multinomial_logit import MultinomialLogit


''' ---------------------------------------------------------- '''
''' CONSTANTS - BOUNDS ON NUMERICAL VALUES                     '''
''' ---------------------------------------------------------- '''
max_exp_val = 700
max_comp_val, min_comp_val = 1e+20, 1e-200 # or use float('inf')
infinity = float('inf')


def _mxl_random_start(target_mean, distribution_name, relative_sd=0.1,
                      sd_floor=0.05, mean_floor=1e-3,
                      align_sign=True):
    """Return a mean/spread start in the model's parameterization."""
    target = float(target_mean) if np.isfinite(target_mean) else 0.0
    relative_sd = max(float(relative_sd), 0.0)
    sd_floor = max(float(sd_floor), 1e-8)
    mean_floor = max(float(mean_floor), 1e-12)
    magnitude = max(abs(target), mean_floor)
    target_sd = max(magnitude * relative_sd, sd_floor)
    effective = str(distribution_name)

    if align_sign:
        if effective == "ln" and target < 0.0:
            effective = "nln"
        elif effective == "nln" and target > 0.0:
            effective = "ln"

    if effective in {"ln", "nln"}:
        latent_sd = float(np.sqrt(np.log1p((target_sd / magnitude) ** 2)))
        latent_mean = float(np.log(magnitude) - 0.5 * latent_sd ** 2)
        return latent_mean, latent_sd, effective
    if effective == "u":
        return target, float(target_sd * np.sqrt(3.0)), effective
    if effective == "t":
        return target, float(target_sd * np.sqrt(6.0)), effective
    return target, target_sd, effective


def _mxl_variance_start(target_means, distributions, correlation_length,
                        relative_sd=0.1, sd_floor=0.05, mean_floor=1e-3,
                        align_sign=True):
    """Build diagonal Cholesky/independent spread starts for random means."""
    means = []
    spreads = []
    effective = []
    for target, distribution_name in zip(target_means, distributions):
        mean, spread, dist = _mxl_random_start(
            target, distribution_name, relative_sd=relative_sd,
            sd_floor=sd_floor, mean_floor=mean_floor,
            align_sign=align_sign)
        means.append(mean)
        spreads.append(spread)
        effective.append(dist)

    corr_len = max(0, min(int(correlation_length), len(spreads)))
    cholesky_size = corr_len * (corr_len + 1) // 2
    variance_start = np.zeros(cholesky_size + len(spreads) - corr_len,
                              dtype=float)
    for index in range(corr_len):
        variance_start[index * (index + 1) // 2 + index] = spreads[index]
    if corr_len < len(spreads):
        variance_start[cholesky_size:] = spreads[corr_len:]
    return np.asarray(means, dtype=float), variance_start, effective


def _panel_weighted_shares(prob_np, panel_info):
    """Aggregate (N, P, J) per-situation shares, ignoring zero-padded panel slots.

    ``balance_panels`` pads short panels with zeros; a plain mean over the P
    axis then deflates observed shares by (avg valid P / max P) and smooths
    predicted shares toward uniform. Weighting by ``panel_info`` restricts
    both averages to valid positions. Returns (per-person shares (N, J),
    overall shares (J,)). Falls back to plain means when shapes mismatch.
    """
    try:
        a = np.asarray(prob_np, dtype=float)
        w = np.asarray(panel_info, dtype=float)
        if (a.ndim == 3 and w.ndim == 2 and w.shape == a.shape[:2]
                and float(w.sum()) > 0):
            w3 = w[..., None]
            ind = (a * w3).sum(axis=1) / np.maximum(
                w.sum(axis=1, keepdims=True), 1e-300)
            return ind, (a * w3).sum(axis=(0, 1)) / float(w.sum())
    except Exception:
        pass
    ind = np.mean(a, axis=1)
    return ind, np.mean(ind, axis=0)

class MixedLogit(DiscreteChoiceModel):
    def __init__(self, halton_opts=None, distributions=['n', 'ln', 'nln', 't', 'tn', 'u'], _jax=None):
        super().__init__(_jax)
        self.descr = "MXL"
        self.halton_opts = halton_opts
        self.draws_generator = Draws(k=len(distributions), halton_opts=halton_opts, rvdist=distributions)
        self.random_parameters = RandomParameters(distributions or [])
        self.softmax_r = True
        self.reg_penalty = 0.001  # tiny L2 ridge — prevents singular Hessians

    def generate_draws(self, sample_size, n_draws, halton=True, chol_mat=None):
        """Generate random or Halton draws via fn_generate_draws, apply distributions, return tuple."""
        args = (sample_size, n_draws)
        draws, drawstrans = self.fn_generate_draws(*args)

        # Filter out any False values from the lists
        self.rvdist = [item for item in self.rvdist if item is not False]
        self.rvtransdist = [item for item in self.rvtransdist if item is not False]
        draws = self.evaluate_distribution(self.rvdist, draws)  # Evaluate distributions
        draws = np.atleast_3d(draws)
        drawstrans = self.evaluate_distribution(self.rvtransdist, drawstrans)  # Evaluate distributions
        drawstrans = np.atleast_3d(drawstrans)
        return draws, drawstrans

    def generate_halton_draws(self, sample_size, n_draws, n_vars):
        """Generate Halton draws for multiple random variables using different primes."""
        if n_vars == 0:
            return []
        primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47,
                  53, 59, 61, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109,
                  113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173,
                  179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233,
                  239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293,
                  307, 311]

        from SearchLibrium.Halton import _halton_seq_traditional as halton_seq
        draws = [halton_seq(sample_size * n_draws, prime=primes[i % len(primes)],
                 drop=100, shuffled=False).reshape(sample_size, n_draws) for i in range(n_vars)]
        draws = np.stack(draws, axis=1)
        return draws

    def evaluate_distribution(self, distr, values):
        """Transform uniform [0,1] draws to specified distributions."""
        if isinstance(values, list) or values.size == 0:
            return values
        for k, distr_k in enumerate(distr):
            if distr_k in ['n', 'ln', 'nln', 'tn']:
                values[:, k, :] = ss.norm.ppf(values[:, k, :])
            elif distr_k == 't':
                values_k = values[:, k, :]
                values[:, k, :] = (np.sqrt(2 * values_k) - 1) * (values_k <= .5) + \
                                  (1 - np.sqrt(2 * (1 - values_k))) * (values_k > .5)
            elif distr_k == 'u':
                values[:, k, :] = 2 * values[:, k, :] - 1
        return values

    def generate_draws_halton(self, sample_size, n_draws):
        """Generate Halton/Sobol draws (respects halton_opts configuration)."""
        # Use the Halton class from draws_generator which was configured with halton_opts
        # This ensures Sobol configuration (use_sobol=True/False) is properly applied
        draws, drawstrans = [], []

        if hasattr(self, 'draws_generator') and self.draws_generator is not None:
            # Use configured Halton/Sobol generator
            halton_gen = self.draws_generator.halton  # This respects use_sobol setting

            if self.randvars:
                n_vars_r = int(np.sum(self.rvidx))
                if n_vars_r > 0:
                    draws = halton_gen.generate_draws(sample_size, n_draws, n_vars_r)

            if self.randtransvars:
                n_vars_rt = int(np.sum(self.rvtransidx))
                if n_vars_rt > 0:
                    drawstrans = halton_gen.generate_draws(sample_size, n_draws, n_vars_rt)
        else:
            # Fallback to direct Halton generation (default behavior)
            if self.randvars:
                draws = self.generate_halton_draws(sample_size, n_draws, np.sum(self.rvidx))
            if self.randtransvars:
                drawstrans = self.generate_halton_draws(sample_size, n_draws, np.sum(self.rvtransidx))

        return draws, drawstrans

    def generate_draws_random(self, sample_size, n_draws):
        """Generate random uniform draws, returns (draws, drawstrans) tuple with raw uniform values."""
        draws, drawstrans = [], []
        if self.randvars:
            draws = self.get_random_draws(sample_size, n_draws, np.sum(self.rvidx))
        if self.randtransvars:
            drawstrans = self.get_random_draws(sample_size, n_draws, np.sum(self.rvtransidx))
        return draws, drawstrans

    def get_random_draws(self, sample_size, n_draws, n_vars):
        """Generate random uniform draws between 0 and 1."""
        if n_vars == 0:
            return []
        return np.random.uniform(size=(sample_size, n_vars, n_draws))

    def setup(self, X, y, varnames=None, alts=None, isvars=None, transvars=None,
              transformation="boxcox", ids=None, weights=None, avail=None,
              randvars=None, panels=None, base_alt=None, fit_intercept=False,
              init_coeff=None, maxiter=1000, correlated_vars=None,
              n_draws=1000, halton=True, minimise_func=None,
              batch_size=None, halton_opts=None, ftol=1e-12,
              gtol=1e-6, return_hess=True, return_grad=True, method="slsqp",
              save_fitted_params=True, mnl_init=True,
              de_init=False, de_popsize=4, de_maxiter=3, de_tol=0.5,
              de_polish=False, l1_penalty=0.0, reg_penalty=0.001, sd_penalty=0.0,
              engine=None, asc_share_init=True, random_sd_start=0.1,
              random_sd_floor=0.05, align_random_distributions=True):
        # {
        self.fit_intercept = fit_intercept
        # L2 ridge regularisation strength (default ON). Keeps the Hessian
        # diagonally dominant / non-singular under near-constant covariates and
        # simulation noise. Applied in both the JAX objective and the NumPy
        # get_loglik_gradient path. Set reg_penalty=0.0 to disable.
        self.reg_penalty = float(reg_penalty)
        # Extra L2 penalty applied specifically to the random-coefficient standard
        # deviations (Br_w). Shrinks weakly-identified / runaway SDs toward zero.
        self.sd_penalty = float(sd_penalty)
        self.random_sd_start = float(random_sd_start)
        self.random_sd_floor = float(random_sd_floor)
        self.align_random_distributions = bool(align_random_distributions)
        # Seed alternative-specific constants from observed shares
        # (alpha_j = log(s_j / s_base); detected as exact alternative
        # dummies, no naming convention needed). Disable with
        # asc_share_init=False.
        self.asc_share_init = bool(asc_share_init)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # RECAST AS NUMPY NDARRAY
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        X, y, varnames, alts, isvars, transvars, ids, weights, \
            panels, avail = self.set_asarray(X, y, varnames, alts,
                                             isvars, transvars, ids, weights, panels, avail)

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # CHECK FOR MISTAKES IN DATA
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        self.validate_inputs(X, y, alts, varnames)
        # REMOVED:, isvars, ids, weights, panels, base_alt, fit_intercept, maxiter)

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # RECORD PARAMETERS AS MEMBER VARIABLES
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        self.pre_process(alts, varnames, isvars, transvars, base_alt, fit_intercept, transformation,
                         maxiter, panels, correlated_vars, randvars)
        self.X_original = X  # Copy of X as input to use in mnl_init
        self.y_original = y  # Copy of y as input
        self.X, self.y = X, y
        self.transformation = transformation
        self.ids = ids
        self.weights, self.avail = weights, avail
        self.init_coeff = init_coeff
        self.ftol, self.gtol = ftol, gtol
        self.return_grad, self.return_hess = return_grad, return_hess
        self.fit_intercept = fit_intercept


        self.init_coeff = init_coeff
        self.halton, self.halton_opts = halton, halton_opts
        self.minimise_func = minimise_func
        # Optional execution engine for fit(); 'numba' selects the njit
        # likelihood + L-BFGS-B via numba_engine (silent fallback to
        # SciPy/JAX when the spec is outside the supported base case).
        # An explicit kwarg wins over a pre-set attribute.
        self.engine = engine if engine is not None else getattr(self, 'engine', None)
        self.save_fitted_params = save_fitted_params
        self.mnl_init = mnl_init
        self.de_init = de_init
        self.de_popsize = de_popsize
        self.de_maxiter = de_maxiter
        self.de_tol = de_tol
        self.de_polish = de_polish
        self.total_fun_eval = 0
        self.method = method.lower() if hasattr(method, 'lower') else method
        self.l1_penalty = float(l1_penalty)
        self.jac = self.return_grad  # scipy optimize parameter
        self.n_draws = n_draws
        self.batch_size = min(n_draws, batch_size) if batch_size is not None else n_draws
        self.halton_opts = halton_opts  # Store halton options for draw generation

        # CRITICAL FIX: Recreate draws_generator with proper halton_opts AND rvdist
        # The __init__ creates it with halton_opts=None, but setup() gets the actual options
        # Must recreate here to ensure Sobol/Halton configuration is properly applied
        # AND to pass the correct random variable distributions (e.g., 'ln' for lognormal)
        # IMPORTANT: Order rvdist by varnames order, not dictionary order
        rvdist = [randvars[var] for var in varnames if var in randvars] if randvars else []
        self.draws_generator = Draws(k=len(randvars or {}), halton_opts=halton_opts, rvdist=rvdist)

        self.randvarsdict = randvars  # random variables not transformed


        self.randvars = list(set(self.randvars) - set(transvars))  # Exclude elements in transvars

        #  Random variables that are transformed
        self.randtransvars = [x for x in transvars if x in set(randvars) and x not in set(self.randvars)]
        self.fixedtransvars = [x for x in transvars if x not in set(self.randtransvars)]

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Divide the variables in varnames into fixed, fixed transformed,
        # random, random transformed by getting 4 index arrays
        # also for random and random transformed save the distributions
        # in a separate array
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        self.fxidx, self.fxtransidx = [], []
        self.rvidx, self.rvdist = [], []
        self.rvtransidx, self.rvtransdist = [], []

        # Heterogeneity tracking: for each random variable, track covariates for mean/var heterogeneity
        self.rv_het_mean_vars = []   # list of lists: covariates for mean heterogeneity per random var
        self.rv_het_var_vars = []    # list of lists: covariates for variance heterogeneity per random var
        self.rv_het_corr = []        # list of bool: whether this RV has correlated heterogeneity
        self.rvtrans_het_mean_vars = []
        self.rvtrans_het_var_vars = []
        self.rvtrans_het_corr = []   # list of bool: whether this RV has correlated heterogeneity

        for var in self.varnames:
            # {
            if isinstance(randvars, dict) and var in randvars:
                # {
                self.fxidx.append(False)
                self.fxtransidx.append(False)

                # Parse heterogeneity specification
                rv_spec = randvars[var]
                if isinstance(rv_spec, dict):
                    dist = rv_spec.get('dist', 'n')
                    het_mean = rv_spec.get('mean_het', [])
                    het_var = rv_spec.get('var_het', [])
                    het_corr = rv_spec.get('het_corr', False)  # Correlated heterogeneity flag
                else:
                    dist = rv_spec
                    het_mean = []
                    het_var = []
                    het_corr = False

                if var in self.randvars:  # {
                    self.rvidx.append(True)
                    self.rvdist.append(dist)
                    self.rvtransidx.append(False)
                    self.rv_het_mean_vars.append(het_mean)
                    self.rv_het_var_vars.append(het_var)
                    self.rv_het_corr.append(het_corr)
                # }
                else:  # {
                    self.rvidx.append(False)
                    self.rvtransidx.append(True)
                    self.rvtransdist.append(dist)
                    self.rvtrans_het_mean_vars.append(het_mean)
                    self.rvtrans_het_var_vars.append(het_var)
                    self.rvtrans_het_corr.append(het_corr)
                # }
            # }
            else:
                # {
                # Set all flags to False and prepare for 'transvars' check
                self.rvidx.append(False)
                self.rvtransidx.append(False)
                self.rvdist.append(False)
                self.rvtransdist.append(False)

                if var in transvars:
                    # {
                    self.fxtransidx.append(True)
                    self.fxidx.append(False)
                # }
                else:
                    # {
                    self.fxtransidx.append(False)
                    self.fxidx.append(True)
                # }
            # }
        # }

        # Convert to NUMPY array
        self.rvidx, self.rvtransidx = np.array(self.rvidx), np.array(self.rvtransidx)
        self.fxidx, self.fxtransidx = np.array(self.fxidx), np.array(self.fxtransidx)

        # ~~~~~~~~~~~~~~~~~~~~~
        # SETUP DESIGN MATRIX
        # ~~~~~~~~~~~~~~~~~~~~~

        self.X, self.y, self.panels = self.arrange_long_format(self.X, self.y, ids, alts, panels)
        self.X, self.Xnames = self.setup_design_matrix(self.X)  # NOTE: self.Xnames is saved and used in LatentMixed...
        self.model_specific_validations(randvars, self.Xnames)
        self.J, self.K = self.X.shape[1], self.X.shape[2]

        # NOTE: Do NOT rebuild index arrays - searchlogit works with the original order
        # and the variable reordering in setup_design_matrix is intentional.
        # Rebuilding index arrays actually makes results worse (gap 50pt → 18pt without rebuild)
        # self._rebuild_index_arrays_for_reordered_varnames()

        if self.transformation == "boxcox":  # {
            self.trans_func = boxcox_transformation_mixed
            self.transform_deriv = boxcox_param_deriv_mixed
        # }

        if panels is not None:  # {
            self.X, self.y, avail, self.panel_info = self.balance_panels(self.X, self.y, avail,
                                                                         self.panels)  # CHECK. "self.panels" needed?
            self.N, self.P = self.panel_info.shape
        # }
        else:  # {
            self.N, self.P = self.X.shape[0], 1
            self.panel_info = np.ones((self.N, 1))
        # }

        # ~~~~~~~~~~~~~~~~~~~~~~~~
        # RESHAPE TO 4 DIMENSIONS
        # ~~~~~~~~~~~~~~~~~~~~~~~~

        self.X = self.X.reshape((self.N, self.P, self.J, self.K))
        self.y = self.y.reshape((self.N, self.P, self.J, 1))

        #  RESHAPE WEIGHTS (using panel data if necessary)
        self.weights = self.reshape_weights(weights, self.panels) if weights is not None else weights
        self.avail = self.reshape_avail(avail, self.panels) if avail is not None else avail
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # COMPUTE obs_prob over valid panel positions only (balance_panels
        # pads short panels with zeros; an unweighted mean over P deflates
        # shares by avg-valid-P / max-P, e.g. sums to ~0.18 instead of 1).
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        means_1 = np.mean(self.y, axis=3)  # means_1[n,p,j] = avg(y[n,p,j,:])
        _, self.obs_prob = _panel_weighted_shares(
            means_1, getattr(self, 'panel_info', None))
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # DEFINE MEMBER FUNCTIONS TO APPLY
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        from typing import Callable, Tuple
        Args, Result = Tuple[int, int], Tuple[np.ndarray, np.ndarray]
        DrawsFunction = Callable[[Args], Result]
        self.fn_generate_draws: DrawsFunction = self.generate_draws_halton if halton else self.generate_draws_random

        # Build heterogeneity covariate tracking after design matrix is set up
        self._build_heterogeneity_tracking()
    # }


    def _build_heterogeneity_tracking(self):
        """Build tracking for heterogeneity in means and variances.
        
        Maps heterogeneity covariates to design matrix columns and tracks which
        random variable each heterogeneity term belongs to.
        """
        # Map from variable name to its DESIGN-MATRIX column index. The design
        # matrix is built as dstack(Xis, Xas): for each individual-specific
        # variable, one column per non-base alternative, followed by
        # ``asvars_construct_matrix`` (all non-isvar candidate columns in
        # varnames order). ``Xnames`` is the *coefficient* name vector (which
        # also lists sd./chol./lambda. names), so it must NOT be used as a
        # column map — doing so mis-picked covariates whenever isvars expanded.
        _isvar_block = ["{}.{}".format(iv, j) for iv in self.isvars
                        for j in self.alts if j != self.base_alt]
        _asvar_block = [str(v) for v in
                        getattr(self, 'asvars_construct_matrix', [])]
        xname_to_col = {}
        for _i, _name in enumerate(_isvar_block + _asvar_block):
            xname_to_col.setdefault(str(_name), _i)

        def _col_of(name):
            """Design column of *name*, expanding a random isvar to its first
            alternative-specific column when necessary."""
            name = str(name)
            if name in xname_to_col:
                return xname_to_col[name]
            for _n, _i in xname_to_col.items():
                if _n.startswith(name + "."):
                    return _i
            return -1

        # Positions (within the Br / Br_b column order) of the correlated and
        # independent random coefficients. The covariance-block gradient and
        # the variance start must not assume the correlated variables are the
        # first correlationLength coefficients (partial/arbitrary correlated
        # sets are allowed).
        rv_names_ordered = [str(v) for v in self.varnames
                            if str(v) in set(str(x) for x in (self.randvars or []))]
        _corr = getattr(self, 'correlated_vars', None)
        if _corr is True:
            _corr_set = set(rv_names_ordered)
        elif isinstance(_corr, (list, tuple, set)):
            _corr_set = set(str(x) for x in _corr)
        else:
            _corr_set = set()
        self.rv_corr_local = [i for i, v in enumerate(rv_names_ordered)
                              if v in _corr_set]
        self.rv_indep_local = [i for i in range(len(rv_names_ordered))
                               if i not in self.rv_corr_local]
        
        # For non-transformed random variables
        self.het_mean_rv_names = []
        self.het_var_rv_names = []
        self.het_mean_rv_cols = []  # column index in design matrix for each heterogeneity covariate
        self.het_var_rv_cols = []
        self.het_mean_rv_idx = []   # which random variable (0..Kr-1) each heterogeneity term belongs to
        self.het_var_rv_idx = []
        
        # Map from random variable index (0..Kr-1) to design matrix column index
        self.rv_col_idx = []
        
        # setup_design_matrix expands/reorders the design columns and updates
        # rvidx to that layout, so rvidx must NOT be indexed by the original
        # varnames position here. Iterate the random variables by name in
        # varnames order (which is the Br column order).
        randset = set(str(x) for x in (self.randvars or []))
        rv_count = 0
        for var in self.varnames:
            if str(var) in randset:
                self.rv_col_idx.append(_col_of(var))
                het_mean_vars = self.rv_het_mean_vars[rv_count] if rv_count < len(self.rv_het_mean_vars) else []
                het_var_vars = self.rv_het_var_vars[rv_count] if rv_count < len(self.rv_het_var_vars) else []
                
                for hvar in het_mean_vars:
                    if hvar in xname_to_col:
                        self.het_mean_rv_names.append(f"{var}_het_mean_{hvar}")
                        self.het_mean_rv_cols.append(xname_to_col[hvar])
                        self.het_mean_rv_idx.append(rv_count)
                
                for hvar in het_var_vars:
                    if hvar in xname_to_col:
                        self.het_var_rv_names.append(f"{var}_het_var_{hvar}")
                        self.het_var_rv_cols.append(xname_to_col[hvar])
                        self.het_var_rv_idx.append(rv_count)
                
                rv_count += 1
        
        # For transformed random variables
        self.het_mean_rvtrans_names = []
        self.het_var_rvtrans_names = []
        self.het_mean_rvtrans_cols = []
        self.het_var_rvtrans_cols = []
        self.het_mean_rvtrans_idx = []
        self.het_var_rvtrans_idx = []
        
        # Map from transformed random variable index (0..Krtrans-1) to design matrix column index
        self.rvtrans_col_idx = []
        
        # Track correlated heterogeneity groups
        self.het_corr_groups = []  # List of lists of RV indices that share correlated heterogeneity
        self.het_corr_group_id = []  # Group ID for each RV (-1 if not in a group)
        
        rvtransset = set(str(x) for x in (self.randtransvars or []))
        rvtrans_count = 0
        for var in self.varnames:
            if str(var) in rvtransset:
                self.rvtrans_col_idx.append(_col_of(var))
                het_mean_vars = self.rvtrans_het_mean_vars[rvtrans_count] if rvtrans_count < len(self.rvtrans_het_mean_vars) else []
                het_var_vars = self.rvtrans_het_var_vars[rvtrans_count] if rvtrans_count < len(self.rvtrans_het_var_vars) else []
                
                for hvar in het_mean_vars:
                    if hvar in xname_to_col:
                        self.het_mean_rvtrans_names.append(f"{var}_het_mean_{hvar}")
                        self.het_mean_rvtrans_cols.append(xname_to_col[hvar])
                        self.het_mean_rvtrans_idx.append(rvtrans_count)
                
                for hvar in het_var_vars:
                    if hvar in xname_to_col:
                        self.het_var_rvtrans_names.append(f"{var}_het_var_{hvar}")
                        self.het_var_rvtrans_cols.append(xname_to_col[hvar])
                        self.het_var_rvtrans_idx.append(rvtrans_count)
                
                rvtrans_count += 1
        
        # Build correlated heterogeneity groups
        self._build_het_corr_groups()
        
        # Total heterogeneity parameters
        self.K_het_mean_rv = len(self.het_mean_rv_cols)
        self.K_het_var_rv = len(self.het_var_rv_cols)
        self.K_het_mean_rvtrans = len(self.het_mean_rvtrans_cols)
        self.K_het_var_rvtrans = len(self.het_var_rvtrans_cols)

    def _build_het_corr_groups(self):
        """Build groups of random variables with correlated heterogeneity.
        
        Variables with het_corr=True are grouped together. Each group shares
        a covariance matrix for their heterogeneity parameters (γ and τ).
        """
        # Map from RV index to group ID
        self.het_corr_group_id = [-1] * (self.Kr + self.Krtrans)
        self.het_corr_groups = []
        
        current_group = 0
        
        # Check non-transformed RVs. Guard the index: rv_het_corr holds one flag
        # per COMPACT randvar, while Kr counts the EXPANDED random columns (an
        # individual-specific random var expands into J-1 alternative-specific
        # columns), so Kr can exceed len(rv_het_corr). The extra expanded columns
        # default to no correlated heterogeneity (matches the guards at the
        # het-tracking build above). Without this guard, any random-coefficient
        # model with an isvar random raised IndexError in setup.
        for rv_idx in range(self.Kr):
            if rv_idx < len(self.rv_het_corr) and self.rv_het_corr[rv_idx]:
                # Check if this RV should join an existing group or start a new one
                # For now, all correlated RVs form a single group
                if not self.het_corr_groups:
                    self.het_corr_groups.append([])
                self.het_corr_groups[-1].append(('rv', rv_idx))
                self.het_corr_group_id[rv_idx] = current_group
            else:
                self.het_corr_group_id[rv_idx] = -1
        
        # Check transformed RVs (same expanded-vs-compact guard as above).
        for rvtrans_idx in range(self.Krtrans):
            if rvtrans_idx < len(self.rvtrans_het_corr) and self.rvtrans_het_corr[rvtrans_idx]:
                if not self.het_corr_groups:
                    self.het_corr_groups.append([])
                self.het_corr_groups[-1].append(('rvtrans', rvtrans_idx))
                self.het_corr_group_id[self.Kr + rvtrans_idx] = current_group
            else:
                self.het_corr_group_id[self.Kr + rvtrans_idx] = -1
        
        # Count heterogeneity parameters per group
        self.het_corr_group_params = []  # (K_het_mean, K_het_var) per group
        for group in self.het_corr_groups:
            mean_count = 0
            var_count = 0
            for rtype, idx in group:
                if rtype == 'rv':
                    # Count mean het params for this RV
                    for g_idx, rv in enumerate(self.het_mean_rv_idx):
                        if rv == idx:
                            mean_count += 1
                    # Count var het params for this RV
                    for g_idx, rv in enumerate(self.het_var_rv_idx):
                        if rv == idx:
                            var_count += 1
                else:  # rvtrans
                    for g_idx, rv in enumerate(self.het_mean_rvtrans_idx):
                        if rv == idx:
                            mean_count += 1
                    for g_idx, rv in enumerate(self.het_var_rvtrans_idx):
                        if rv == idx:
                            var_count += 1
            self.het_corr_group_params.append((mean_count, var_count))
        
        # Total correlated heterogeneity parameters (covariance matrix elements)
        # For each group: mean_params + var_params parameters, with covariance matrix
        # Upper triangular: n*(n+1)/2 for each of mean and var
        self.K_het_corr_cov = 0
        for mean_count, var_count in self.het_corr_group_params:
            n_mean = mean_count
            n_var = var_count
            self.K_het_corr_cov += n_mean * (n_mean + 1) // 2
            self.K_het_corr_cov += n_var * (n_var + 1) // 2

    ''' ---------------------------------------------------------- '''
    def _rebuild_index_arrays_for_reordered_varnames(self):
        """Rebuild index arrays (rvidx, fxidx, etc.) to match the new variable order from setup_design_matrix.

        setup_design_matrix reorders variables (e.g., putting asvars before randvars), so the index arrays
        built from the original varnames order are now pointing to the wrong columns. This method rebuilds
        them to match Xnames.
        """
        # Map from variable name to its type in the original specification
        vartype_map = {}
        for i, var in enumerate(self.varnames):
            vartype_map[var] = {
                'rvidx': self.rvidx[i],
                'fxidx': self.fxidx[i],
                'rvtransidx': self.rvtransidx[i],
                'fxtransidx': self.fxtransidx[i],
                'rvdist': self.rvdist[i] if i < len(self.rvdist) else None,
                'rvtransdist': self.rvtransdist[i] if i < len(self.rvtransdist) else None,
            }

        # Rebuild index arrays based on the new Xnames order (first K elements only)
        # K elements are the actual data variables (not the parameter names like sd.*)
        new_rvidx = []
        new_fxidx = []
        new_rvtransidx = []
        new_fxtransidx = []
        new_rvdist = []
        new_rvtransdist = []

        for i in range(self.K):
            varname = self.Xnames[i]
            if varname in vartype_map:
                new_rvidx.append(vartype_map[varname]['rvidx'])
                new_fxidx.append(vartype_map[varname]['fxidx'])
                new_rvtransidx.append(vartype_map[varname]['rvtransidx'])
                new_fxtransidx.append(vartype_map[varname]['fxtransidx'])
                new_rvdist.append(vartype_map[varname]['rvdist'])
                new_rvtransdist.append(vartype_map[varname]['rvtransdist'])
            else:
                # Variable not found in original - this shouldn't happen
                new_rvidx.append(False)
                new_fxidx.append(False)
                new_rvtransidx.append(False)
                new_fxtransidx.append(False)
                new_rvdist.append(False)
                new_rvtransdist.append(False)

        # Replace index arrays with reordered versions
        self.rvidx = np.array(new_rvidx, dtype=bool)
        self.fxidx = np.array(new_fxidx, dtype=bool)
        self.rvtransidx = np.array(new_rvtransidx, dtype=bool)
        self.fxtransidx = np.array(new_fxtransidx, dtype=bool)
        self.rvdist = new_rvdist
        self.rvtransdist = new_rvtransdist

    ''' Function.  Fit Mixed Logit model                           '''
    ''' ---------------------------------------------------------- '''

    def _seed_asc_from_shares(self, betas):
        """Overwrite ASC fixed/random-mean starts with log-share ratios.

        For alternative dummies the plain-logit MLE is closed form:
        ``alpha_j = log(s_j / s_base)`` (the BLP-contraction starting
        point; exact for intercepts-only, excellent with covariates).
        ASC columns are detected from the design (columns exactly
        indicating one alternative), so no naming convention is needed.
        Positions without positive shares on both sides keep their
        incoming value. Returns ``(betas, n_seeded)``; never raises.
        """
        try:
            import numpy as _np
            betas = _np.asarray(betas, dtype=float).copy()
            Kf, Kr = int(self.Kf), int(self.Kr)
            if Kf + Kr <= 0:
                return betas, 0
            X = _np.asarray(self.X, dtype=float)
            if X.ndim != 4:
                return betas, 0
            N, P, J = X.shape[0], X.shape[1], X.shape[2]
            if J < 2:
                return betas, 0
            # observed shares over valid choice situations
            y = _np.asarray(self.y)
            if y.ndim == 4:
                y = y[..., 0]
            if y.ndim == 3 and y.shape == (N, P, J):
                _flat = y.reshape(N * P, J)
                cnt = _flat.sum(axis=0)
                den = float((_flat.sum(axis=1) > 0).sum())
            elif y.ndim <= 2:
                idx = y.astype(int).ravel()
                idx = idx[(idx >= 0) & (idx < J)]
                if idx.size == 0:
                    return betas, 0
                cnt = _np.bincount(idx, minlength=J).astype(float)
                den = float(idx.size)
            else:
                return betas, 0
            if not den > 0:
                return betas, 0
            shares = cnt / den
            try:
                base = int(self.base_alt)
            except Exception:
                base = 0
            if not (0 <= base < J) or not shares[base] > 0:
                return betas, 0
            try:
                fx = _np.where(_np.asarray(self.fxidx, dtype=bool))[0]
                rv = _np.where(_np.asarray(self.rvidx, dtype=bool))[0]
            except Exception:
                return betas, 0
            if len(fx) < Kf or len(rv) < Kr:
                return betas, 0
            alt1 = _np.arange(J)
            n_seed = 0
            for f in range(Kf):  # fixed means <-> design column fx[f]
                col = X[:, :, :, int(fx[f])]
                for j in range(J):
                    if bool((col == (alt1 == j)).all()):
                        if shares[j] > 0:
                            betas[f] = float(_np.log(shares[j] / shares[base]))
                            n_seed += 1
                        break
            for k in range(Kr):  # random means <-> design column rv[k]
                col = X[:, :, :, int(rv[k])]
                for j in range(J):
                    if bool((col == (alt1 == j)).all()):
                        if shares[j] > 0:
                            betas[Kf + k] = float(
                                _np.log(shares[j] / shares[base]))
                            n_seed += 1
                        break
            return betas, n_seed
        except Exception:
            try:
                import numpy as _np
                return _np.asarray(betas, dtype=float), 0
            except Exception:
                return betas, 0

    def fit(self):
        # {
        # Generate draws:
        draws, drawstrans = self.generate_draws(self.N, self.n_draws, self.halton)
        self.draws, self.drawstrans = draws, drawstrans  # Record generated values
        # Explicit caller-supplied starts are respected verbatim (no ASC
        # share seeding); the MNL block below may still overwrite
        # self.init_coeff when it runs.
        _explicit_init = self.init_coeff is not None

        # Optional numba engine (first-class; the T4 minimise_func patch is
        # the equivalent for older installs). Resolved here so the JAX fast
        # path below is skipped when numba is selected. An explicit
        # model.engine wins; otherwise the global default (SL_ENGINE env var
        # or numba_engine.set_default_engine) applies.
        try:
            try:
                from numba_engine import effective_engine as _mx_eff_eng
            except ImportError:
                from .numba_engine import effective_engine as _mx_eff_eng
            use_numba = (_mx_eff_eng(self) == 'numba')
        except Exception:
            use_numba = (getattr(self, 'engine', None) == 'numba')

        # 2x Kftrans - mean and lambda, 3x Krtrans - mean, s.d., lambda
        # Kchol, Kbw - relate to random variables, non-transformed
        # Kchol - cholesky matrix, Kbw the s.d. for random vars
        n_coeff = (self.Kf + self.Kr + self.Kchol + self.Kbw
                   + 2 * self.Kftrans + 3 * self.Krtrans
                   + self._n_coeff_extra())

        # Initalise coefficients using a multinomial logit model
        if self.mnl_init and self.init_coeff is None:
            # {
            # Exclude 'intercept' from varnames
            if self.fit_intercept and 'intercept' in self.varnames:
                self.varnames_mnl = self.varnames[self.varnames != 'intercept']
            else:
                self.varnames_mnl = self.varnames



            # else:
            # self.isvars = self.asvars

            def _run_seed_mnl(jax_flag):
                _mnl = MultinomialLogit(_jax=jax_flag)
                _mnl.setup(self.X_original, self.y_original.flatten(),  # Collapse to one dimension!
                           self.varnames, self.alts, self.isvars, transvars=self.transvars,
                           ids=self.ids, weights=self.weights, avail=self.avail,
                           base_alt=self.base_alt, fit_intercept=False)
                _mnl.fit()
                return _mnl

            # Match the model's own backend. The JAX MNL path can return an
            # all-zero / non-converged seed for Box-Cox designs, which then
            # poisons the MXL start (all-zero fixed coefficients and a
            # log-normal mean at log(1e-3)); fall back to the numpy path.
            mnl = _run_seed_mnl(getattr(self, '_jax', False))
            if not bool(getattr(mnl, 'converged', False)) or not np.any(
                    np.asarray(mnl.coeff_est, dtype=float)):
                _mnl_np = _run_seed_mnl(False)
                if np.any(np.asarray(_mnl_np.coeff_est, dtype=float)):
                    mnl = _mnl_np

            # Build init_coeff from MNL estimates, mapping each MXL coefficient to
            # its MNL counterpart BY NAME. Name-based mapping is robust to the
            # per-alternative column expansion used for individual-specific
            # variables / ASCs (e.g. "male.bicycling"), for which the previous
            # index-based mapping (which iterated the compact varnames but indexed
            # the expanded fxidx/rvidx masks) mis-seeded the optimiser. The MNL and
            # MXL share the same expanded design-column names.
            mnl_map = {str(n): v for n, v in zip(mnl.coeff_names, mnl.coeff_est)}
            fixed_names = [str(n) for n in self.Xnames[:self.Kf]]
            rand_mean_names = [str(n) for n in self.Xnames[self.Kf:self.Kf + self.Kr]]
            bf_init = np.array([mnl_map.get(nm, 0.1) for nm in fixed_names], dtype=float)
            mnl_random_means = np.array(
                [mnl_map.get(nm, 0.1) for nm in rand_mean_names], dtype=float)
            random_distributions = [d for d in self.rvdist if d is not False]
            if len(random_distributions) != self.Kr:
                random_distributions = (random_distributions + ['n'] * self.Kr)[:self.Kr]

            # Place the spread starts in the objective's chol/Br_w layout. The
            # correlated variables are not necessarily the first
            # correlationLength random coefficients (partial/arbitrary
            # correlated sets), and _mxl_variance_start assumes they are, so
            # reorder means/distributions by the actual positions first.
            _corr_local = list(getattr(self, 'rv_corr_local', []) or [])
            _indep_local = list(getattr(self, 'rv_indep_local', []) or [])
            if (len(_corr_local) + len(_indep_local) == self.Kr
                    and len(random_distributions) == self.Kr
                    and len(mnl_random_means) == self.Kr
                    and sorted(_corr_local + _indep_local) == list(range(self.Kr))):
                _c_means, _c_var, _c_eff = _mxl_variance_start(
                    [mnl_random_means[i] for i in _corr_local],
                    [random_distributions[i] for i in _corr_local],
                    len(_corr_local),
                    relative_sd=self.random_sd_start,
                    sd_floor=self.random_sd_floor,
                    align_sign=self.align_random_distributions)
                _i_means, _i_var, _i_eff = _mxl_variance_start(
                    [mnl_random_means[i] for i in _indep_local],
                    [random_distributions[i] for i in _indep_local], 0,
                    relative_sd=self.random_sd_start,
                    sd_floor=self.random_sd_floor,
                    align_sign=self.align_random_distributions)
                # Use the LATENT-SPACE aligned means returned by
                # _mxl_variance_start: for log-normal variables the raw MNL
                # coefficient is a utility-space mean and must be converted
                # (latent mean = log(magnitude) - sd^2/2), otherwise the
                # start coefficient is exp() of the wrong value.
                br_b_init = np.asarray(mnl_random_means, dtype=float).copy()
                for _pos, _i in enumerate(_corr_local):
                    br_b_init[_i] = _c_means[_pos]
                for _pos, _i in enumerate(_indep_local):
                    br_b_init[_i] = _i_means[_pos]
                variance_init = np.zeros(self.Kchol + self.Kbw)
                variance_init[:self.Kchol] = np.asarray(_c_var)[:self.Kchol]
                if self.Kbw:
                    variance_init[self.Kchol:] = np.asarray(_i_var)[:self.Kbw]
                effective_dists = [None] * self.Kr
                for _pos, _i in enumerate(_corr_local):
                    effective_dists[_i] = _c_eff[_pos]
                for _pos, _i in enumerate(_indep_local):
                    effective_dists[_i] = _i_eff[_pos]
            else:
                br_b_init, variance_init, effective_dists = _mxl_variance_start(
                    mnl_random_means, random_distributions,
                    self.correlationLength,
                    relative_sd=self.random_sd_start,
                    sd_floor=self.random_sd_floor,
                    align_sign=self.align_random_distributions)
            self.effective_rvdist = list(effective_dists)
            if self.align_random_distributions and effective_dists != random_distributions:
                self.rvdist = list(effective_dists)
                self.draws_generator.rvdist = list(effective_dists)
            if self.Kf == 0:
                bf_init = np.zeros(0)
            if self.Kr == 0:
                br_b_init = np.zeros(0)

            mnl_Kf = int(np.sum(mnl.fxidx))
            mnl_Kftrans = int(np.sum(mnl.fxtransidx))
            bftrans_b = mnl.coeff_est[mnl_Kf:mnl_Kf + mnl_Kftrans] if mnl_Kftrans > 0 else np.array([])
            bftrans_l = mnl.coeff_est[mnl_Kf + mnl_Kftrans:mnl_Kf + 2 * mnl_Kftrans] if mnl_Kftrans > 0 else np.array([])

            self.init_coeff = self._assemble_init_coeff(
                bf_init, br_b_init, variance_init, bftrans_b, bftrans_l)
        # }

        betas = np.repeat(0.1, n_coeff) if self.init_coeff is None else self.init_coeff
        if self.init_coeff is not None and len(self.init_coeff) != n_coeff and not hasattr(self, 'class_params_spec'):
            self.init_coeff = None
            betas = np.repeat(0.1, n_coeff)

        # Log-share seeding for alternative-specific constants detected as
        # exact alternative dummies: alpha_j = log(s_j / s_base). Cheap
        # closed form; skipped for explicitly user-supplied starts.
        if getattr(self, 'asc_share_init', True) and not _explicit_init:
            try:
                betas, _n_asc = self._seed_asc_from_shares(betas)
                if _n_asc and not _SL_QUIET:
                    print(f"[MXL] ASC share-init seeded {_n_asc} constants "
                          f"(log-share ratios).")
            except Exception:
                pass

        positive_bound = (0, infinity)
        any_bound = (-infinity, infinity)
        lmda_bound = (-5, 1)
        bound_dict = {
            "bf": (any_bound, self.Kf),
            "br_b": (any_bound, self.Kr),
            "chol": (any_bound, self.Kchol),
            "br_w": (positive_bound, self.Kr - self.correlationLength),
            "bf_trans": (any_bound, self.Kftrans),
            "flmbda": (lmda_bound, self.Kftrans),
            "br_trans_b": (any_bound, self.Krtrans),
            "br_trans_w": (any_bound, self.Krtrans),
            "rlmbda": (lmda_bound, self.Krtrans),
            **self._bound_extra(),
        }
        bnds = [[bound[1][0]] * bound[1][1] for bound in bound_dict.items() if bound[1][1] > 0]
        bnds = list(itertools.chain.from_iterable(bnds))

        #print(f"[MXL] Starting beta seed length={n_coeff}, first_values={betas[:min(8, len(betas))]!r}")

        if self.de_init:
            _v = getattr(self, 'verbose_de', False)
            if _v: print(f"[MXL] DE init enabled: popsize={self.de_popsize}, maxiter={self.de_maxiter}, tol={self.de_tol}, polish={self.de_polish}")
            try:
                before_de_obj = self.get_loglik_gradient(betas, self.X, self.y, self.panel_info,
                                                        draws, drawstrans, self.weights,
                                                        self.avail, self.batch_size)[0]
                if _v: print(f"[MXL] DE before: obj={before_de_obj:.6g}")

                def _de_obj(x):
                    return self.get_loglik_gradient(x, self.X, self.y, self.panel_info,
                                                    draws, drawstrans, self.weights,
                                                    self.avail, self.batch_size)[0]

                if len(bnds) == n_coeff:
                    de_bounds = []
                    for idx, bound in enumerate(bnds):
                        low, high = bound
                        if not np.isfinite(low) or not np.isfinite(high):
                            scale = max(1.0, 10.0 * abs(betas[idx]) if idx < len(betas) else 1.0)
                            de_bounds.append((-scale, scale))
                        else:
                            de_bounds.append((low, high))
                else:
                    de_bounds = [(-10, 10)] * n_coeff

                de_result = differential_evolution(
                    _de_obj,
                    de_bounds,
                    strategy='best1bin',
                    maxiter=self.de_maxiter,
                    popsize=self.de_popsize,
                    tol=self.de_tol,
                    polish=self.de_polish,
                    disp=False,
                    workers=1,
                )
                de_improved = False
                if _v: print(f"[MXL] DE completed: success={de_result.success}, nit={de_result.nit}, message={de_result.message}")
                if de_result.success:
                    de_obj = self.get_loglik_gradient(de_result.x, self.X, self.y, self.panel_info,
                                                     draws, drawstrans, self.weights,
                                                     self.avail, self.batch_size)[0]
                    if _v: print(f"[MXL] DE after: obj={de_obj:.6g}")
                    de_improved = de_obj < before_de_obj
                    if de_improved:
                        betas = de_result.x
                        if _v: print(f"[MXL] DE best seed first_values={betas[:min(8, len(betas))]!r}")
                    elif _v:
                        print(f"[MXL] Differential evolution did not beat the original start ({de_obj:.6g} >= {before_de_obj:.6g}); keeping original start.")
                if not de_improved and _v:
                    print(f"[MXL] Differential evolution initialization rejected because it did not improve the starting objective. Using original seed.")
            except Exception as e:
                if _v: print(f"[MXL] Differential evolution initialization failed: {e}")

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu:  # {
            self.X, self.y = dev.convert_array_gpu(self.X), dev.convert_array_gpu(self.y)
            self.panel_info = dev.convert_array_gpu(self.panel_info)
            draws = dev.convert_array_gpu(draws)
            drawstrans = dev.convert_array_gpu(drawstrans)
            self.weights = dev.convert_array_gpu(self.weights) if self.weights is not None else None
            self.avail = dev.convert_array_gpu(self.avail) if self.avail is not None else None
        # }
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        #print(f"[MXL] Minimization start with betas first_values={betas[:min(8, len(betas))]!r}")
        try:
            before_fun = self.get_loglik_gradient(betas, self.X, self.y, self.panel_info,
                                                 draws, drawstrans, self.weights,
                                                 self.avail, self.batch_size)[0]
            #print(f"[MXL] Minimization obj before={before_fun:.6g}")
        except Exception as e:
            if not _SL_QUIET:
                print(f"[MXL] Could not evaluate initial objective before minimization: {e}")

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Generate bound for L-BFGS-B method
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        positive_bound = (0, infinity)
        any_bound = (-infinity, infinity)
        lmda_bound = (-5, 1)
        # corr_bound = (-1, 1)      # QUERY. UNUSED CODE

        bound_dict = {  # (bound range (i.e. pair), number of bounds to add (i.e., int))
            "bf": (any_bound, self.Kf),
            "br_b": (any_bound, self.Kr),
            "chol": (any_bound, self.Kchol),
            "br_w": (positive_bound, self.Kr - self.correlationLength),
            "bf_trans": (any_bound, self.Kftrans),
            "flmbda": (lmda_bound, self.Kftrans),
            "br_trans_b": (any_bound, self.Krtrans),
            "br_trans_w": (any_bound, self.Krtrans),
            "rlmbda": (lmda_bound, self.Krtrans),
            **self._bound_extra(),
        }

        # This code makes a specific number of copies of each range
        # Note: bound[1][0] - the range; bound[1][1] - # copies
        bnds = [[bound[1][0]] * bound[1][1] for bound in bound_dict.items() if bound[1][1] > 0]

        # Flatten the list of bounds, i.e., convert list of lists to one list
        bnds = list(itertools.chain.from_iterable(bnds))

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # SOLVE OPTIMISATION PROBLEM - COMPUTATIONALLY TIME CONSUMING!
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            # ---- JAX fast path ----
        if (getattr(self, '_jax', False) and not use_numba
                and self.minimise_func is None):
            jax_result = self.optimize_jax(betas, draws, drawstrans)
            if jax_result is not None:
                # ── L-BFGS-B polish for stable Hessian ──────────────────
                # JAX Hessian through 500 simulation draws is often near-
                # singular; scipy's L-BFGS-B quasi-Newton Hessian is much
                # more robust because it's built from gradient history over
                # multiple iterations, not a single-point autodiff through
                # noisy simulation draws.
                if ('hess_inv' not in jax_result
                        or np.all(np.abs(np.diag(np.array(
                            jax_result.get('hess_inv',
                                           np.eye(1))))) < 1e-12)):
                    try:
                        _polish_fn = self.get_loglik_gradient
                        _polish_args = (self.X, self.y, self.panel_info,
                                        draws, drawstrans, self.weights,
                                        self.avail, self.batch_size)
                        polish = minimize(
                            _polish_fn,
                            np.asarray(jax_result['x']).copy(),
                            jac=True, method='L-BFGS-B',
                            args=_polish_args,
                            options={'gtol': self.gtol * 100,
                                     'maxiter': 100, 'disp': False},
                        )
                        if (polish.get('fun', float('inf'))
                                < jax_result.get('fun', float('inf')) + 0.1):
                            jax_result.update(polish)
                            jax_result['hess_inv'] = getattr(polish, 'hess_inv', None)
                    except Exception:
                        pass
                # ─────────────────────────────────────────────────────────

                # Use the SAME canonical 14-segment layout as the batched
                # (non-JAX) path below (see ~line 1203). The previous JAX-only
                # layout inserted the extra segment right after Br_b and OMITTED
                # the four heterogeneity segments (het_mean_rv, het_var_rv,
                # het_mean_rvtrans, het_var_rvtrans), so split_betas produced a
                # 10-entry var_list while compute_probabilities unpacks 14 — which
                # crashed ("not enough values to unpack (expected 14, got 10)")
                # for any random-coefficient model without individual-specific
                # variables (e.g. an all-asvar mode-choice spec). The trailing
                # het segments are zero-length when heterogeneity is unused, so
                # this is safe and matches the beta vector layout implied by
                # _jax_negloglik_extra_kwargs (het terms after the base params).
                beta_segment_names = ["Bf", "Br_b", "chol", "Br_w", "Bftrans",
                                      "flmbda", "Brtrans_b", "Brtrans_w", "rlmda",
                                      "het_mean_rv", "het_var_rv",
                                      "het_mean_rvtrans", "het_var_rvtrans",
                                      "het_corr_cov"]
                extra_names, extra_counts = self._beta_segment_extra()
                beta_segment_names = beta_segment_names + [
                    n for n in extra_names if n not in beta_segment_names]
                iterations = [self.Kf, self.Kr, self.Kchol, self.Kbw, self.Kftrans,
                              self.Kftrans, self.Krtrans, self.Krtrans, self.Krtrans,
                              self.K_het_mean_rv, self.K_het_var_rv,
                              self.K_het_mean_rvtrans, self.K_het_var_rvtrans,
                              self.K_het_corr_cov]
                self.var_list = self.split_betas(jax_result['x'], iterations, beta_segment_names)
                self.chol_mat = self.construct_chol_mat(
                    self.var_list['chol'], self.var_list['Br_w'], self.var_list['Brtrans_w'])

                p = self.compute_probabilities(jax_result['x'], self.X, self.panel_info,
                                                draws, drawstrans, self.avail, self.var_list, self.chol_mat)
                self.choice_pred_prob = np.mean(p, axis=3)
                self.ind_pred_prob, self.pred_prob = _panel_weighted_shares(
                    self.choice_pred_prob, self.panel_info)
                self.prob_full = p
                self._refresh_corr_from_varlist()
                self.post_process(jax_result, self.Xnames, self.N)
                return

        minimise_func = minimize if self.minimise_func is None else self.minimise_func
        if use_numba:
            # Prefer the registered numba builder; silent fallback to the
            # SciPy default when the spec is outside the supported base case.
            try:
                try:
                    from numba_engine import make_minimiser_for
                except ImportError:
                    from .numba_engine import make_minimiser_for
                _nb = make_minimiser_for(self)
                if _nb is not None:
                    minimise_func = _nb
            except Exception as _e:
                print(f"[MXL numba engine] unavailable ({_e}); using scipy.")
        self.fit_intercept_old = False
        if self.fit_intercept_old:
            if self.X.shape[-1] != len(self.fxidx):
                print(f'difference is {self.X.shape[-1] - len(self.fxidx)}')
                print('problem here')
                ones = np.ones((self.X.shape[0], self.X.shape[1], self.X.shape[2], 1))
                # X=np.hstack(np.tile(np.eye(J), reps=(P_N, 1)),X)
                print('UNSURE THIS MIGHT NOT WORK FOR PANELS')
                # eye = np.tile(np.eye(self.J), reps=(self.X.shape[0], 1))
                # X = np.hstack((eye,X))

                self.X = np.concatenate((ones, self.X), axis=-1)
        args = (self.X, self.y, self.panel_info, draws, drawstrans, self.weights, self.avail, self.batch_size)
        bounds = bnds if self.method == "l-bfgs-b" else None
        options = {'gtol': self.gtol, 'maxiter': self.maxiter, 'disp': False}
        result = minimise_func(self.get_loglik_gradient, betas, jac=self.jac, method=self.method,
                               args=args, tol=self.ftol, bounds=bounds, options=options)
        if not _SL_QUIET:
            print(f"[MXL] Minimization completed: success={result.get('success', None)}, fun={result.get('fun', float('nan')):.6g}, nit={result.get('nit', '?')}")
            if 'x' in result:
                print(f"[MXL] Minimization final betas first_values={np.asarray(result['x'])[:min(8, len(result['x']))]!r}")
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        if hasattr(self, 'method') and self.method == "l-bfgs-b":  # {
            H = self.get_hessian(result['x'], self._get_loglik_gradient)
            try:
                result['hess_inv'] = np.linalg.inv(H)
            except np.linalg.LinAlgError:
                result['hess_inv'] = np.linalg.pinv(H)
        # }
        else:
            # ── Non-L-BFGS-B path (e.g. JAX): compute Hessian numerically
            #     so post_process can extract standard errors
            try:
                H = self.get_hessian(result['x'], self._get_loglik_gradient, eps=1e-6)
                result['hess_inv'] = np.linalg.inv(H)
            except Exception:
                try:
                    result['hess_inv'] = np.linalg.pinv(H)
                except Exception:
                    pass

        if self.save_fitted_params:
            self.compute_fitted_params(self.y, self.p, self.panel_info, self.Br)

        # save predicted and observed probabilities to display in summary
        if 'is_latent_class' not in result.keys():
            # {
            p = self.compute_probabilities(result['x'], self.X, self.panel_info,
                                           draws, drawstrans, self.avail, self.var_list, self.chol_mat)

            # Compute choice_pred_prob = avg(p[i,j,:]):
            self.choice_pred_prob = np.mean(p, axis=3)

            # Per-person / overall predicted shares over valid panels only
            # (unweighted P-means smooth predictions toward uniform).
            self.ind_pred_prob, self.pred_prob = _panel_weighted_shares(
                self.choice_pred_prob, self.panel_info)

            self.prob_full = p
        # }
        self._refresh_corr_from_varlist()
        self.post_process(result, self.Xnames, self.N)
    # }

    def get_hessian(self, x, func, eps=1e-8):
        # {
        N = x.size  # Cardinality of hessian matrix
        hessian = np.zeros((N, N))  # Initialise hessian matrix
        df_0 = func(x)[1]  # Evaluate function
        for i in np.arange(N):  # i.e., for i = 0, 1, ..., N-1
            # {
            x[i] += eps  # Increment by epsilon
            df_1 = func(x)[1]  # Evaluate x
            hessian[i, :] = (df_1 - df_0) / eps  # Compute the gradient for row i elements
            x[i] -= eps  # Undo the change
        # }
        return hessian
    # }

    # ------------------------------------------------------------------
    # JAX-based MLE for Mixed Logit
    # ------------------------------------------------------------------
    @staticmethod
    def _jax_mxl_negloglik(betas, X_jax, y_jax, panel_info_jax, draws_jax,
                            fxidx, rvidx, Kf, Kr, Kchol, Kbw, rvdist_names,
                            correlationLength,
                            # Heterogeneity parameters
                            K_het_mean_rv=0, K_het_var_rv=0,
                            K_het_mean_rvtrans=0, K_het_var_rvtrans=0,
                            het_mean_rv_idx=None, het_mean_rv_cols=None,
                            het_var_rv_idx=None, het_var_rv_cols=None,
                            het_mean_rvtrans_idx=None, het_mean_rvtrans_cols=None,
                            het_var_rvtrans_idx=None, het_var_rvtrans_cols=None,
                            rv_col_idx=None, rvtrans_col_idx=None,
                            # Correlated heterogeneity parameters
                            K_het_corr_cov=0,
                            het_corr_groups=None,
                            het_corr_group_id=None,
                            het_corr_group_params=None,
                            **kwargs):
        """JAX simulation-based log-likelihood for Mixed Logit with heterogeneity in means and variances.

        Handles fixed and random (normally/lognormally distributed) parameters.
        Cholesky correlation structure is included via the Kchol segment;
        uncorrelated random vars use independent std devs in Br_w.
        Heterogeneity in means/variances is applied via covariates.
        Correlated heterogeneity allows covariance between heterogeneity parameters across variables.
        """
        import jax.numpy as jnp

        # ---- split beta vector ----
        Bf     = betas[:Kf]
        Br_b   = betas[Kf:Kf + Kr]
        chol_v = betas[Kf + Kr:Kf + Kr + Kchol]             # correlated cholesky elements
        Br_w   = betas[Kf + Kr + Kchol:Kf + Kr + Kchol + Kbw]  # independent std devs

        # Heterogeneity parameters start after base MXL parameters
        # Standard MXL params: Kf + Kr + Kchol + Kbw + 2*Kftrans + 3*Krtrans
        # We'll compute the offset from kwargs
        het_offset = kwargs.get('het_offset', Kf + Kr + Kchol + Kbw)

        # ---- build cholesky matrix ----
        chol_mat = jnp.zeros((Kr, Kr))
        idx = 0
        for r in range(correlationLength):
            for c in range(r + 1):
                chol_mat = chol_mat.at[r, c].set(chol_v[idx])
                idx += 1
        for k in range(Kbw):
            diag_pos = correlationLength + k
            chol_mat = chol_mat.at[diag_pos, diag_pos].set(jnp.abs(Br_w[k]))

        # ---- sample random coefficients: (N, Kr, R) ----
        N = X_jax.shape[0]

        # Apply variance heterogeneity BEFORE forming Br: scale the latent
        # draws by exp(het_var_rv * covariates). Scaling after the sum would
        # be a no-op (and left the gradient chasing a phantom term).
        if K_het_var_rv > 0:
            het_var_rv = betas[het_offset + K_het_mean_rv:het_offset + K_het_mean_rv + K_het_var_rv]
            for idx, (rv_idx, col) in enumerate(zip(het_var_rv_idx, het_var_rv_cols)):
                het_cov = X_jax[:, :, :, col]
                het_cov_mean = jnp.mean(het_cov, axis=(1, 2))
                scale = jnp.exp(het_var_rv[idx] * het_cov_mean)
                draws_jax = draws_jax.at[:, rv_idx:rv_idx+1, :].mul(scale[:, None, None])

        Br = Br_b[:, None] + jnp.einsum('kl,nlr->nkr',
                                         chol_mat,
                                         draws_jax[:, :Kr, :])   # (N, Kr, R)

        # Apply mean heterogeneity: Br += het_mean_rv * covariates
        if K_het_mean_rv > 0:
            # Extract heterogeneity parameters
            het_mean_rv = betas[het_offset:het_offset + K_het_mean_rv]
            for idx, (rv_idx, col) in enumerate(zip(het_mean_rv_idx, het_mean_rv_cols)):
                het_cov = X_jax[:, :, :, col]
                het_cov_mean = jnp.mean(het_cov, axis=(1, 2))  # (N,)
                Br = Br.at[:, rv_idx:rv_idx+1, :].add(het_mean_rv[idx] * het_cov_mean[:, None, None])

        # Apply correlated heterogeneity: draw correlated heterogeneity parameters
        if K_het_corr_cov > 0 and het_corr_groups is not None:
            # Extract correlated heterogeneity parameters (Cholesky elements for covariance matrix)
            # These are the parameters after the independent heterogeneity parameters
            het_corr_offset = het_offset + K_het_mean_rv + K_het_var_rv + K_het_mean_rvtrans + K_het_var_rvtrans
            het_corr_chol = betas[het_corr_offset:het_corr_offset + K_het_corr_cov]
            
            # For each correlated heterogeneity group, draw correlated heterogeneity parameters
            # This is a simplified implementation - in practice would need proper Cholesky handling
            # For now, we add a placeholder that doesn't modify Br
            pass

        # apply distribution transforms
        for k, dist in enumerate(rvdist_names):
            if dist == 'ln':
                Br = Br.at[:, k, :].set(jnp.exp(Br[:, k, :]))
            elif dist == 'nln':
                Br = Br.at[:, k, :].set(-jnp.exp(Br[:, k, :]))
            elif dist == 'tn':
                Br = Br.at[:, k, :].set(jnp.abs(Br[:, k, :]))
            elif dist == 'u':
                # Marginal sd = Cholesky row norm: exact for correlated vars
                # and identical to Br_w[k] when uncorrelated (single-nonzero
                # row, symmetric uniform so the abs() is distribution-neutral).
                # Direct Br_w[k] indexing breaks with IndexError whenever
                # correlated vars exist (Kbw < Kr) or Kbw == 0.
                _sd_k = jnp.linalg.norm(chol_mat[k, :])
                Br = Br.at[:, k, :].set(
                    Br_b[k] + _sd_k * (draws_jax[:, k, :] - 0.5))

        # ---- utility ----
        P = X_jax.shape[1]
        J = X_jax.shape[2]
        Xr = X_jax[:, :, :, rvidx]                           # (N, P, J, Kr)
        UR = jnp.einsum('npjk,nkr->npjr', Xr, Br)           # (N, P, J, R)

        if Kf > 0:
            Xf = X_jax[:, :, :, fxidx]                       # (N, P, J, Kf)
            UB = jnp.einsum('npjk,k->npj', Xf, Bf)           # (N, P, J)
            U  = UB[:, :, :, None] + UR
        else:
            U  = UR                                           # (N, P, J, R)

        U   = U - jnp.max(U, axis=2, keepdims=True)
        eU  = jnp.exp(U)
        p   = eU / jnp.sum(eU, axis=2, keepdims=True)        # (N, P, J, R)

        pch = jnp.sum(y_jax[:, :, :, None] * p, axis=2)     # (N, P, R)
        # Mask padded (panel_info == 0) choice situations so they contribute a
        # factor of 1 to the per-individual product rather than 0. Without this,
        # UNBALANCED panels (individuals with different numbers of choice
        # situations) collapse the joint probability to ~0, and the
        # log-likelihood explodes. Mirrors prob_product_across_panels in the
        # NumPy gradient path.
        pi = panel_info_jax[:, :, None]                      # (N, P, 1)
        pch = jnp.where(pi > 0, pch, 1.0)
        pch = jnp.prod(pch, axis=1)                          # (N, R)
        pch = jnp.clip(pch, 1e-300, None)

        sim_p = jnp.mean(pch, axis=1)                        # (N,)
        sim_p = jnp.clip(sim_p, 1e-300, None)
        ll = -jnp.sum(jnp.log(sim_p))
        # Tiny L2 penalty — makes the Hessian diagonally dominant so it
        # never becomes singular, even with near-constant variables or
        # simulation noise in the mixed-logit probability integration.
        reg = kwargs.get('reg_penalty', 0.0)
        if reg > 0:
            ll = ll + reg * jnp.sum(jnp.square(betas))
        # Extra penalty on the random-coefficient standard deviations (Br_w),
        # which occupy the Kbw entries after Bf, Br_b and the cholesky block.
        sd_pen = kwargs.get('sd_penalty', 0.0)
        if sd_pen > 0 and Kbw > 0:
            _start = Kf + Kr + Kchol
            ll = ll + sd_pen * jnp.sum(jnp.square(betas[_start:_start + Kbw]))
        return ll

    # ------------------------------------------------------------------
    # MASKED (fixed-max-size) negloglik — one JIT compilation for ALL specs.
    #
    # The per-shape path above recompiles once for every distinct
    # (Kf, Kr, Kchol, Kbw). This variant instead pads the design to a fixed
    # (KF, KR), passes float masks (mask_f, mask_r) and the draws padded to KR,
    # and zeroes inactive columns with the masks instead of slicing — so a single
    # compiled function serves every specification. Scope: UNCORRELATED random
    # coefficients, no heterogeneity, no Box-Cox (exactly the cases the JAX path
    # already supports; correlated/het/trans fall back to the per-shape path).
    # Enabled with SL_JAX_MASK=1; numerically identical to the per-shape path
    # (see tests/test_jax_mask_equivalence.py).
    #
    # beta layout (padded): [ Bf: KF | Br_b: KR | Br_w: KR ]
    # rvdist_codes: per random slot — 0:n 1:ln 2:nln 3:tn 4:u  (padding uses 0).
    # ------------------------------------------------------------------
    @staticmethod
    def _jax_mxl_negloglik_masked(betas, X_jax, y_jax, panel_info_jax, draws_jax,
                                  mask_f, mask_r, rvdist_codes, KF, KR,
                                  reg_penalty=0.0, sd_penalty=0.0):
        import jax.numpy as jnp
        Bf   = betas[:KF] * mask_f                       # inactive fixed -> 0
        Br_b = betas[KF:KF + KR]
        Br_w = jnp.abs(betas[KF + KR:KF + 2 * KR])       # sd >= 0 (diagonal chol)

        d = draws_jax[:, :KR, :]                         # (N, KR, R)
        base = Br_b[None, :, None] + Br_w[None, :, None] * d   # normal draw
        codes = rvdist_codes[None, :, None]              # (1, KR, 1)
        Br = base
        Br = jnp.where(codes == 1, jnp.exp(base), Br)                        # ln
        Br = jnp.where(codes == 2, -jnp.exp(base), Br)                       # nln
        Br = jnp.where(codes == 3, jnp.abs(base), Br)                        # tn
        Br = jnp.where(codes == 4,
                       Br_b[None, :, None] + Br_w[None, :, None] * (d - 0.5), Br)  # u
        Br = Br * mask_r[None, :, None]                  # inactive random -> 0

        Xf = X_jax[:, :, :, :KF]                         # (N, P, J, KF)
        Xr = X_jax[:, :, :, KF:KF + KR]                  # (N, P, J, KR)
        UB = jnp.einsum('npjk,k->npj', Xf, Bf)
        UR = jnp.einsum('npjk,nkr->npjr', Xr, Br)
        U  = UB[:, :, :, None] + UR

        U   = U - jnp.max(U, axis=2, keepdims=True)
        eU  = jnp.exp(U)
        p   = eU / jnp.sum(eU, axis=2, keepdims=True)
        pch = jnp.sum(y_jax[:, :, :, None] * p, axis=2)  # (N, P, R)
        pi  = panel_info_jax[:, :, None]
        pch = jnp.where(pi > 0, pch, 1.0)
        pch = jnp.prod(pch, axis=1)                      # (N, R)
        pch = jnp.clip(pch, 1e-300, None)
        sim = jnp.clip(jnp.mean(pch, axis=1), 1e-300, None)
        ll  = -jnp.sum(jnp.log(sim))
        if reg_penalty:
            ll = ll + reg_penalty * (jnp.sum(jnp.square(Bf))
                                     + jnp.sum(jnp.square(Br_b * mask_r))
                                     + jnp.sum(jnp.square(Br_w * mask_r)))
        if sd_penalty:
            ll = ll + sd_penalty * jnp.sum(jnp.square(Br_w * mask_r))
        return ll

    # ------------------------------------------------------------------
    # Per-shape JIT cache: avoids recompilation when the same (N, P, J,
    # Kf, Kr, Kchol, Kbw) combination is visited again during GA search.
    #
    # MEMORY: the cache is a bounded LRU, and every cached callable closes
    # over a *weakref* to the model that built it. Caching a closure that
    # captured ``self`` directly made each entry pin a whole model (and its
    # X/y/draws arrays plus a live XLA executable) for the life of the
    # process; during a heterogeneous GA search that is one retained model
    # per distinct parameter-count combination.
    # ------------------------------------------------------------------
    _JIT_CACHE_MAXSIZE = 16
    _mxl_jit_cache: "OrderedDict[tuple, tuple]" = OrderedDict()

    @staticmethod
    def _freeze(value):
        """Hashable, structural fingerprint of a closure-constant value.

        Used so the cache key actually reflects the per-instance data baked
        into the cached callable (index lists, group definitions). Keying on
        shapes alone let two specs with identical shapes but different index
        lists collide and silently reuse the wrong compiled function.
        """
        if isinstance(value, np.ndarray):
            return (value.shape, str(value.dtype), value.tobytes())
        if isinstance(value, (list, tuple)):
            return tuple(MixedLogit._freeze(v) for v in value)
        if isinstance(value, dict):
            return tuple(sorted((k, MixedLogit._freeze(v))
                                for k, v in value.items()))
        return value

    @classmethod
    def _closure_key(cls, extra):
        """Cache-key fragment covering everything captured from ``self``."""
        return tuple((k, cls._freeze(v)) for k, v in sorted(extra.items()))

    @classmethod
    def _jit_cache_get(cls, key):
        """Fetch a live cache entry, dropping it if its owner was collected."""
        entry = cls._mxl_jit_cache.get(key)
        if entry is None:
            return None
        ref, value = entry
        if ref is not None and ref() is None:
            cls._mxl_jit_cache.pop(key, None)
            return None
        cls._mxl_jit_cache.move_to_end(key)
        return value

    @classmethod
    def _jit_cache_put(cls, key, value, owner):
        """Insert an entry, evicting least-recently-used ones past maxsize."""
        try:
            ref = weakref.ref(owner)
        except TypeError:
            ref = None
        cls._mxl_jit_cache[key] = (ref, value)
        cls._mxl_jit_cache.move_to_end(key)
        while len(cls._mxl_jit_cache) > cls._JIT_CACHE_MAXSIZE:
            cls._mxl_jit_cache.popitem(last=False)

    @classmethod
    def _clear_jit_cache(cls):
        """Drop all cached JIT-compiled MXL functions to free XLA memory."""
        import gc
        cls._mxl_jit_cache.clear()
        try:
            import jax
            jax.clear_caches()
        except Exception:
            pass
        gc.collect()

    def _run_jaxopt(self, betas, X_jax, y_jax, pi_jax, draws_jax,
                    _fn, _cache_key):
        """JAX likelihood + ``jaxopt.LBFGS`` solver (experiment).

        Same simulated likelihood as the SciPy path (``_fn`` closed over
        the current spec), jitted once per shape and cached. Returns a
        SciPy-style result dict (``x``/``fun``/``nit``/``success``) so the
        shared Hessian / ``post_process`` machinery downstream runs
        unchanged — or ``None`` on any failure so the caller falls back
        to SciPy.
        """
        try:
            import jaxopt
        except Exception as _e:
            if not _SL_QUIET:
                print(f"[JAX MXL optimizer] jaxopt not installed ({_e}).")
            return None
        try:
            import jax
            import numpy as _np
            key = tuple(_cache_key) + ('jaxopt',)
            solver = self._jit_cache_get(key)
            if solver is None:
                solver = jaxopt.LBFGS(
                    fun=_fn, value_and_grad=False,
                    maxiter=int(self.maxiter),
                    tol=float(self.gtol), jit=True)
                self._jit_cache_put(key, solver, self)
            import jax.numpy as _jnp
            b0 = _jnp.array(np.asarray(betas, dtype=float), dtype=_jnp.float64)
            params, state = solver.run(b0, X_jax, y_jax, pi_jax, draws_jax)
            x = _np.asarray(params, dtype=float)
            # Objective value via a jitted value_and_grad (one extra
            # compile per shape, reused across fits like everything else).
            _vg = self._jit_cache_get(_cache_key)
            if _vg is None:
                _vg = jax.jit(jax.value_and_grad(_fn))
                self._jit_cache_put(_cache_key, _vg, self)
            v, _g = _vg(_jnp.array(x, dtype=_jnp.float64),
                        X_jax, y_jax, pi_jax, draws_jax)
            fun = float(v)
            try:
                err = float(getattr(state, 'error', float('inf')))
            except Exception:
                err = float('inf')
            try:
                nit = int(getattr(state, 'iter_num', 0))
            except Exception:
                nit = 0
            _tol = float(self.gtol)
            ok = bool(_np.isfinite(fun) and err <= max(_tol, 1e-8) * 10.0)
            if not _SL_QUIET:
                print(f"[JAX MXL optimizer] jaxopt.LBFGS finished: "
                      f"success={ok}, fun={fun:.6g}, nit={nit}, err={err:.3g}")
            _out = {'x': x, 'fun': fun, 'nit': nit, 'success': ok}
            # JAX autograd Hessian for standard errors (mirrors the SciPy
            # path below so post_process behaves identically).
            try:
                _hkey = key + ('hess',)
                _ch = self._jit_cache_get(_hkey)
                if _ch is None:
                    _ch = jax.jit(jax.hessian(_fn))
                    self._jit_cache_put(_hkey, _ch, self)
                _H = _ch(_jnp.array(x, dtype=_jnp.float64),
                         X_jax, y_jax, pi_jax, draws_jax)
                _Hnp = _np.asarray(_H, dtype=float)
                try:
                    _out['hess_inv'] = _np.linalg.inv(_Hnp)
                except _np.linalg.LinAlgError:
                    _out['hess_inv'] = _np.linalg.pinv(_Hnp)
            except Exception:
                pass
            return _out
        except Exception as _e:
            if not _SL_QUIET:
                print(f"[JAX MXL optimizer] jaxopt run failed ({_e}).")
            return None

    def optimize_jax(self, betas, draws, drawstrans):
        """JAX-accelerated optimisation for the Mixed Logit model.

        Uses value_and_grad over _jax_mxl_negloglik and scipy BFGS.
        Falls back to standard numpy optimisation on failure.
        """
        # Disable JAX for models with heterogeneity in means/variances
        if (getattr(self, 'K_het_mean_rv', 0) > 0 or 
            getattr(self, 'K_het_var_rv', 0) > 0 or
            getattr(self, 'K_het_mean_rvtrans', 0) > 0 or
            getattr(self, 'K_het_var_rvtrans', 0) > 0):
            if not _SL_QUIET:
                print("[JAX MXL optimizer] heterogeneity detected; falling back to scipy.")
            return None

        try:
            import os
            os.environ.setdefault("JAX_ENABLE_X64", "True")
            import jax
            jax.config.update("jax_enable_x64", True)
            import jax.numpy as jnp
            from scipy.optimize import minimize as sp_min

            if int(self.Kr) == 0:
                if not _SL_QUIET:
                    print("[JAX MXL optimizer] no random coefficients detected (Kr=0); falling back to scipy.")
                return None

            # Convert static inputs once
            X_jax        = jnp.array(self.X,          dtype=jnp.float64)
            _y_np        = np.asarray(self.y)
            if _y_np.ndim > 3:           # stored as (N, P, J, 1) in some paths
                _y_np = _y_np[..., 0]
            y_jax        = jnp.array(_y_np,            dtype=jnp.float64)
            pi_jax       = jnp.array(self.panel_info,  dtype=jnp.float64)
            draws_jax    = jnp.array(draws,             dtype=jnp.float64)

            fxidx = jnp.array(self.fxidx, dtype=bool)
            rvidx = jnp.array(self.rvidx, dtype=bool)
            rvdist_names = [d for d in self.rvdist if d is not False]

            Kf, Kr, Kchol, Kbw = int(self.Kf), int(self.Kr), int(self.Kchol), int(self.Kbw)
            correlationLength = int(self.correlationLength)

            # ── Optional masked (compile-once) path ────────────────
            # One JIT compilation serves every spec: pad to a running-max
            # (KF, KR), mask inactive columns. Only for the uncorrelated,
            # no-heterogeneity, no-Box-Cox case (the correlated/trans cases fall
            # through to the exact per-shape path below).
            if (os.environ.get('SL_JAX_MASK', '0') == '1'
                    and Kchol == 0 and correlationLength == 0 and Kbw == Kr
                    and int(getattr(self, 'Kftrans', 0)) == 0
                    and int(getattr(self, 'Krtrans', 0)) == 0):
                _masked = self._run_masked_jax(
                    betas, X_jax, y_jax, pi_jax, draws_jax,
                    fxidx, rvidx, rvdist_names, Kf, Kr, jax, jnp, sp_min)
                if _masked is not None:
                    return _masked
                # else: fall through to the per-shape path

            # ── per-shape JIT cache ────────────────────────────────
            # Key on shape AND on every value captured from ``self``, so two
            # specs with the same shape but different index lists cannot
            # collide. The callable dereferences a weakref rather than
            # capturing ``self``, so a cache hit never keeps a dead model
            # (and its X/y/draws arrays) alive.
            _N = X_jax.shape[0]
            _P = X_jax.shape[1] if X_jax.ndim > 1 else 1
            _J = X_jax.shape[2] if X_jax.ndim > 2 else 1
            _extra = self._jax_negloglik_extra_kwargs()
            _cache_key = ((_N, _P, _J, Kf, Kr, Kchol, Kbw)
                          + self._jax_cache_key_extra()
                          + (self._closure_key(_extra),))
            _sref = weakref.ref(self)

            def _fn(b, _X, _y, _pi, _dr):
                _self = _sref()
                if _self is None:
                    raise RuntimeError(
                        "MixedLogit instance was garbage-collected while its "
                        "compiled objective was still in use")
                return _self._jax_mxl_negloglik(
                    b, _X, _y, _pi, _dr,
                    fxidx, rvidx, Kf, Kr, Kchol, Kbw, rvdist_names,
                    correlationLength, **_extra)
            # ── jaxopt solver (experiment): same likelihood, jaxopt.LBFGS
            # instead of SciPy. Selected via model.engine == 'jaxopt'.
            # Falls through to the SciPy path on any failure.
            if getattr(self, 'engine', None) == 'jaxopt':
                _jr = self._run_jaxopt(
                    betas, X_jax, y_jax, pi_jax, draws_jax, _fn, _cache_key)
                if _jr is not None:
                    return _jr
                if not _SL_QUIET:
                    print("[JAX MXL optimizer] jaxopt unavailable/failed; "
                          "falling back to scipy.")
            _compiled = self._jit_cache_get(_cache_key)
            if _compiled is None:
                _compiled = jax.jit(jax.value_and_grad(_fn))
                self._jit_cache_put(_cache_key, _compiled, self)
            # ────────────────────────────────────────────────────────

            def _obj(betas_np):
                b    = jnp.array(betas_np, dtype=jnp.float64)
                v, g = _compiled(b, X_jax, y_jax, pi_jax, draws_jax)
                return float(v), np.array(g, dtype=np.float64)

            # Build options dict based on method
            opts = {'maxiter': self.maxiter, 'disp': False}
            if self.method in ['bfgs', 'l-bfgs-b']:
                opts['gtol'] = self.gtol
                opts['ftol'] = self.ftol
            elif self.method == 'slsqp':
                opts['ftol'] = self.ftol  # SLSQP uses ftol, not gtol

            result = sp_min(
                _obj, betas, jac=True, method=self.method, options=opts)

            # ── JAX autograd Hessian for standard errors ───────────────
            try:
                hess_cache_key = _cache_key + ('hess',)
                _compiled_hess = self._jit_cache_get(hess_cache_key)
                if _compiled_hess is None:
                    _compiled_hess = jax.jit(jax.hessian(_fn))
                    self._jit_cache_put(hess_cache_key, _compiled_hess, self)
                b_opt = jnp.array(result['x'], dtype=jnp.float64)
                H = _compiled_hess(b_opt, X_jax, y_jax, pi_jax, draws_jax)
                H_np = np.asarray(H, dtype=float)
                try:
                    result['hess_inv'] = np.linalg.inv(H_np)
                except np.linalg.LinAlgError:
                    result['hess_inv'] = np.linalg.pinv(H_np)
            except Exception:
                pass

            return result

        except Exception as e:
            if not _SL_QUIET:
                print(f"[JAX MXL optimizer] falling back to scipy: {e}")
            return None   # caller will use standard path

    # Running-max padding sizes shared across every spec, so the masked negloglik
    # compiles once (and only recompiles the handful of times the max grows).
    _jax_mask_KF: int = 0
    _jax_mask_KR: int = 0

    def _run_masked_jax(self, betas, X_jax, y_jax, pi_jax, draws_jax,
                        fxidx, rvidx, rvdist_names, Kf, Kr, jax, jnp, sp_min):
        """Fit via the masked, compile-once negloglik. Returns a scipy-style
        result with REAL-length x and hess_inv, or None to fall back."""
        try:
            _np = np
            KF = max(int(MixedLogit._jax_mask_KF), int(Kf))
            KR = max(int(MixedLogit._jax_mask_KR), int(Kr))
            MixedLogit._jax_mask_KF, MixedLogit._jax_mask_KR = KF, KR

            N = X_jax.shape[0]; P = X_jax.shape[1]; J = X_jax.shape[2]
            fx = _np.asarray(fxidx, dtype=bool)
            rv = _np.asarray(rvidx, dtype=bool)
            Xnp = _np.asarray(X_jax)
            # Padded design: [ active fixed | 0…KF | active random | 0…KR ]
            X_pad = _np.zeros((N, P, J, KF + KR), dtype=_np.float64)
            X_pad[:, :, :, :Kf] = Xnp[:, :, :, fx]
            X_pad[:, :, :, KF:KF + Kr] = Xnp[:, :, :, rv]
            X_pad_j = jnp.asarray(X_pad)

            dr = _np.asarray(draws_jax)
            R = dr.shape[2]
            draws_pad = _np.zeros((N, KR, R), dtype=_np.float64)
            draws_pad[:, :Kr, :] = dr[:, :Kr, :]
            draws_pad_j = jnp.asarray(draws_pad)

            mask_f = _np.zeros(KF); mask_f[:Kf] = 1.0
            mask_r = _np.zeros(KR); mask_r[:Kr] = 1.0
            _code = {'n': 0, 'ln': 1, 'nln': 2, 'tn': 3, 'u': 4}
            codes = _np.zeros(KR, dtype=_np.float64)
            for i, dname in enumerate(list(rvdist_names)[:Kr]):
                codes[i] = _code.get(dname, 0)
            mask_f_j = jnp.asarray(mask_f)
            mask_r_j = jnp.asarray(mask_r)
            codes_j = jnp.asarray(codes)

            # The real (uncorrelated) beta vector is [Bf(Kf) | Br_b(Kr) | Br_w(Kr)];
            # its entries map to these positions of the padded
            # [Bf:KF | Br_b:KR | Br_w:KR] layout.
            b0 = _np.asarray(betas, dtype=_np.float64)
            active = _np.asarray(
                list(range(Kf)) + list(range(KF, KF + Kr))
                + list(range(KF + KR, KF + KR + Kr)), dtype=int)

            reg = float(getattr(self, 'reg_penalty', 0.0) or 0.0)
            sdp = float(getattr(self, 'sd_penalty', 0.0) or 0.0)

            # masks/codes are ARGUMENTS (dynamic data, static shape) so one
            # compiled fn serves every spec; KF/KR/reg/sdp are baked in (keyed).
            key = ('masked', N, P, J, KF, KR, reg, sdp)
            fn = self._jit_cache_get(key)
            if fn is None:
                _sref = weakref.ref(self)

                def _f(b, _X, _y, _pi, _dr, _mf, _mr, _cd):
                    _self = _sref()
                    if _self is None:
                        raise RuntimeError(
                            "MixedLogit instance was garbage-collected while "
                            "its compiled objective was still in use")
                    return _self._jax_mxl_negloglik_masked(
                        b, _X, _y, _pi, _dr, _mf, _mr, _cd, KF, KR,
                        reg_penalty=reg, sd_penalty=sdp)
                fn = jax.jit(jax.value_and_grad(_f))
                self._jit_cache_put(key, fn, self)

            def _scatter(real_bnp):
                bpad = _np.zeros(KF + 2 * KR, dtype=_np.float64)
                bpad[active] = real_bnp
                return bpad

            # IMPORTANT: scipy optimises the REAL-length beta vector (padded dims
            # are scattered in only inside the objective). Optimising the padded
            # vector directly lets BFGS's dense inverse-Hessian couple the flat
            # padded dims into the active ones, which shifted the optimum by ~1e-3
            # vs the per-shape path. This way the optimisation problem is byte-for-
            # byte the same as per-shape, while the compiled fn stays fixed-shape.
            def _obj(real_bnp):
                v, g = fn(jnp.asarray(_scatter(real_bnp), dtype=jnp.float64),
                          X_pad_j, y_jax, pi_jax, draws_pad_j,
                          mask_f_j, mask_r_j, codes_j)
                return float(v), _np.asarray(g, dtype=_np.float64)[active]

            opts = {'maxiter': self.maxiter, 'disp': False}
            if self.method in ['bfgs', 'l-bfgs-b']:
                opts['gtol'] = self.gtol; opts['ftol'] = self.ftol
            elif self.method == 'slsqp':
                opts['ftol'] = self.ftol
            result = sp_min(_obj, b0, jac=True, method=self.method, options=opts)
            # result['x'] is already the real-length beta vector.
            xr = _scatter(_np.asarray(result['x'], dtype=_np.float64))

            # Standard errors: masked Hessian, then the active-index block only
            # (padded rows/cols are exactly flat -> singular otherwise).
            try:
                hkey = key + ('hess',)
                hfn = self._jit_cache_get(hkey)
                if hfn is None:
                    _sref_h = weakref.ref(self)

                    def _fh(b, _X, _y, _pi, _dr, _mf, _mr, _cd):
                        _self = _sref_h()
                        if _self is None:
                            raise RuntimeError(
                                "MixedLogit instance was garbage-collected "
                                "while its compiled objective was still in use")
                        return _self._jax_mxl_negloglik_masked(
                            b, _X, _y, _pi, _dr, _mf, _mr, _cd, KF, KR,
                            reg_penalty=reg, sd_penalty=sdp)
                    hfn = jax.jit(jax.hessian(_fh))
                    self._jit_cache_put(hkey, hfn, self)
                H = _np.asarray(hfn(jnp.asarray(xr, dtype=jnp.float64), X_pad_j,
                                    y_jax, pi_jax, draws_pad_j,
                                    mask_f_j, mask_r_j, codes_j), dtype=float)
                Hb = H[_np.ix_(active, active)]
                try:
                    result['hess_inv'] = _np.linalg.inv(Hb)
                except _np.linalg.LinAlgError:
                    result['hess_inv'] = _np.linalg.pinv(Hb)
            except Exception:
                pass
            return result
        except Exception as e:
            if not _SL_QUIET:
                print(f"[JAX MXL masked] falling back: {e}")
            return None

    def get_loglik_gradient(self, betas, X, y, panel_info, draws,
                            drawstrans, weights, avail, batch_size):
        # {
        """ Fixed and random parameters are handled separately to
        speed up the estimation and the results are concatenated.
        """
        # Segregating initial values to fixed betas (Bf),
        # random beta means (Br_b)
        # for both non-transformed and transformed variables
        # and random beta cholesky factors (chol)

        self.betas = betas  # save to display later

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu:
            betas = dev.convert_array_gpu(self.betas)
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        beta_segment_names = ["Bf", "Br_b", "chol", "Br_w", "Bftrans",
                              "flmbda", "Brtrans_b", "Brtrans_w", "rlmda",
                              "het_mean_rv", "het_var_rv", "het_mean_rvtrans", "het_var_rvtrans",
                              "het_corr_cov"]
        extra_names, extra_counts = self._beta_segment_extra()
        # extra_names now only contains truly extra segments beyond the base list
        beta_segment_names = beta_segment_names + [n for n in extra_names if n not in beta_segment_names]
        iterations = [self.Kf, self.Kr, self.Kchol, self.Kbw, self.Kftrans,
                      self.Kftrans, self.Krtrans, self.Krtrans, self.Krtrans,
                      self.K_het_mean_rv, self.K_het_var_rv,
                      self.K_het_mean_rvtrans, self.K_het_var_rvtrans,
                      self.K_het_corr_cov]
        var_list = self.split_betas(betas, iterations, beta_segment_names)
        vals = list(var_list.values())
        (Bf, Br_b, chol, Br_w, Bftrans, flmbda, Brtrans_b, Brtrans_w, rlmda,
         het_mean_rv, het_var_rv, het_mean_rvtrans, het_var_rvtrans, het_corr_cov) = vals[:14]

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu:  # {
            # UNUSED: Bf = dev.convert_array_gpu(Bf)
            # UNUSED: Br_b = dev.convert_array_gpu(Br_b)
            chol = dev.convert_array_gpu(chol)
            Br_w = dev.convert_array_gpu(Br_w)
            Bftrans = dev.convert_array_gpu(Bftrans)
            flmbda = dev.convert_array_gpu(flmbda)
            Brtrans_b = dev.convert_array_gpu(Brtrans_b)
            Brtrans_w = dev.convert_array_gpu(Brtrans_w)
            rlmda = dev.convert_array_gpu(rlmda)
            if len(het_mean_rv) > 0: het_mean_rv = dev.convert_array_gpu(het_mean_rv)
            if len(het_var_rv) > 0: het_var_rv = dev.convert_array_gpu(het_var_rv)
            if len(het_mean_rvtrans) > 0: het_mean_rvtrans = dev.convert_array_gpu(het_mean_rvtrans)
            if len(het_var_rvtrans) > 0: het_var_rvtrans = dev.convert_array_gpu(het_var_rvtrans)
        # }
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        chol_mat = self.construct_chol_mat(chol, Br_w, Brtrans_w)

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu: chol_mat = dev.convert_array_gpu(chol_mat)
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        self.covariance_matrix = dev.np.matmul(chol_mat, np.transpose(chol_mat))
        self.covariance_matrix = dev.np.array(self.covariance_matrix)

        self.corr_mat = np.zeros_like(chol_mat)

        # Calculate the standard deviations from the diagonal elements of the covariance matrix
        diagonal_elements = np.diag(self.covariance_matrix)
        self.stdevs = np.sqrt(diagonal_elements)
        K = len(self.stdevs)
        for i in range(K):  # {
            for j in range(K):  # {
                if self.stdevs[i] == 0 or self.stdevs[j] == 0:
                    self.corr_mat[i, j] = np.nan  # or 0, or any value that is meaningful
                else:
                    self.corr_mat[i, j] = self.covariance_matrix[i, j] / (self.stdevs[i] * self.stdevs[j])
            # }
        # }

        full_batches = self.n_draws // self.batch_size  # Round down answer
        extra_batch = int(self.n_draws % self.batch_size != 0)  # Add one more batch if there's a remainder
        n_batches = full_batches + extra_batch

        N = self.N

        # _, gr_b, gr_w, pch = np.zeros((N, self.Kf)), np.zeros((N, self.Kr)), np.zeros((N, self.Kr)), []  # Batch data

        _ = np.zeros((N, self.Kf))  # CONCEPTUAL ERROR. WHY CREATE IF NO NAME?
        gr_b = np.zeros((N, self.Kr))
        gr_w = np.zeros((N, self.Kr))
        g_all = np.zeros((N, len(betas)))
        pch = []  # Batch data
        for batch in range(n_batches):
            # {
            a = batch * batch_size
            b = a + batch_size
            draws_batch = draws[:, :, a:b]
            drawstrans_batch = drawstrans[:, :, a:b]

            # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            if dev.using_gpu: draws_batch = dev.convert_array_gpu(draws_batch)
            # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            self.chol_mat, self.var_list = chol_mat, var_list
            p = self.compute_probabilities(betas, X, panel_info, draws_batch, drawstrans_batch, avail, var_list,
                                           chol_mat)

            # Joint probability estimation for panels data
            pch_batch = np.sum(y * p, axis=2)  # (N, P, R)
            pch_batch = self.prob_product_across_panels(pch_batch, panel_info)

            # Thresholds to avoid divide by zero warnings
            pch_batch = truncate_lower(pch_batch, min_comp_val)

            # Observed probability minus predicted probability
            ymp = y - p  # (N, P, J, R)

            # For fixed params
            # gradient = (Obs prob. minus predicted probability) * obs. var
            g = np.array([])
            if self.Kf != 0:  # {
                Xf = X[:, :, :, self.fxidx].astype(float)
                g = dev.cust_einsum('npjr,npjk -> nkr', ymp, Xf)
                g = np.mean(g * pch_batch[:, None, :], axis=2)  # Take the mean across the last axis
            # }

            # For random params w/ untransformed vars, two gradients will be
            # estimated: one for the mean and one for the s.d.
            # for mean: gr_b = (Obs. prob. minus pred. prob.)  * obs. var
            # for s.d.: gr_b = (Obs. prob. minus pred. prob.)  * obs. var * rand draw
            # if random coef. is lognormally dist:
            # gr_b = (obs. prob minus pred. prob.) * obs. var. * rand draw * der(R.V.)

            if self.Kr != 0:
                # {
                der = self.compute_derivatives(betas, draws_batch, chol_mat=chol_mat, betas_random=self.Br)
                Xr = X[:, :, :, self.rvidx].astype(float)
                gr_b = dev.cust_einsum('npjr,npjk -> nkr', ymp, Xr) * der  # (N, Kr, R)

                # For correlation parameters
                # for s.d.: gr_w = (Obs prob. minus predicted probability) * obs. var * random draw
                #
                # Map each covariance-block gradient column to the random
                # coefficient column and draw column it differentiates:
                #   chol entry (v, u) -> gr_b[:, v] * draws[:, u]  (row-major
                #   lower triangle within the correlated random variables)
                #   independent var k  -> gr_b[:, k] * draws[:, k]
                # The correlated variables are NOT necessarily the first
                # correlationLength random coefficients (partial/arbitrary
                # correlated sets), so use the actual positions.
                corr_local = getattr(self, 'rv_corr_local', None)
                indep_local = getattr(self, 'rv_indep_local', None)
                if corr_local is None or indep_local is None:
                    X_tril_idx, draws_tril_idx = np.tril_indices(self.correlationLength)
                    range_var = list(range(self.correlationLength, self.Kr))
                    draws_tril_idx = np.concatenate((draws_tril_idx, range_var))
                    X_tril_idx = np.concatenate((X_tril_idx, range_var))
                else:
                    _rows, _cols = [], []
                    for _j, _v in enumerate(corr_local):
                        for _c in range(_j + 1):
                            _rows.append(_v)
                            _cols.append(corr_local[_c])
                    for _k in indep_local:
                        _rows.append(_k)
                        _cols.append(_k)
                    X_tril_idx = np.asarray(_rows)
                    draws_tril_idx = np.asarray(_cols)

                draws_tril_idx = draws_tril_idx.astype(int)
                X_tril_idx = X_tril_idx.astype(int)

                # d Br_k / d(chol[k, u]) = scale_k * draws_u when variance
                # heterogeneity is active (the objective scales row k of
                # chol @ draws), so the multiplier carries the scale of the
                # ROW variable and the raw draw of the column variable.
                scale_row = np.ones((N, self.Kr))
                if self.K_het_var_rv > 0:
                    for _hi, (_rv, _col) in enumerate(zip(self.het_var_rv_idx,
                                                         self.het_var_rv_cols)):
                        _cov = np.mean(X[:, :, :, _col], axis=(1, 2))
                        scale_row[:, _rv] = np.exp(het_var_rv[_hi] * _cov)

                # Perform element-wise multiplication of two subsets of arrays,
                gr_w = (gr_b[:, X_tril_idx, :]
                        * draws_batch[:, draws_tril_idx, :]
                        * scale_row[:, X_tril_idx, None])  # (N,P,Kr,R)

                gr_b = np.mean(gr_b * pch_batch[:, None, :], axis=2)  # (N,Kr)
                gr_w = np.mean(gr_w * pch_batch[:, None, :], axis=2)  # (N,Kr)

                # Gradient for fixed and random params
                g = np.concatenate((g, gr_b, gr_w), axis=1) if g.size \
                    else np.concatenate((gr_b, gr_w), axis=1)
            # }

            # For Box-Cox vars
            if len(self.transvars) > 0:
                # {
                if self.Kftrans:  # with fixed params
                    # {
                    Xftrans = X[:, :, :, self.fxtransidx].astype(float)
                    Xftrans_lmda = self.trans_func(Xftrans, flmbda)
                    Xftrans_lmda = truncate(Xftrans_lmda, -max_comp_val, max_comp_val)

                    gftrans = dev.cust_einsum('npjr,npjk -> nkr', ymp, Xftrans_lmda)  # (N, Kf, R)
                    # for the lambda param

                    der_Xftrans_lmda = self.transform_deriv(Xftrans, flmbda)
                    der_Xftrans_lmda = truncate(der_Xftrans_lmda, -max_comp_val, max_comp_val)
                    der_Xftrans_lmda[np.isnan(der_Xftrans_lmda)] = min_comp_val

                    der_Xbftrans = dev.np.einsum('npjk,k -> njk', der_Xftrans_lmda, Bftrans)

                    gftrans_lmda = dev.np.einsum('npjr,njk -> nkr', ymp, der_Xbftrans)
                    gftrans = np.mean(gftrans * pch_batch[:, None, :], axis=2)
                    gftrans_lmda = np.mean(gftrans_lmda * pch_batch[:, None, :], axis=2)

                    g = np.concatenate((g, gftrans, gftrans_lmda), axis=1) if g.size \
                        else np.concatenate((gftrans, gftrans_lmda), axis=1)
                # }

                if self.Krtrans:
                    # {
                    # for rand parameters
                    # for mean: (obs prob. min pred. prob)*obs var * deriv rand coef
                    # if rand coef is lognormally distributed:
                    # gr_b = (obs prob minus pred. prob) * obs. var * rand draw * der(RV)
                    temp_chol = chol_mat if chol_mat.size != 0 else np.diag(Brtrans_w)
                    dertrans = self.compute_derivatives(betas, draws=drawstrans_batch,
                                                        distr=self.rvtransdist, chol_mat=temp_chol, K=self.Krtrans,
                                                        trans=True, betas_random=self.Brtrans)

                    Xrtrans = X[:, :, :, self.rvtransidx].astype(float)
                    Xrtrans_lmda = self.trans_func(Xrtrans, rlmda)

                    Brtrans = Brtrans_b[None, :, None] + drawstrans_batch[:, 0:self.Krtrans, :] * Brtrans_w[None, :, None]
                    Brtrans = self.draws_generator.apply_distribution(Brtrans, self.rvtransdist)

                    grtrans_b = dev.cust_einsum('npjr,npjk -> nkr', ymp, Xrtrans_lmda) * dertrans

                    # for s.d. (obs - pred) * obs var * der rand coef * rd draw
                    # (draws carry the variance-heterogeneity scale when active)
                    drawstrans_for_w = drawstrans_batch
                    if self.K_het_var_rvtrans > 0:
                        drawstrans_for_w = drawstrans_batch.copy()
                        for _hi, (_rv, _col) in enumerate(zip(
                                self.het_var_rvtrans_idx,
                                self.het_var_rvtrans_cols)):
                            _cov = np.mean(X[:, :, :, _col], axis=(1, 2))
                            drawstrans_for_w[:, _rv, :] *= np.exp(
                                het_var_rvtrans[_hi] * _cov)[:, None]
                    grtrans_w = dev.cust_einsum('npjr,npjk -> nkr', ymp, Xrtrans_lmda) * dertrans * drawstrans_for_w

                    # for the lambda param. gradient = (obs - pred) * deriv x_lambda * beta
                    der_Xrtrans_lmda = self.transform_deriv(Xrtrans, rlmda)

                    der_Xrtrans_lmda = truncate(der_Xrtrans_lmda, -max_comp_val, max_comp_val)

                    # TODO? KEEP an eye out ... 4, 3, 5 ...  no cust_einsum

                    der_Xbrtrans = dev.np.einsum('npjk, nkr -> npjkr', der_Xrtrans_lmda, Brtrans)  # (N, P, J, K, R)
                    grtrans_lmda = dev.np.einsum('npjr, npjkr -> nkr', ymp, der_Xbrtrans)  # (N, Krtrans, R)
                    grtrans_b = (grtrans_b * pch_batch[:, None, :]).mean(axis=2)  # (N,Kr)
                    grtrans_w = (grtrans_w * pch_batch[:, None, :]).mean(axis=2)  # (N,Kr)
                    grtrans_lmda = (grtrans_lmda * pch_batch[:, None, :]).mean(axis=2)  # (N,Kr)

                    g = np.concatenate((g, grtrans_b, grtrans_w, grtrans_lmda), axis=1) if g.size \
                        else np.concatenate((grtrans_b, grtrans_w, grtrans_lmda), axis=1)
                # }
            # }

            # Heterogeneity gradients
            # Mean heterogeneity: dL/d(het_mean) = (y-p) * X_r * covariate_mean
            # Variance heterogeneity: dL/d(het_var) = (y-p) * X_r * draw * covariate_mean * scale
            if self.K_het_mean_rv > 0 and self.Kr > 0:
                gr_het_mean_rv = np.zeros((N, self.K_het_mean_rv))
                for idx, (rv_idx, col) in enumerate(zip(self.het_mean_rv_idx, self.het_mean_rv_cols)):
                    het_cov = X[:, :, :, col]
                    het_cov_mean = np.mean(het_cov, axis=(1, 2))  # (N,)
                    # Gradient: (y-p) * X_r * covariate_mean
                    rv_col = self.rv_col_idx[rv_idx]
                    x_r = X[:, :, :, rv_col:rv_col+1]  # (N, P, J, 1)
                    grad = dev.np.einsum('npjr,npjk -> nr', ymp, x_r) * het_cov_mean[:, None]  # (N, R)
                    gr_het_mean_rv[:, idx] = np.mean(grad * pch_batch, axis=1)  # (N,)

                g = np.concatenate((g, gr_het_mean_rv), axis=1) if g.size else gr_het_mean_rv

            if self.K_het_var_rv > 0 and self.Kr > 0:
                gr_het_var_rv = np.zeros((N, self.K_het_var_rv))
                # d Br / d het_var = (chol @ draws) * scale * covariate,
                # then through the mixing distribution (ln/tn) via `der`.
                tmp_r = np.matmul(chol_mat[:self.Kr, :self.Kr], draws_batch) \
                    if chol_mat.size else draws_batch[:, :self.Kr, :]
                for idx, (rv_idx, col) in enumerate(zip(self.het_var_rv_idx, self.het_var_rv_cols)):
                    het_cov = X[:, :, :, col]
                    het_cov_mean = np.mean(het_cov, axis=(1, 2))
                    scale = np.exp(het_var_rv[idx] * het_cov_mean)
                    rv_col = self.rv_col_idx[rv_idx]
                    x_r = X[:, :, :, rv_col:rv_col+1]
                    deriv = (tmp_r[:, rv_idx, :] * scale[:, None]
                             * het_cov_mean[:, None] * der[:, rv_idx, :])
                    grad = dev.np.einsum('npjr,npjk -> nr', ymp, x_r) * deriv
                    gr_het_var_rv[:, idx] = np.mean(grad * pch_batch, axis=1)

                g = np.concatenate((g, gr_het_var_rv), axis=1) if g.size else gr_het_var_rv

            if self.K_het_mean_rvtrans > 0 and self.Krtrans > 0:
                gr_het_mean_rvtrans = np.zeros((N, self.K_het_mean_rvtrans))
                for idx, (rv_idx, col) in enumerate(zip(self.het_mean_rvtrans_idx, self.het_mean_rvtrans_cols)):
                    het_cov = X[:, :, :, col]
                    het_cov_mean = np.mean(het_cov, axis=(1, 2))
                    rv_col = self.rvtrans_col_idx[rv_idx]
                    x_r = X[:, :, :, rv_col:rv_col+1]
                    grad = dev.np.einsum('npjr,npjk -> nr', ymp, x_r) * het_cov_mean[:, None]
                    gr_het_mean_rvtrans[:, idx] = np.mean(grad * pch_batch, axis=1)

                g = np.concatenate((g, gr_het_mean_rvtrans), axis=1) if g.size else gr_het_mean_rvtrans

            if self.K_het_var_rvtrans > 0 and self.Krtrans > 0:
                gr_het_var_rvtrans = np.zeros((N, self.K_het_var_rvtrans))
                for idx, (rv_idx, col) in enumerate(zip(self.het_var_rvtrans_idx, self.het_var_rvtrans_cols)):
                    het_cov = X[:, :, :, col]
                    het_cov_mean = np.mean(het_cov, axis=(1, 2))
                    scale = np.exp(het_var_rvtrans[idx] * het_cov_mean)
                    rv_col = self.rvtrans_col_idx[rv_idx]
                    x_r = X[:, :, :, rv_col:rv_col+1]
                    # d Brtrans / d het_var = draw * scale * sd * covariate,
                    # then through the mixing distribution via `dertrans`.
                    deriv = (drawstrans_batch[:, rv_idx, :] * scale[:, None]
                             * Brtrans_w[rv_idx] * het_cov_mean[:, None]
                             * dertrans[:, rv_idx, :])
                    grad = dev.np.einsum('npjr,npjk -> nr', ymp, x_r) * deriv
                    gr_het_var_rvtrans[:, idx] = np.mean(grad * pch_batch, axis=1)

                g = np.concatenate((g, gr_het_var_rvtrans), axis=1) if g.size else gr_het_var_rvtrans

            # Correlated heterogeneity covariance gradients
            # For now, compute gradient numerically (placeholder)
            if self.K_het_corr_cov > 0:
                gr_het_corr_cov = np.zeros((N, self.K_het_corr_cov))
                # Placeholder: gradient w.r.t. heterogeneity covariance parameters
                # This requires derivative through the random draw generation
                # which is complex. For now, set to zero.
                g = np.concatenate((g, gr_het_corr_cov), axis=1) if g.size else gr_het_corr_cov

            # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            if dev.using_gpu:
                g, pch_batch = dev.to_cpu(g), dev.to_cpu(pch_batch)
            # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

            pch.append(pch_batch)
            g_all += g
        # }

        pch = np.concatenate(pch, axis=-1)
        lik = pch.mean(axis=1)  # (N,)
        loglik = np.log(lik)
        if weights is not None: loglik = loglik * weights
        loglik = loglik.sum()

        penalty = self.regularize_loglik(betas)
        loglik = loglik - penalty
        loglik = loglik - self.regularize_l1_loglik(betas)

        self.total_fun_eval += 1

        g = g_all

        # Perform element-wise division after adding a new dimension to lik.
        # Divide each element in the g array by the corresponding element in the lik array.
        g = g / lik[:, np.newaxis]

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Update gradient
        # Note: The use of [:, None] creates a new axis to ensure proper broadcasting.
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if weights is not None:  # {
            if weights.ndim == 1:
                g *= weights[:, None]  # Convert 1D weights to column vector
            elif weights.ndim >= 2:
                g *= weights[:, 0][:, None]  # Use only the first column and convert to column vector
        # }

        g = np.sum(g, axis=0) / n_batches  # (K, )
        g = g - self.regularize_l1_grad(betas)
        # L2 ridge penalty gradient: the objective subtracts
        # reg_penalty * sum(betas^2) from the log-likelihood, so its
        # derivative (2 * reg_penalty * betas) must be included too.
        if self.reg_penalty:
            g = g - 2.0 * self.reg_penalty * betas
        self.gtol_res = np.linalg.norm(g, ord=np.inf)

        result = (-loglik,)  # Create a tuple
        if self.return_grad: result += (-g,)  # Enlarge the tuple and add '-g'
        return result

    # }


    ''' ---------------------------------------------------------- '''
    ''' Function                                                   '''
    ''' ---------------------------------------------------------- '''
    def prob_product_across_panels(self, pch, panel_info):
    # {
        if not np.all(panel_info):  # If panels unbalanced. Not all ones
        # {
            idx = panel_info == 0
            for i in range(pch.shape[2]):
                pch[:, :, i][idx] = 1  # Multiply by one when unbalanced
        # }
        pch = pch.prod(axis=1)  # (N,R)
        truncate_lower(pch, min_comp_val)  # i.e., pch[pch == 0] = min_comp_val
        return pch  # (N,R)
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function.                                                  '''
    ''' ---------------------------------------------------------- '''

    def _get_loglik_gradient(self, betas):  # {
        result = self.get_loglik_gradient(betas, self.X, self.y, self.panel_info,
                                          self.draws, self.drawstrans, self.weights, self.avail, self.batch_size)
        return result
    # }

    ''' ------------------------------------------------------------- '''
    ''' Function. Conduct validations specific for mixed logit models '''
    ''' ------------------------------------------------------------- '''
    def model_specific_validations(self, randvars, Xnames):  # {
        if randvars is None:
            raise ValueError("The randvars parameter is required for Mixed "
                             "Logit estimation")
        # A random variable name is valid if it appears directly in the design
        # column names (alternative-specific attributes) OR it is an
        # individual-specific variable / intercept whose (J-1) alternative-specific
        # columns appear as "<name>.<alt>" (and, for the sd terms, "sd.<name>.<alt>").
        xnames_set = set(str(x) for x in Xnames)
        valid_isvars = set(str(v) for v in getattr(self, "isvars", []))
        # Also check original varnames
        orig_varnames_set = set(str(v) for v in getattr(self, "varnames", []))
        for key in randvars.keys():
            if key in xnames_set or key in valid_isvars or key in orig_varnames_set:
                continue
            if any(str(x) == key or str(x).startswith(key + ".") for x in Xnames):
                continue
            print(f'randvars:{randvars}')
            print(f'XNames:{Xnames}')
            raise ValueError("Some variable names in randvars were not found "
                             "in the list of variable names")
        
        # Validate distributions - support both simple string format and dict format
        valid_dists = ["n", "ln", "nln", "t", "tn", "u"]
        for var, spec in randvars.items():
            if isinstance(spec, dict):
                dist = spec.get('dist', 'n')
            else:
                dist = spec
            if dist not in valid_dists:
                raise ValueError(f"Wrong mixing distribution '{dist}' for variable '{var}' in randvars. "
                                 f"Accepted distributions are {valid_dists}")
    # }


    ''' --------------------------------------------------------------------------- '''
    ''' Function. Balance panels if necessary and produce a new version of X and y  '''
    ''' If panels are already balanced, the same X and y are returned. This routine '''
    ''' also keeps track of the panels that needed balancing                        '''
    ''' --------------------------------------------------------------------------- '''
    def balance_panels(self, X, y, avail, panels):
    #
        _, J, K = X.shape
        _, p_obs = np.unique(panels, return_counts=True)
        p_obs = (p_obs / J).astype(int)
        N = len(p_obs)  # This is the new N after accounting for panels
        P = np.max(p_obs)  # panels length for all records
        NP = N * P
        if not np.all(p_obs[0] == p_obs):  # Balancing needed
        # {
            y = y.reshape(X.shape[0], J, 1) if y is not None else None
            avail = avail.reshape(X.shape[0], J, 1) if avail is not None else None
            Xbal = np.zeros((NP, J, K))
            ybal = np.zeros((NP, J, 1))
            availbal = np.zeros((NP, J, 1))
            panel_info = np.zeros((N, P))
            cum_p = 0  # Cumulative sum of n_obs at every iteration
            for n, p in enumerate(p_obs):  # {
                # Copy data from original to balanced version
                nP = n * P
                Xbal[nP:nP + p, :, :] = X[cum_p:cum_p + p, :, :]
                ybal[nP:nP + p, :, :] = y[cum_p:cum_p + p, :, :] if y is not None else None  # TODO? predict mode in xlogit?
                availbal[nP:nP + p, :, :] = avail[cum_p:cum_p + p, :, :] if avail is not None else None
                panel_info[n, :p] = np.ones(p)
                cum_p += p
            # }
        # }
        else:  # No balancing needed
        # {
            Xbal, ybal, availbal = X, y, avail
            panel_info = np.ones((N, P))
        # }
        ybal = ybal if y is not None else None
        availbal = availbal if avail is not None else None
        return Xbal, ybal, availbal, panel_info
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function. This code segments the betas array into different 
        parts and stores these parts in var_list under keys from 
        beta_segment_names. The segmentation is based on the values
        in iterations, which determine the size of each segment '''
    ''' ---------------------------------------------------------- '''

    def split_betas(self, betas, iterations, beta_segment_names):
        var_list = {}
        i = 0
        for count, iteration in enumerate(iterations):
            # {
            var_list[beta_segment_names[count]] = betas[i:i + iteration]
            i += iteration
        # }
        return var_list

    ''' -------------------------------------------------------------------- '''
    ''' Function. Compute Cholesky matrix for the variance-covariance matrix '''
    ''' -------------------------------------------------------------------- '''

    def construct_chol_mat(self, chol, Br_w, Brtrans_w):
        # {

        # Note: All random variables not included in correlation will only
        # have their standard deviation computed
        # NOTE: fairly poorly written function, made to patch bugs

        chol_mat = np.zeros((self.correlationLength, self.correlationLength))
        indices = np.tril_indices(self.correlationLength)

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu:
            chol = dev.to_cpu(chol)
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        chol_mat[indices] = chol
        Kr_all = self.Kr + self.Krtrans
        chol_mat_temp = np.zeros((Kr_all, Kr_all))

        # TODO: Structure ... Kr first, Krtrans last, fill in for correlations
        # TODO: could do better
        rv_count, rv_count_all, rv_trans_count, rv_trans_count_all, chol_count = 0, 0, 0, 0, 0
        corr_indices = []

        # TODO: another bugfix

        # Assumption: Order rvtrans correctly beforehand
        num_corr_rvtrans = 0  # Correlated

        for ii, var in enumerate(self.varnames):
            if self.rvtransidx[ii]:
                if hasattr(self, 'correlated_vars') and self.correlated_vars:
                    if hasattr(self.correlated_vars, 'append'):
                        if var in self.correlated_vars:
                            num_corr_rvtrans += 1
                    else:
                        num_corr_rvtrans += 1

        num_rvtrans_total = self.Krtrans + num_corr_rvtrans
        offset_varnames = getattr(self, 'Xnames', self.varnames)  # Set as self.Xnames or self.varnames
        ordered_varnames = getattr(self, 'ordered_varnames', self.varnames)

        inter_offset = 0
        if not hasattr(self, 'class_params_spec'):
            inter_offset = len([x for x in offset_varnames if 'inter' in x]) - 1
            inter_offset = 0
        if inter_offset < 0:
            inter_offset = 0

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # ZEKES ERROR HANDLING. DO NOT ADD ANOTHER INTER_OFFSET
        # if 'intercept' in self.varnames and inter_offset > 1:
        #    inter_offset -= 1
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        for ii, var in enumerate(ordered_varnames):  # TODO: BUGFIX
            # {

            if str(var) == 'intercept': continue  # ERROR HANDLING. SKIP REMAINING STEPS

            ii_offset = ii + inter_offset
            is_correlated = False

            if hasattr(self, 'correlated_vars') and self.correlated_vars:
                if hasattr(self.correlated_vars, 'append'):
                    if var in self.correlated_vars:
                        is_correlated = True
                else:
                    is_correlated = True

            if self.rvidx[ii_offset]:  # {
                if is_correlated:
                    rv_val = chol[chol_count]
                else:
                    if rv_count >= len(Br_w):
                        raise IndexError(
                            f"construct_chol_mat: rv_count={rv_count} out of bounds "
                            f"for Br_w (size {len(Br_w)}). "
                            f"var={var}, Kr={self.Kr}, Kbw={self.Kbw}, "
                            f"correlated_vars={getattr(self, 'correlated_vars', None)}"
                        )
                    rv_val = Br_w[rv_count]
                chol_mat_temp[rv_count_all, rv_count_all] = rv_val
                rv_count_all += 1
                if is_correlated:
                    chol_count += 1
                else:
                    rv_count += 1
            # }

            if self.rvtransidx[ii_offset]:  # {
                is_correlated = False
                if hasattr(self, 'correlated_vars') and self.correlated_vars:
                    if hasattr(self.correlated_vars, 'append'):
                        if var in self.correlated_vars:
                            is_correlated = True
                    else:
                        is_correlated = True
                if is_correlated:
                    rv_val = chol[chol_count]
                else:
                    if rv_trans_count >= len(Brtrans_w):
                        raise IndexError(
                            f"construct_chol_mat: rv_trans_count={rv_trans_count} out of bounds "
                            f"for Brtrans_w (size {len(Brtrans_w)}). "
                            f"var={var}, Krtrans={self.Krtrans}"
                        )
                    rv_val = Brtrans_w[rv_trans_count]
                chol_mat_temp[-num_rvtrans_total + rv_trans_count_all, -num_rvtrans_total + rv_trans_count_all] = rv_val
                rv_trans_count_all += 1

                if is_correlated:
                    chol_count += 1
                else:
                    rv_trans_count += 1
            # }

            if hasattr(self, 'correlated_vars') and hasattr(self.correlated_vars, 'append') \
                    and var in self.correlated_vars:  # {
                tot = rv_count_all - 1 if self.rvidx[ii_offset] else Kr_all - num_rvtrans_total + rv_trans_count_all - 1
                corr_indices.append(tot)
            # }

        # }

        # Create pairs of indices representing correlations between different features.
        if hasattr(self, 'correlated_vars') and isinstance(self.correlated_vars, bool) and self.correlated_vars:
            # {
            feature_indices = np.arange(self.Kr)

            # Generate all combinations of feature indices (excluding correlations)
            corr_pairs = list(itertools.combinations(feature_indices, 2))

            # Add correlations (pairs with the same index)
            corr_pairs += [(i, i) for i in feature_indices]
        # }
        else:
            # {
            # Generate all combinations of feature indices
            corr_pairs = list(itertools.combinations(corr_indices, 2))

            # Add correlations (pairs with the same index)
            corr_pairs += [(idx, idx) for ii, idx in enumerate(corr_indices)]
        # }

        reversed_corr_pairs = [tuple(reversed(pair)) for ii, pair in enumerate(corr_pairs)]
        reversed_corr_pairs.sort(key=lambda x: x[0])

        chol_count = 0

        for _, corr_pair in enumerate(reversed_corr_pairs):
            # {
            # lower cholesky matrix
            chol_mat_temp[corr_pair] = chol[chol_count]
            chol_count += 1
        # }

        #####################################################################
        # UNUSED CODE:
        # # add non-correlated random variables to cholesky matrix
        # num_rand_noncorr = sel f.Kr - self.correlationLength
        # for i in range(num_rand_noncorr):
        #     chol_mat_temp[i, i] = Br_w[i]
        # # add non-correlated transformed random variables to cholesky matrix
        # for i in range(self.Krtrans):
        #     chol_mat_temp[i + num_rand_noncorr, i + num_rand_noncorr] = Brtrans_w[i]

        # if self.correlationLength > 0:
        #     chol_mat_temp[-self.correlationLength:, -self.correlationLength:] = \
        #         chol_mat
        ######################################################################

        chol_mat = chol_mat_temp
        return chol_mat
    # }

    def compute_probabilities(self, betas, X, panel_info, draws, drawstrans,
                          avail, var_list, chol_mat):
        # {
        # Creating random coeffs using Br_b, cholesky matrix and random draws
        # Estimating the linear utility specification (U = sum of Xb)
        vals = list(var_list.values())
        (Bf, Br_b, chol, Br_w, Bftrans, flmbda, Brtrans_b, Brtrans_w, rlmda,
         het_mean_rv, het_var_rv, het_mean_rvtrans, het_var_rvtrans, het_corr_cov) = vals[:14]

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        # CONVERSIONS
        if dev.using_gpu:  # {
            Bf = dev.convert_array_gpu(Bf)
            Br_b = dev.convert_array_gpu(Br_b)
            chol = dev.convert_array_gpu(chol)  # NOT USED?
            Br_w = dev.convert_array_gpu(Br_w)  # NOT USED?
            Bftrans = dev.convert_array_gpu(Bftrans)
            flmbda = dev.convert_array_gpu(flmbda)
            Brtrans_b = dev.convert_array_gpu(Brtrans_b)
            Brtrans_w = dev.convert_array_gpu(Brtrans_w)
            rlmda = dev.convert_array_gpu(rlmda)
            if len(het_mean_rv) > 0: het_mean_rv = dev.convert_array_gpu(het_mean_rv)
            if len(het_var_rv) > 0: het_var_rv = dev.convert_array_gpu(het_var_rv)
            if len(het_mean_rvtrans) > 0: het_mean_rvtrans = dev.convert_array_gpu(het_mean_rvtrans)
            if len(het_var_rvtrans) > 0: het_var_rvtrans = dev.convert_array_gpu(het_var_rvtrans)
        # }
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        # INITIALISE
        XBf = np.zeros((self.N, self.P, self.J))
        XBr = np.zeros((self.N, self.P, self.J, self.batch_size))  # NOT USED?
        V = np.zeros((self.N, self.P, self.J, self.batch_size))  # NOT USED?

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu:  # {
            XBf = dev.convert_array_gpu(XBf)
            XBr = dev.convert_array_gpu(XBr)
            V = dev.convert_array_gpu(V)
        # }
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        if self.Kf != 0:
            Xf = X[:, :, :, self.fxidx]
            XBf = dev.cust_einsum('npjk,k -> npj', Xf, Bf).astype(float)

        if self.Kr != 0:  # {
            tmp = dev.np.matmul(chol_mat[:self.Kr, :self.Kr], draws)

            # Apply variance heterogeneity to the latent draws BEFORE forming
            # Br: scale each affected row of chol @ draws by
            # exp(het_var * covariate). Scaling `tmp` after `Br = Br_b + tmp`
            # would be a no-op (the addition already copied).
            if self.K_het_var_rv > 0:
                for idx, (rv_idx, col) in enumerate(zip(self.het_var_rv_idx, self.het_var_rv_cols)):
                    het_cov = X[:, :, :, col]
                    het_cov_mean = np.mean(het_cov, axis=(1, 2))
                    scale = np.exp(het_var_rv[idx] * het_cov_mean)  # (N,)
                    tmp[:, rv_idx:rv_idx+1, :] *= scale[:, None, None]

            Br = Br_b[None, :, None] + tmp
            # Br_b has dimension (Kr) and tmp has dimension (N, Kr, P*J)
            # First reshape Br, creating a first and third dimension so dimension (1, Kr, 1)
            # Second, compute Br[i,:,j] = tmp[i,:,j] + Br_b[0,:,0]  for all values of i and j

            # Apply mean heterogeneity: Br += het_mean_rv * covariates
            if self.K_het_mean_rv > 0:
                # Build heterogeneity contribution for each random variable
                for idx, (rv_idx, col) in enumerate(zip(self.het_mean_rv_idx, self.het_mean_rv_cols)):
                    het_cov = X[:, :, :, col]  # (N, P, J)
                    # Average across alternatives and panels for individual-level covariate
                    het_cov_mean = np.mean(het_cov, axis=(1, 2))  # (N,)
                    Br[:, rv_idx:rv_idx+1, :] += het_mean_rv[idx] * het_cov_mean[:, None, None]

            # apply_distribution - rvdist is already filtered in generate_draws()
            Br = self.draws_generator.apply_distribution(Br, self.rvdist)
            self.Br = Br  # save Br to use later
            Xr = X[:, :, :, self.rvidx]
            XBr = dev.cust_einsum('npjk,nkr -> npjr', Xr, Br).astype(float)  # (N, P, J, R)
            V = XBf[:, :, :, None] + XBr  # Add an extra dimension to XBf and then add XBr
        else:
            self.Br = Br_b[None, :, None]

        #  transformations for variables with fixed coeffs
        if self.Kftrans != 0:
            # {
            Xftrans = X[:, :, :, self.fxtransidx]
            Xftrans_lmda = self.trans_func(Xftrans, flmbda)  # applying transformation
            Xftrans_lmda = truncate(Xftrans_lmda, -max_comp_val, max_comp_val)
            Xbf_trans = dev.cust_einsum('npjk,k -> npj', Xftrans_lmda,
                                        Bftrans)  # Estimating the linear utility specificiation (U = sum XB)
            V += Xbf_trans[:, :, :, None]  # Combining utilities
        # }

        if self.Krtrans != 0:
            # {
            # Apply variance heterogeneity for transformed random vars BEFORE
            # forming Brtrans (scaling after the sum would be a no-op). Copy
            # first: drawstrans is a view into the model's draw array and the
            # in-place scaling would otherwise compound across evaluations.
            if self.K_het_var_rvtrans > 0:
                drawstrans = drawstrans.copy()
                for idx, (rv_idx, col) in enumerate(zip(self.het_var_rvtrans_idx, self.het_var_rvtrans_cols)):
                    het_cov = X[:, :, :, col]
                    het_cov_mean = np.mean(het_cov, axis=(1, 2))
                    scale = np.exp(het_var_rvtrans[idx] * het_cov_mean)
                    drawstrans[:, rv_idx:rv_idx+1, :] *= scale[:, None, None]

            Brtrans = Brtrans_b[None, :, None] + drawstrans[:, 0:self.Krtrans, :] * Brtrans_w[None, :,
                                                                                    None]  # Creating the random coeffs

            # Apply mean heterogeneity for transformed random vars
            if self.K_het_mean_rvtrans > 0:
                for idx, (rv_idx, col) in enumerate(zip(self.het_mean_rvtrans_idx, self.het_mean_rvtrans_cols)):
                    het_cov = X[:, :, :, col]
                    het_cov_mean = np.mean(het_cov, axis=(1, 2))
                    Brtrans[:, rv_idx:rv_idx+1, :] += het_mean_rvtrans[idx] * het_cov_mean[:, None, None]

            Brtrans = self.draws_generator.apply_distribution(Brtrans, self.rvtransdist)
            self.Brtrans = Brtrans  # saving for later use
            Xrtrans = X[:, :, :, self.rvtransidx]
            Xrtrans_lmda = self.trans_func(Xrtrans, rlmda)  # applying transformation
            Xrtrans_lmda = truncate(Xrtrans_lmda, -max_comp_val, max_comp_val)
            Xbr_trans = dev.cust_einsum('npjk,nkr -> npjr', Xrtrans_lmda, Brtrans).astype(float) # (N, P, J, R)
            V += Xbr_trans  # Combining utilities
        # }

        # Thresholds to avoid overflow warnings
        V = truncate(V, -max_exp_val, max_exp_val)
        if self.softmax_r:
            # Apply numerical stability by subtracting the max value for each choice set
            V = V - dev.np.max(V, axis=2, keepdims=True)
        V = np.array(V)
        try:
            eV = np.exp(V)  # Compute eV = exp(V)
        except:
            print('inspect above')

        # Exponent of the utility function for the logit formula
        if avail is not None:  # {
            ref = avail[:, :, :, None] if self.panels is not None else avail[:, None, :,
                                                                       None]  # Accommodate availability of alts
            eV = eV * ref
        # }
        # FIXME I belueve this should be axis 3
        sum_eV = dev.np.sum(eV, axis=2, keepdims=True)
        sum_eV = truncate_lower(sum_eV, min_comp_val)  # Truncate elements below min_comp_val

        p = np.divide(eV, sum_eV, out=np.zeros_like(eV))
        if self.save_fitted_params:
            self.p = p  # save

        return p
    # }

    def balance_panels(self, X, y, avail, panels):
    #
        _, J, K = X.shape
        _, p_obs = np.unique(panels, return_counts=True)
        p_obs = (p_obs / J).astype(int)
        N = len(p_obs)  # This is the new N after accounting for panels
        P = np.max(p_obs)  # panels length for all records
        NP = N * P
        if not np.all(p_obs[0] == p_obs):  # Balancing needed
        # {
            y = y.reshape(X.shape[0], J, 1) if y is not None else None
            avail = avail.reshape(X.shape[0], J, 1) if avail is not None else None
            Xbal = np.zeros((NP, J, K))
            ybal = np.zeros((NP, J, 1))
            availbal = np.zeros((NP, J, 1))
            panel_info = np.zeros((N, P))
            cum_p = 0  # Cumulative sum of n_obs at every iteration
            for n, p in enumerate(p_obs):  # {
                # Copy data from original to balanced version
                nP = n * P
                Xbal[nP:nP + p, :, :] = X[cum_p:cum_p + p, :, :]
                ybal[nP:nP + p, :, :] = y[cum_p:cum_p + p, :, :] if y is not None else None  # TODO? predict mode in xlogit?
                availbal[nP:nP + p, :, :] = avail[cum_p:cum_p + p, :, :] if avail is not None else None
                panel_info[n, :p] = np.ones(p)
                cum_p += p
            # }
        # }
        else:  # No balancing needed
        # {
            Xbal, ybal, availbal = X, y, avail
            panel_info = np.ones((N, P))
        # }
        ybal = ybal if y is not None else None
        availbal = availbal if avail is not None else None
        return Xbal, ybal, availbal, panel_info
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function. Reshaping approach (mirrors mixed_logit.MixedLogit) '''
    ''' ---------------------------------------------------------- '''
    def reshape(self, arr, panels):
        N, P, J = self.N, self.P, self.J
        if panels is None:
            arr = arr.reshape(N, J)
        else:
            # Same logic as _balance_panels: pad per-panel observation counts
            _, p_obs = np.unique(panels, return_counts=True)
            p_obs //= J
            _temp = np.zeros((N, P, J))
            cum_p = 0
            for n, p in enumerate(p_obs):
                _temp[n, 0:p, :] = arr[cum_p: cum_p + (p * J)].reshape((1, p, J))
                cum_p += p
            arr = _temp.reshape((N, P, J))
        return arr

    ''' ---------------------------------------------------------- '''
    ''' Function. Logic to reshape weights according to panels     '''
    ''' ---------------------------------------------------------- '''
    def reshape_weights(self, weights, panels):
        scale = self.N / np.sum(weights)  # Normalize weights to sum to N
        weights = weights * scale
        return self.reshape(weights, panels)

    ''' ---------------------------------------------------------- '''
    ''' Function. Logic to reshape avail according to panels       '''
    ''' ---------------------------------------------------------- '''
    def reshape_avail(self, avail, panels):
        return self.reshape(avail, panels)

    ''' -------------------------------------------------------------------- '''
    ''' Function. Compute the derivatives based on the mixing distributions  '''
    ''' note: (betas_random[:, k, :] > 0) creates a boolean mask and         '''
    ''' astype(int) converts any valure True to 1 and any False to zero      '''
    ''' -------------------------------------------------------------------- '''
    def compute_derivatives(self, betas, draws, distr=None, K=None,
                            chol_mat=None, trans=False, betas_random=None):
    # {
        N, R = draws.shape[0], draws.shape[2]
        Kr = K if K else self.Kr
        der = dev.np.ones((N, Kr, R))
        distr = distr if distr else self.rvdist
        if any(set(distr).intersection(['ln', 'nln', 'tn'])):  # ln / negative-ln / tn
        # {
            for k, distr_k in enumerate(distr):  # {
                if distr_k in ('ln', 'nln'):
                    # ln: Br = exp(z); nln: Br = -exp(z). In both cases
                    # d Br / d z = Br, so the derivative is the coefficient.
                    der[:, k, :] = betas_random[:, k, :]
                elif distr_k == 'tn':  # Set any element > 0 as 1 and 0 otherwise
                    der[:, k, :] = (betas_random[:, k, :] > 0).astype(int)
            # }
        # }
        return der
    # }



    def transform_betas(self, betas, draws, index=None, trans=False, chol_mat=None):  # {
        if trans:
            betas_fixed, betas_random = self.compute_betas_trans(betas, draws, index)
        else:
            betas_fixed, betas_random = self.compute_betas_not_trans(betas, draws, index, chol_mat)
        return betas_fixed, betas_random
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function                                                   '''
    ''' ---------------------------------------------------------- '''

    def compute_fitted_params(self, y, p, panel_info, Br):
        # {

        if Br is None:
            raise ValueError("BR is undefined in mixed_logit::compute_fitted_params")

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu:
            y, p = dev.convert_array_gpu(y), dev.convert_array_gpu(p)
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        pch = np.sum(y * p, axis=2)  # (N, P, R)
        pch = self.prob_product_across_panels(pch, panel_info)
        pch = truncate_lower(pch, min_comp_val)  # Remove zero elements, i.e., pch[pch == 0] = min_comp_val
        pch2 = np.divide(pch, np.sum(pch, axis=1)[:, None])  # pch divide by rowsum(pch)
        pch2 = pch2.flatten()
        temp_br = np.zeros((self.N * self.batch_size, self.Kr))

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu:
            temp_br = dev.convert_array_gpu(temp_br)
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        for i in range(self.N):  # {
            start = i * self.batch_size
            end = (i + 1) * self.batch_size
            for k in range(self.Kr):
                temp_br[start:end, k] = Br[i, k, :]
        # }

        Br = temp_br
        pch2 = np.multiply(pch2[:, None], Br)
        pch2_res = np.zeros((self.N, self.Kr))
        pch2_sd_test = np.zeros((self.N, self.Kr))

        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        if dev.using_gpu:
            pch2_res, pch2_sd_test = dev.convert_array_gpu(pch2_res), dev.convert_array_gpu(pch2_sd_test)
        # '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

        for i in range(self.N):  # {
            batch_slice = slice(i * self.batch_size, (i + 1) * self.batch_size)
            pch2_res[i, :] = np.sum(pch2[batch_slice, :], axis=0)
            pch2_sd_test[i, :] = np.std(pch2[batch_slice, :], axis=0)
        # }
        self.pch2_res, self.pch2_sd_test = pch2_res, pch2_sd_test
    # }

    # ── Extension hooks for subclasses (e.g. MixedLogitGSE) ────────
    def _n_coeff_extra(self) -> int:
        """Extra parameter count beyond base MXL params (includes heterogeneity)."""
        return (getattr(self, 'K_het_mean_rv', 0) + getattr(self, 'K_het_var_rv', 0) +
                getattr(self, 'K_het_mean_rvtrans', 0) + getattr(self, 'K_het_var_rvtrans', 0) +
                getattr(self, 'K_het_corr_cov', 0))

    def _bound_extra(self) -> dict:
        """Extra bound dictionary entries for subclasses (includes heterogeneity)."""
        inf = float('inf')
        any_bound = (-inf, inf)
        pos_bound = (0, inf)
        return {
            "het_mean_rv": (any_bound, getattr(self, 'K_het_mean_rv', 0)),
            "het_var_rv": (any_bound, getattr(self, 'K_het_var_rv', 0)),
            "het_mean_rvtrans": (any_bound, getattr(self, 'K_het_mean_rvtrans', 0)),
            "het_var_rvtrans": (any_bound, getattr(self, 'K_het_var_rvtrans', 0)),
            "het_corr_cov": (pos_bound, getattr(self, 'K_het_corr_cov', 0))
        }

    def _beta_segment_extra(self):
        """Returns (extra_names, extra_counts) for split_betas (includes heterogeneity).
        Note: Base heterogeneity segments (het_mean_rv, het_var_rv, etc.) are already
        in the base segment list. This only returns NEW segments like correlated heterogeneity covariance.
        """
        return (["het_corr_cov"],
                [getattr(self, 'K_het_corr_cov', 0)])

    def _augment_br(self, Br, var_list):
        """Modify random coefficients. Subclasses may add gradient terms."""
        return Br

    def _jax_negloglik_extra_kwargs(self):
        """Extra keyword arguments forwarded to JAX negloglik fn."""
        # Base MXL parameters (before heterogeneity)
        base_params = (self.Kf + self.Kr + self.Kchol + self.Kbw + 
                       2 * self.Kftrans + 3 * self.Krtrans)
        
        return {'reg_penalty': getattr(self, 'reg_penalty', 0.0),
                'sd_penalty': getattr(self, 'sd_penalty', 0.0),
                'het_offset': base_params,
                'K_het_mean_rv': getattr(self, 'K_het_mean_rv', 0),
                'K_het_var_rv': getattr(self, 'K_het_var_rv', 0),
                'K_het_mean_rvtrans': getattr(self, 'K_het_mean_rvtrans', 0),
                'K_het_var_rvtrans': getattr(self, 'K_het_var_rvtrans', 0),
                'het_mean_rv_idx': getattr(self, 'het_mean_rv_idx', []),
                'het_mean_rv_cols': getattr(self, 'het_mean_rv_cols', []),
                'het_var_rv_idx': getattr(self, 'het_var_rv_idx', []),
                'het_var_rv_cols': getattr(self, 'het_var_rv_cols', []),
                'het_mean_rvtrans_idx': getattr(self, 'het_mean_rvtrans_idx', []),
                'het_mean_rvtrans_cols': getattr(self, 'het_mean_rvtrans_cols', []),
                'het_var_rvtrans_idx': getattr(self, 'het_var_rvtrans_idx', []),
                'het_var_rvtrans_cols': getattr(self, 'het_var_rvtrans_cols', []),
                'rv_col_idx': getattr(self, 'rv_col_idx', []),
                'rvtrans_col_idx': getattr(self, 'rvtrans_col_idx', []),
                # Correlated heterogeneity
                'K_het_corr_cov': getattr(self, 'K_het_corr_cov', 0),
                'het_corr_groups': getattr(self, 'het_corr_groups', []),
                'het_corr_group_id': getattr(self, 'het_corr_group_id', []),
                'het_corr_group_params': getattr(self, 'het_corr_group_params', [])}

    def _jax_cache_key_extra(self):
        """Extra tuple elements for the JAX compilation cache key."""
        return (getattr(self, 'K_het_mean_rv', 0), getattr(self, 'K_het_var_rv', 0),
                getattr(self, 'K_het_mean_rvtrans', 0), getattr(self, 'K_het_var_rvtrans', 0),
                getattr(self, 'K_het_corr_cov', 0))

    def _refresh_corr_from_varlist(self):
        """Recompute chol/covariance/corr/stdevs from the FITTED var_list.

        These attributes were previously left over from whichever gradient
        evaluation ran last — often the init point (all-0.1 betas), which
        prints the infamous constant 0.7071/0.5774/0.8165 'correlations' and
        exact-zero terms that never move. Rebuilding deterministically from
        the final segments makes the displayed matrix the estimated one.
        Never raises (leaves prior values on failure).
        """
        try:
            vl = getattr(self, 'var_list', None) or {}
            chol = np.asarray(vl.get('chol', []), dtype=float).ravel()
            brw = np.asarray(vl.get('Br_w', []), dtype=float).ravel()
            Kr = int(getattr(self, 'Kr', 0) or 0)
            L = int(getattr(self, 'correlationLength', 0) or 0)
            if Kr <= 0 or chol.size == 0:
                return
            mat = np.zeros((Kr, Kr))
            idx = 0
            for r in range(min(L, Kr)):
                for c in range(r + 1):
                    if idx < chol.size:
                        mat[r, c] = chol[idx]
                        idx += 1
            for k in range(min(L, Kr), Kr):
                j = k - min(L, Kr)
                if j < brw.size:
                    mat[k, k] = abs(brw[j])
            cov = mat @ mat.T
            sd = np.sqrt(np.maximum(np.diag(cov), 1e-300))
            corr = np.eye(Kr)
            for i in range(Kr):
                for j in range(Kr):
                    if sd[i] > 0 and sd[j] > 0:
                        corr[i, j] = cov[i, j] / (sd[i] * sd[j])
            self.chol_mat = mat
            self.covariance_matrix = cov
            self.stdevs = sd
            self.corr_mat = corr
        except Exception:
            pass

    def _assemble_init_coeff(self, bf_init, br_b_init, variance_init,
                             bftrans_b, bftrans_l):
        """Assemble the MNL-based start in the objective's beta layout.

        The layout is ``[Bf | Br_b | chol | Br_w | Bftrans | flmbda |
        Brtrans_b | Brtrans_w | rlmda | het_* | subclass extras]``. The
        previous assembly inserted the het pads between Br_b and Bftrans and
        appended the variance block at the end, scrambling the start for any
        Box-Cox/heterogeneity spec (e.g. lambda seeded with a Cholesky
        spread and the log-normal mean start landing on a wrong slot).
        """
        parts = [bf_init, br_b_init, variance_init, bftrans_b, bftrans_l]
        if getattr(self, 'Krtrans', 0):
            parts += [np.repeat(0.1, self.Krtrans)] * 3
        parts += list(self._init_pad_arrays())
        parts = [np.asarray(p, dtype=float).ravel() for p in parts
                 if p is not None and len(p)]
        return np.concatenate(parts) if parts else None

    def _init_pad_arrays(self):
        """Extra arrays to insert between Br_b and Bftrans in init_coeff.
        For base MixedLogit with heterogeneity, this includes the heterogeneity params."""
        pads = []
        # Heterogeneity parameters (initialized to 0 for mean heterogeneity, 0 for variance heterogeneity)
        if hasattr(self, 'K_het_mean_rv') and self.K_het_mean_rv > 0:
            pads.append(np.repeat(0.0, self.K_het_mean_rv))
        if hasattr(self, 'K_het_var_rv') and self.K_het_var_rv > 0:
            pads.append(np.repeat(0.0, self.K_het_var_rv))
        if hasattr(self, 'K_het_mean_rvtrans') and self.K_het_mean_rvtrans > 0:
            pads.append(np.repeat(0.0, self.K_het_mean_rvtrans))
        if hasattr(self, 'K_het_var_rvtrans') and self.K_het_var_rvtrans > 0:
            pads.append(np.repeat(0.0, self.K_het_var_rvtrans))
        if hasattr(self, 'K_het_corr_cov') and self.K_het_corr_cov > 0:
            pads.append(np.repeat(0.1, self.K_het_corr_cov))  # Initialize cov params with small positive values
        return pads