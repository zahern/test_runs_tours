# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# META HEURISTIC OPTIMISATION — SearchLibrium
#
# Provides a consistent interface for all search algorithms:
#   call_siman   — Simulated Annealing
#   call_harmony — Harmony Search
#   call_search  — unified entry point (algorithm='sa' | 'hs')
#
# All functions accept:
#   parameters  — a Parameters object (from search.py)
#   init_sol    — optional warm-start solution
#   ctrl        — algorithm-specific hyperparameter tuple (auto-estimated if omitted)
#   id_num      — run identifier (used for log files)
#
# Auto-hyperparameter estimation:
#   If ctrl is None the function calls estimate_ctrl(parameters, algorithm) to
#   derive appropriate defaults based on problem size (number of candidate
#   variables, alternatives, observations, model complexity).
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

try:
    from harmony import*
    from siman import*
    from banditsa import*
    from threshold import*
    from sapbil import SAPBIL, ProbabilityMatrix
    from hspbil import HSPBIL
    from sparseea_agds import SparseEAAGDS
except ImportError:
    from .harmony import*
    from .siman import*
    from .banditsa import*
    from .threshold import*
    from .sapbil import SAPBIL, ProbabilityMatrix
    from .hspbil import HSPBIL
    from .sparseea_agds import SparseEAAGDS

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Problem-size helpers
# ─────────────────────────────────────────────────────────────────────────────

def _problem_size(parameters):
    """
    Return a dict of problem-size indicators used to calibrate hyperparameters.

    Keys
    ----
    n_vars     : total number of candidate variables
    n_alts     : number of alternatives
    n_obs      : number of observations (rows / alternatives)
    n_models   : number of model classes in the search
    allow_random: whether random parameters are enabled
    complexity  : composite score (higher = harder problem)
    """
    n_vars    = len(getattr(parameters, 'asvarnames', []) or []) + \
                len(getattr(parameters, 'isvarnames', []) or [])
    n_alts    = len(getattr(parameters, 'choice_set', []) or [])
    df        = getattr(parameters, 'df', None)
    n_obs     = len(df) if df is not None else 1000
    n_models  = len(getattr(parameters, 'models_avail', ['multinomial']))
    allow_rnd = bool(getattr(parameters, 'allow_random', False))
    allow_bc  = bool(getattr(parameters, 'allow_bcvars', False))

    # Composite complexity: more variables/models/options → harder
    complexity = n_vars * n_alts * n_models
    if allow_rnd:
        complexity *= 2
    if allow_bc:
        complexity = int(complexity * 1.5)

    return dict(n_vars=n_vars, n_alts=n_alts, n_obs=n_obs,
                n_models=n_models, allow_random=allow_rnd,
                complexity=complexity)


def estimate_ctrl(parameters, algorithm='sa', thorough=False, deep=False):
    """
    Estimate appropriate default hyperparameters for *algorithm* based on
    the problem size encoded in *parameters*.

    Parameters
    ----------
    thorough : bool
        If True, scale up hyperparameters for a more thorough search
        (3x memory/iterations for HS, 2x for SA).
    deep : bool
        If True, apply maximum search depth regardless of problem size.
        Appropriate for production/publishing runs.

    Returns
    -------
    tuple
        SA  : (tI, tF, max_temp_steps, max_iter)
        HS  : (max_mem, maxiter, max_harm, min_harm, max_pitch, min_pitch)
        AGDS: (pop_size, maxiter, pc0, pm0)
        TA  : (max_threshold, max_steps, max_iter)
    """
    ps = _problem_size(parameters)
    c  = ps['complexity']
    scale = 3 if deep else (2 if thorough else 1)

    if algorithm == 'sa':
        # Temperature ladder scales with complexity
        # Small problem  (<  50): few variables, one model type
        # Medium problem (50-300): several variables, mixed models
        # Large problem  (> 300): many variables, random params, multiple models

        if c < 50:
            tI, tF            = 500,   0.01
            max_temp_steps    = max(100, 100 * scale)
            max_iter          = max(20,  20 * scale)
        elif c < 200:
            tI, tF            = 1000,  0.001
            max_temp_steps    = max(200, 200 * scale)
            max_iter          = max(30,  30 * scale)
        elif c < 600:
            tI, tF            = 2000,  0.001
            max_temp_steps    = max(250, 250 * scale)
            max_iter          = max(40,  40 * scale)
        else:
            tI, tF            = 5000,  0.0001
            max_temp_steps    = max(300, 300 * scale)
            max_iter          = max(50,  50 * scale)

        if deep:
            tI = max(tI, 10000)
            max_temp_steps = max(max_temp_steps, 500)

        ctrl = (tI, tF, max_temp_steps, max_iter)

    elif algorithm == 'hs':
        # Harmony memory size and improvisation iterations scale with complexity
        if c < 50:
            max_mem, maxiter  = max(20,  20 * scale),  max(100,  100 * scale)
        elif c < 200:
            max_mem, maxiter  = max(25,  25 * scale),  max(300,  300 * scale)
        elif c < 600:
            max_mem, maxiter  = max(30,  30 * scale),  max(500,  500 * scale)
        else:
            max_mem, maxiter  = max(40,  40 * scale),  max(800,  800 * scale)

        # Harmony/pitch rates adapt: wider exploration band for bigger problems
        if deep or thorough:
            max_harm, min_harm = 0.95, 0.40
            max_pitch, min_pitch = 0.92, 0.15
        else:
            max_harm, min_harm = 0.90, 0.60
            max_pitch, min_pitch = 0.85, 0.30

        ctrl = (max_mem, maxiter, max_harm, min_harm, max_pitch, min_pitch)

    elif algorithm == 'agds':
        # SparseEA-AGDS: population size and generations scale with complexity;
        # pc0 is the base crossover probability, pm0=None -> 1/len(asvarnames).
        if c < 50:
            pop_size, maxiter = max(20, 20 * scale), max(30, 30 * scale)
        elif c < 200:
            pop_size, maxiter = max(30, 30 * scale), max(50, 50 * scale)
        elif c < 600:
            pop_size, maxiter = max(40, 40 * scale), max(80, 80 * scale)
        else:
            pop_size, maxiter = max(50, 50 * scale), max(120, 120 * scale)
        pc0 = 0.9
        ctrl = (pop_size, maxiter, pc0, None)

    elif algorithm == 'ta':
        # Threshold Accepting: threshold decreases linearly from max_threshold to 0
        # over max_steps, with max_iter evaluations per step
        if c < 50:
            max_threshold = max(500,  500 * scale)
            max_steps     = max(50,   50 * scale)
            max_iter      = max(30,   30 * scale)
        elif c < 200:
            max_threshold = max(1000, 1000 * scale)
            max_steps     = max(100,  100 * scale)
            max_iter      = max(50,   50 * scale)
        elif c < 600:
            max_threshold = max(2000, 2000 * scale)
            max_steps     = max(150,  150 * scale)
            max_iter      = max(80,   80 * scale)
        else:
            max_threshold = max(5000, 5000 * scale)
            max_steps     = max(200,  200 * scale)
            max_iter      = max(100,  100 * scale)

        if deep:
            max_threshold = max(max_threshold, 10000)
            max_steps = max(max_steps, 300)

        ctrl = (max_threshold, max_steps, max_iter)

    else:
        raise ValueError(f"Unknown algorithm '{algorithm}'. Use 'sa', 'hs', 'agds', or 'ta'.")

    return ctrl


def _describe_ctrl(ctrl, algorithm):
    """Return a human-readable string for the ctrl tuple."""
    if algorithm == 'sa':
        names = ('tI', 'tF', 'max_temp_steps', 'max_iter')
        hints = (
            'initial temperature  — higher = more exploration',
            'final temperature    — lower  = more exploitation',
            'number of cooling steps',
            'evaluations per cooling step',
        )
    elif algorithm == 'ta':
        names = ('max_threshold', 'max_steps', 'max_iter')
        hints = (
            'initial threshold  — higher = more exploration',
            'number of threshold reduction steps',
            'evaluations per threshold step',
        )
    elif algorithm == 'agds':
        names = ('pop_size', 'maxiter', 'pc0', 'pm0')
        hints = (
            'population size',
            'number of generations',
            'base crossover probability',
            'base mutation probability (None → 1/len(asvarnames))',
        )
    else:
        names = ('max_mem', 'maxiter', 'max_harm', 'min_harm', 'max_pitch', 'min_pitch')
        hints = (
            'harmony memory size',
            'improvisation iterations',
            'max harmony consideration rate',
            'min harmony consideration rate',
            'max pitch adjustment rate',
            'min pitch adjustment rate',
        )
    lines = ['  ctrl tuple: ' + str(ctrl)]
    for name, val, hint in zip(names, ctrl, hints):
        lines.append(f'    {name:<20s} = {val}  ({hint})')
    return '\n'.join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard printer (shared by all algorithms)
# ─────────────────────────────────────────────────────────────────────────────

def _print_dashboard(solver, best_sol, algorithm='SA'):
    """Print a formatted summary dashboard after a search run completes."""
    W    = 60
    LINE = '═' * W

    def _pad(text, width=W):
        return f"║{text}{' ' * max(width - len(text), 0)}║"

    def row(label, value, flag=''):
        text = f"  {label:<22s}: {value}"
        if flag:
            text += f'   {flag}'
        return _pad(text)

    def section(text):
        return f"╠{LINE}╣\n" + _pad(f"  {text}")

    # Title
    print(f"\n╔{LINE}╗")
    title = f'SEARCHLIBRIUM — {algorithm.upper()} DASHBOARD'
    tpad  = (W - len(title)) // 2
    print(f"║{' ' * tpad}{title}{' ' * (W - tpad - len(title))}║")

    if best_sol is None:
        print(section('No solution found'))
        print(f"╚{LINE}╝\n")
        return

    # Specification
    print(section('Best specification'))
    model_n  = best_sol.get('model_n', 'unknown')
    asvars   = best_sol.get('asvars',   [])
    isvars   = best_sol.get('isvars',   [])
    randvars = best_sol.get('randvars', {})
    bcvars   = best_sol.get('bcvars',   [])
    corvars  = best_sol.get('corvars',  [])

    print(row('Model type',  str(model_n)))
    print(row('AS variables', ', '.join(asvars) if asvars else '—'))
    if isvars:
        print(row('IS variables', ', '.join(isvars)))
    if randvars:
        print(row('Random params', ', '.join(f"{k}~{v}" for k, v in randvars.items())))
    if bcvars:
        print(row('Box-Cox vars', ', '.join(bcvars)))
    if corvars:
        print(row('Correlated vars', ', '.join(corvars)))

    # Fit statistics
    print(section('Fit statistics'))
    criterions = getattr(solver.param, 'criterions', []) if solver else []
    crit_names = [c[0] for c in criterions]

    def fmt(v):
        if v is None:
            return '—'
        try:
            return f'{float(v):.4f}'
        except Exception:
            return str(v)

    marker = lambda n: '◄ criterion' if n in crit_names else ''
    print(row('Log-likelihood', fmt(best_sol.get('loglik'))))
    print(row('AIC',            fmt(best_sol.get('aic')),    marker('aic')))
    print(row('BIC',            fmt(best_sol.get('bic')),    marker('bic')))
    if best_sol.get('mae') is not None:
        print(row('MAE',        fmt(best_sol.get('mae')),    marker('mae')))

    # Search statistics
    print(section('Search statistics'))
    conv     = getattr(solver, 'converged',     '?') if solver else '?'
    not_conv = getattr(solver, 'not_converged', '?') if solver else '?'
    acc      = getattr(solver, 'accepted',      '?') if solver else '?'
    total    = ((conv     if isinstance(conv,     int) else 0) +
                (not_conv if isinstance(not_conv, int) else 0))
    print(row('Evaluations', str(total)))
    print(row('Converged',   str(conv)))
    print(row('Accepted',    str(acc)))

    # Pareto archive (multi-objective only)
    nb_crit = getattr(solver, 'nb_crit', 1) if solver else 1
    if nb_crit > 1:
        archive = getattr(solver, 'archive', getattr(solver, 'memory', [])) or []
        print(section(f'Pareto archive  ({len(archive)} non-dominated solutions)'))
        header = '  #   ' + '   '.join(f'{c[0].upper()[:7]:<8}' for c in criterions)
        print(_pad(header[:W]))
        for idx, sol in enumerate(archive[:15]):
            vals = '   '.join(f"{float(sol.obj(i)):>8.3f}" for i in range(nb_crit))
            print(_pad(f"  {idx+1:<3d} {vals}"[:W]))
        if len(archive) > 15:
            print(_pad(f"  ... and {len(archive) - 15} more"))

    print(f"╚{LINE}╝\n")


# ─────────────────────────────────────────────────────────────────────────────
# Simulated Annealing
# ─────────────────────────────────────────────────────────────────────────────

def call_siman(parameters, init_sol=None, ctrl=None, thorough=False, deep=False, **kwargs):
    """
    Run Simulated Annealing search.

    Parameters
    ----------
    parameters : Parameters
        Problem definition (variables, data, criteria, models).
    init_sol : Solution, optional
        Warm-start solution.  None = generate automatically.
    ctrl : tuple, optional
        ``(tI, tF, max_temp_steps, max_iter)``.
        If omitted the values are estimated from the problem size.
    thorough : bool
        Scale up parameters for a more thorough search.
    deep : bool
        Maximum search depth for production runs.
    **kwargs
        ``id_num``  — run identifier (int, used in log file names).
        ``max_time`` — maximum wall-clock time in seconds (default: inf).
        ``max_total_iter`` — maximum total temperature steps (default: 100000).
        ``calibrate_tI`` — whether to auto-calibrate initial temperature (default: True if ctrl not provided).
        Any other kwargs are forwarded to the SA constructor.

    Returns
    -------
    Solution
        Best converged, all-significant solution found.
    """
    # Backwards-compat: accept ctrl inside kwargs
    if ctrl is None:
        ctrl = kwargs.pop('ctrl', None)

    id_num = kwargs.pop('id_num', None)

    # Record whether the caller supplied an explicit ctrl BEFORE auto-estimation,
    # so calibrate_tI can be enabled when it wasn't (the previous check ran after
    # estimation, so it could never be True).
    ctrl_was_provided = ctrl is not None

    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm='sa',
                             thorough=thorough, deep=deep)
        label = 'DEEP' if deep else ('THOROUGH' if thorough else 'Auto-estimated')
        print(f"[SA] {label} hyperparameters (problem complexity "
              f"= {_problem_size(parameters)['complexity']}):")
    else:
        print(f"[SA] Using provided hyperparameters:")

    print(_describe_ctrl(ctrl, 'sa'))
    print()

    # When the user supplies an explicit ctrl tuple, respect its tI instead of
    # letting choose_starting_solution recompute (override) it from delta-E sampling.
    kwargs.setdefault('calibrate_tI', not ctrl_was_provided)
    solver = SA(parameters, init_sol, ctrl, id_num, **kwargs)
    try:
        solver.run()
    finally:
        solver.close_files()
    best = solver.return_best()
    _print_dashboard(solver, best, algorithm='SA')
    return best


def call_sapbil(parameters, init_sol=None, ctrl=None, **kwargs):
    """
    Run SA+PBIL (Simulated Annealing coupled with Population-Based Incremental
    Learning) search.

    Parameters
    ----------
    parameters : Parameters
        Problem definition (variables, data, criteria, models).
    init_sol : Solution, optional
        Warm-start solution.  None = generate automatically.
    ctrl : tuple, optional
        ``(tI, tF, max_temp_steps, max_iter)``.
        If omitted the values are estimated from the problem size.
    **kwargs
        ``id_num`` — run identifier (int, used in log file names).
        ``pbil_l_bounds`` — dict of learning rate bounds per decision type
            (default: thesis-based values from Taco-Morales 2026).
            Example: {"inclusion": (0.02, 0.25), "random": (0.02, 0.15), ...}
        ``pbil_p_low`` — minimum probability clamp (default: 0.05).
        ``pbil_p_high`` — maximum probability clamp (default: 0.95).
        Any other kwargs are forwarded to the SAPBIL constructor.

    Returns
    -------
    Solution
        Best converged, all-significant solution found.
    """
    if ctrl is None:
        ctrl = kwargs.pop("ctrl", None)

    id_num = kwargs.pop("id_num", None)

    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm="sa")
        print(
            f"[SA+PBIL] Auto-estimated hyperparameters (problem complexity "
            f"= {_problem_size(parameters)['complexity']}):"
        )
    else:
        print("[SA+PBIL] Using provided hyperparameters:")

    print(_describe_ctrl(ctrl, "sa"))
    print()

    solver = SAPBIL(parameters, init_sol, ctrl, id_num, **kwargs)
    try:
        solver.run()
    finally:
        solver.close_files()
    best = solver.return_best()
    _print_dashboard(solver, best, algorithm="SA+PBIL")
    return best


def call_banditsa(parameters, init_sol=None, ctrl=None, **kwargs):
    """
    Run Bandit-guided Simulated Annealing (Thompson Sampling on perturbation arms).

    Parameters
    ----------
    parameters : Parameters
        Problem definition (variables, data, criteria, models).
    init_sol : Solution, optional
        Warm-start solution. None = generate automatically.
    ctrl : tuple, optional
        ``(tI, tF, max_temp_steps, max_iter)``.
        If omitted the values are estimated from the problem size.
    **kwargs
        ``id_num``  - run identifier (int, used in log file names).
        ``bandit_prior_alpha`` — Thompson sampling prior alpha (default: 1.0).
        ``bandit_prior_beta`` — Thompson sampling prior beta (default: 1.0).
        ``bandit_epsilon`` — epsilon for epsilon-greedy exploration (default: 0.05).
        Any other kwargs are forwarded to the BanditSA constructor.

    Returns
    -------
    Solution
        Best converged, all-significant solution found.
    """
    if ctrl is None:
        ctrl = kwargs.pop('ctrl', None)

    id_num = kwargs.pop('id_num', None)

    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm='sa')
        print(f"[BanditSA] Auto-estimated hyperparameters (problem complexity "
              f"= {_problem_size(parameters)['complexity']}):")
    else:
        print("[BanditSA] Using provided hyperparameters:")

    print(_describe_ctrl(ctrl, 'sa'))
    print()

    solver = BanditSA(parameters, init_sol, ctrl, id_num, **kwargs)
    try:
        solver.run()
    finally:
        solver.close_files()
    best = solver.return_best()
    _print_dashboard(solver, best, algorithm='BanditSA')
    return best


# ─────────────────────────────────────────────────────────────────────────────
# Harmony Search
# ─────────────────────────────────────────────────────────────────────────────

def call_harmony(parameters, init_sol=None, ctrl=None, thorough=False, deep=False, **kwargs):
    """
    Run Harmony Search.

    Parameters
    ----------
    parameters : Parameters
        Problem definition.
    init_sol : Solution, optional
        Warm-start solution (passed as existing memory).
    ctrl : tuple, optional
        ``(max_mem, maxiter, max_harm, min_harm, max_pitch, min_pitch)``.
        If omitted the values are estimated from the problem size.
    thorough : bool
        If True, scale up HS parameters for a more thorough search
        (larger memory, more iterations). Default False.
    deep : bool
        If True, apply maximum search depth for production runs.
        Overrides thorough. Default False.
    **kwargs
        ``id_num`` — run identifier.
        ``prop_local`` — proportion of iterations before local search (default: 0.8).
        ``threshold`` — convergence threshold (default: 15).
        ``generate_plots`` — whether to generate convergence plots (default: False).
        Any other kwargs are forwarded to the HarmonySearch constructor via set_control_parameters.

    Returns
    -------
    Solution
        Best solution in the final harmony memory.
    """
    if ctrl is None:
        ctrl = kwargs.pop('ctrl', None)

    id_num = kwargs.pop('id_num', None)

    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm='hs',
                             thorough=thorough, deep=deep)
        label = 'DEEP' if deep else ('THOROUGH' if thorough else 'Auto-estimated')
        print(f"[HS] {label} hyperparameters (problem complexity "
              f"= {_problem_size(parameters)['complexity']}):")
    else:
        print(f"[HS] Using provided hyperparameters:")

    print(_describe_ctrl(ctrl, 'hs'))
    print()

    solver = HarmonySearch(parameters, ctrl=ctrl, idnum=id_num)
    # Forward remaining kwargs to set_control_parameters
    if kwargs:
        solver.set_control_parameters(**kwargs)
    existing = [init_sol] if init_sol is not None else None
    try:
        solver.run_search(existing_sols=existing)
    finally:
        solver.close_files()
    best = solver.return_best()
    _print_dashboard(solver, best, algorithm='HS')
    return best


# ─────────────────────────────────────────────────────────────────────────────
# SparseEA-AGDS
# ─────────────────────────────────────────────────────────────────────────────

def call_agds(parameters, init_sol=None, ctrl=None, thorough=False, deep=False, **kwargs):
    """
    Run SparseEA-AGDS (adaptive genetic operator + dynamic scoring + reference
    point environmental selection; Wang et al. 2025).

    Parameters
    ----------
    parameters : Parameters
        Problem definition.
    init_sol : Solution, optional
        Warm-start solution (seeded into the initial population).
    ctrl : tuple, optional
        ``(pop_size, maxiter, pc0, pm0)``.  If omitted the values are estimated
        from the problem size.
    thorough, deep : bool
        Scale up population / generations for a more thorough search.
    **kwargs
        ``id_num`` — run identifier.
        ``ref_divisions`` — NSGA-III reference point divisions (default: 12).
        ``generate_plots`` — whether to generate convergence plots (default: False).
        Any other kwargs are forwarded to the SparseEAAGDS constructor via set_control_parameters.

    Returns
    -------
    Solution
        Best solution in the final population.
    """
    if ctrl is None:
        ctrl = kwargs.pop('ctrl', None)

    id_num = kwargs.pop('id_num', None)

    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm='agds',
                             thorough=thorough, deep=deep)
        label = 'DEEP' if deep else ('THOROUGH' if thorough else 'Auto-estimated')
        print(f"[AGDS] {label} hyperparameters (problem complexity "
              f"= {_problem_size(parameters)['complexity']}):")
    else:
        print("[AGDS] Using provided hyperparameters:")

    print(_describe_ctrl(ctrl, 'agds'))
    print()

    solver = SparseEAAGDS(parameters, ctrl=ctrl, idnum=id_num)
    # Forward remaining kwargs to set_control_parameters
    if kwargs:
        solver.set_control_parameters(**kwargs)
    existing = [init_sol] if init_sol is not None else None
    try:
        solver.run_search(existing_sols=existing)
    finally:
        solver.close_files()
    best = solver.return_best()
    _print_dashboard(solver, best, algorithm='AGDS')
    return best


# ─────────────────────────────────────────────────────────────────────────────
# Harmony Search + PBIL
# ─────────────────────────────────────────────────────────────────────────────

def call_harmony_pbil(parameters, init_sol=None, ctrl=None, **kwargs):
    """Run Harmony Search with PBIL-guided pitch adjustment.

    Parameters
    ----------
    parameters : Parameters
        Problem definition.
    init_sol : Solution, optional
        Warm-start solution (passed as existing memory).
    ctrl : tuple, optional
        ``(max_mem, maxiter, max_harm, min_harm, max_pitch, min_pitch)``.
        If omitted the values are estimated from the problem size.
    **kwargs
        ``id_num`` — run identifier.
        ``pbil_l_bounds`` — dict of learning rate bounds per decision type
            (default: thesis-based values from Taco-Morales 2026).
        ``pbil_p_low`` — minimum probability clamp (default: 0.05).
        ``pbil_p_high`` — maximum probability clamp (default: 0.95).
        ``prop_local`` — proportion of iterations before local search (default: 0.8).
        ``threshold`` — convergence threshold (default: 15).
        ``generate_plots`` — whether to generate convergence plots (default: False).
        Any other kwargs are forwarded to the HSPBIL constructor.

    Returns
    -------
    Solution
        Best solution in the final harmony memory.
    """
    if ctrl is None:
        ctrl = kwargs.pop('ctrl', None)

    id_num = kwargs.pop('id_num', None)

    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm='hs')
        print(f"[HS+PBIL] Auto-estimated hyperparameters (problem complexity "
              f"= {_problem_size(parameters)['complexity']}):")
    else:
        print(f"[HS+PBIL] Using provided hyperparameters:")

    print(_describe_ctrl(ctrl, 'hs'))
    print()

    solver = HSPBIL(parameters, init_sol, ctrl, idnum=id_num)
    # Forward remaining kwargs (e.g. generate_plots) via set_control_parameters
    # instead of the constructor: HSPBIL.__init__ does not accept them and older
    # callers crash with TypeError.
    _fwd = {k: v for k, v in kwargs.items() if k != 'ctrl'}
    if _fwd and hasattr(solver, 'set_control_parameters'):
        try:
            solver.set_control_parameters(**_fwd)
        except TypeError:
            pass
    existing = [init_sol] if init_sol is not None else None
    try:
        solver.run_search(existing_sols=existing)
    finally:
        solver.close_files()
    best = solver.return_best()
    _print_dashboard(solver, best, algorithm='HS+PBIL')
    return best


# ─────────────────────────────────────────────────────────────────────────────
# Unified entry point
# ─────────────────────────────────────────────────────────────────────────────

def call_search(parameters, init_sol=None, algorithm='sa', ctrl=None, thorough=False, deep=False, **kwargs):
    """
    Unified search entry point — choose algorithm at runtime.

    Parameters
    ----------
    parameters : Parameters
        Problem definition.
    init_sol : Solution, optional
        Warm-start solution.
    algorithm : {'sa', 'banditsa', 'hs'}
        ``'sa'``  — Simulated Annealing  (default)
        ``'banditsa'`` — Bandit-guided Simulated Annealing
        ``'hs'``  — Harmony Search
    ctrl : tuple, optional
        Algorithm-specific control tuple.  Auto-estimated if omitted.

        SA  : ``(tI, tF, max_temp_steps, max_iter)``
        HS  : ``(max_mem, maxiter, max_harm, min_harm, max_pitch, min_pitch)``
    thorough : bool
        Scale up search for more thorough exploration.
    deep : bool
        Maximum search depth for production runs.
    **kwargs
        Forwarded to the underlying algorithm function.

    Returns
    -------
    Solution
        Best solution found.

    Examples
    --------
    >>> best = call_search(params)                        # SA, auto ctrl
    >>> best = call_search(params, algorithm='banditsa')  # BanditSA, auto ctrl
    >>> best = call_search(params, algorithm='hs')        # HS, auto ctrl
    >>> best = call_search(params, algorithm='ta')        # TA, auto ctrl
    >>> best = call_search(params, thorough=True)         # Thorough SA
    >>> best = call_search(params, algorithm='hs', deep=True)  # Deep HS
    >>> best = call_search(params, ctrl=(500,0.001,80,15))# SA, manual ctrl
    >>> best = call_search(params, algorithm='hs',
    ...                    ctrl=(20, 400, 0.9, 0.6, 0.85, 0.3))
    """
    algorithm = algorithm.lower().strip()
    if algorithm in ('sa', 'siman', 'simulated_annealing'):
        return call_siman(parameters, init_sol=init_sol, ctrl=ctrl,
                          thorough=thorough, deep=deep, **kwargs)
    elif algorithm in ('sapbil', 'sa_pbil', 'sa+pbil', 'pbil'):
        return call_sapbil(parameters, init_sol=init_sol, ctrl=ctrl, **kwargs)
    elif algorithm in ('banditsa', 'bandit_sa', 'bandit-simulated-annealing', 'bsa'):
        return call_banditsa(parameters, init_sol=init_sol, ctrl=ctrl, **kwargs)
    elif algorithm in ('hs', 'harmony', 'harmony_search'):
        return call_harmony(parameters, init_sol=init_sol, ctrl=ctrl,
                            thorough=thorough, deep=deep, **kwargs)
    elif algorithm in ('hspbil', 'harmony_pbil', 'hs_pbil', 'hs+pbil'):
        return call_harmony_pbil(parameters, init_sol=init_sol, ctrl=ctrl, **kwargs)
    elif algorithm in ('ta', 'threshold', 'threshold_accepting'):
        return call_threshold(parameters, init_sol=init_sol, ctrl=ctrl, **kwargs)
    elif algorithm in ('agds', 'ga', 'sparseea', 'adaptive_ga'):
        return call_agds(parameters, init_sol=init_sol, ctrl=ctrl,
                         thorough=thorough, deep=deep, **kwargs)
    else:
        raise ValueError(
            f"Unknown algorithm '{algorithm}'. "
            f"Choose 'sa', 'sapbil', 'banditsa', 'hs', 'hspbil', 'ta', or 'agds'."
        )


# ─────────────────────────────────────────────────────────────────────────────
# Threshold Accepting
# ─────────────────────────────────────────────────────────────────────────────

def call_threshold(parameters, init_sol=None, ctrl=None, **kwargs):
    """
    Run Threshold Accepting search.

    Parameters
    ----------
    parameters : Parameters
        Problem definition.
    init_sol : Solution, optional
        Warm-start solution.
    ctrl : tuple, optional
        ``(max_threshold, max_steps, max_iter)``. If omitted the values are estimated
        from the problem size.
    **kwargs
        ``id_num`` — run identifier.

    Returns
    -------
    Solution
        Best solution found.
    """
    if ctrl is None:
        ctrl = kwargs.pop('ctrl', None)

    id_num = kwargs.pop('id_num', None)

    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm='ta')
        print(f"[TA] Auto-estimated hyperparameters (problem complexity "
              f"= {_problem_size(parameters)['complexity']}):")
    else:
        print("[TA] Using provided hyperparameters:")

    print(_describe_ctrl(ctrl, 'ta'))
    print()

    solver = TA(parameters, init_sol, ctrl, id_num, **kwargs)
    try:
        solver.run()
    finally:
        solver.close_files()
    best = solver.return_best()
    _print_dashboard(solver, best, algorithm='TA')
    return best


# ─────────────────────────────────────────────────────────────────────────────
# Parallel SA variants (unchanged interface, improved ctrl handling)
# ─────────────────────────────────────────────────────────────────────────────

def call_parsa(parameters, init_sol=None, nthrds=4, ctrl=None, **kwargs):
    """Run Parallel Simulated Annealing across *nthrds* independent solvers."""
    if ctrl is None:
        ctrl = kwargs.pop('ctrl', None)
    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm='sa')

    parsa = PARSA(parameters, init_sol, ctrl, nthrds=nthrds)
    parsa.run()


def call_parcopsa(parameters, init_sol=None, nthrds=8, ctrl=None):
    """Run Parallel Cooperative SA (solvers share best solution periodically)."""
    if ctrl is None:
        ctrl = estimate_ctrl(parameters, algorithm='sa')
    parcopsa = PARCOPSA(parameters, init_sol, ctrl, nthrds=nthrds)
    parcopsa.run()


def call_threshold(parameters, init_sol=None, ctrl=None):
    """Run Threshold Accepting search."""
    if ctrl is None:
        ctrl = (10, 20, 20)     # (threshold, max_steps, max_iter)
    solver = TA(parameters, init_sol, ctrl)
    try:
        solver.run()
    finally:
        solver.close_files()


# ─────────────────────────────────────────────────────────────────────────────
# Covering-array helper for hyperparameter experiments
# ─────────────────────────────────────────────────────────────────────────────

def covering_arrays(index=0):
    """Return a covering-array row for SA hyperparameter experiments."""
    covering_array = [
        (500,  0.001, 10,  10),
        (500,  0.01,  20,  20),
        (500,  0.1,   30,  50),
        (1000, 0.001, 20,  50),
        (1000, 0.01,  30,  10),
        (1500, 0.001, 30,  20),
        (1500, 0.1,   10,  50),
        (1500, 0.01,  20,  10),
    ]
    if index < len(covering_array):
        return covering_array[index]
    return covering_array[0]
