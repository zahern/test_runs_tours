"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
IMPLEMENTATION: BASE CLASS FOR LOGIT MODELS 
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
import logging

_SINGULARITY_WARNED = False


def _clip_zval(z, cap=50.0):
    """Clip a z-value for DISPLAY ONLY (|z| > cap renders as +/-cap).

    Huge |z| (near-zero SEs) break fixed-width table alignment without adding
    information (p is 0 either way). Underlying statistics are untouched —
    callers keep the raw values for inference.
    """
    try:
        z = float(z)
    except Exception:
        return float('nan')
    if z != z:  # nan stays nan
        return z
    return max(-float(cap), min(float(cap), z))


def _result_get(result, key, default=None):
    """Read *key* from a dict-like OR attribute-style optimiser result.

    ``post_process`` accepts SciPy ``OptimizeResult``/dicts as well as plain
    objects (e.g. the ``SimpleNamespace`` Larch models build), so membership
    tests like ``'stderr' in result`` must not assume a mapping.
    """
    try:
        if isinstance(result, dict):
            return result.get(key, default)
        return getattr(result, key, default)
    except Exception:
        return default

"""
BACKGROUND - Choice Modelling

ISVARS: In choice modeling, an individual-specific variable refers to a characteristic or attribute 
of an individual that is specific to that individual and influences their decision-making process.
These variables are typically included in choice models to capture heterogeneity or differences 
among individuals in their preferences or behavior.

Individual-specific variables are used in choice modeling to account for variations in preferences 
or behaviors that cannot be explained solely by the attributes of the alternatives being considered.

ASVARS: In choice modeling, an alternative-specific variable refers to a characteristic or attribute
of a specific alternative that may influence the decision-making process of individuals when choosing 
among available options. These variables are included in choice models to capture the effects of
attributes that vary across alternatives and affect individuals' preferences for those alternatives.

Examples of alternative-specific variables in choice modeling may include attributes such as price, 
brand, product features, location, or availability. These variables can represent both observable
characteristics of alternatives (e.g., price) and unobservable characteristics that may influence 
preferences (e.g., brand reputation).
 
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

''' ----------------------------------------------------------- '''
'''  MAIN PARAMETERS:                                           '''
''' ----------------------------------------------------------- '''
# N : Number of choice situations
# P : Number of observations per panels
# J : Number of alternatives
# K : Number of variables (Kf: fixed, non-trans, Kr: random, non-trans,
#        Kftrans: fixed, trans, Krtrans: random, trans)

''' ---------------------------------------------------------- '''
''' UNUSED LIBRARIES                                           '''
''' ---------------------------------------------------------- '''
#import logging

''' ---------------------------------------------------------- '''
''' LIBRARIES                                                  '''
''' ---------------------------------------------------------- '''
import warnings
from abc import ABC #, abstractmethod
from time import time
import numpy as np
import pandas as pd
import scipy.stats as ss
try:
    import jax.numpy as jnp
    JAX_AVAILABLE = True
except ImportError:  # pragma: no cover - jax is required; guard is import robustness only
    jnp = None
    JAX_AVAILABLE = False




try:
    from .boxcox_functions import boxcox_param_deriv, boxcox_transformation, truncate, truncate_lower
    from ._device import device as dev
    
except ImportError:
    from boxcox_functions import boxcox_param_deriv, boxcox_transformation, truncate, truncate_lower
    from _device import device as dev
    

#library for keeping track of variables
#from watchpoints import watch

# A dictionary to manage backends
BACKENDS = {
    "numpy": np,
}
if JAX_AVAILABLE:
    BACKENDS["jax"] = jnp

_JAX_MISSING_WARNED = False


def _warn_jax_missing():
    """Warn once that JAX was requested but is not installed."""
    global _JAX_MISSING_WARNED
    if not _JAX_MISSING_WARNED:
        _JAX_MISSING_WARNED = True
        warnings.warn(
            "JAX was requested but could not be imported; falling back to "
            "the numpy/scipy backend. JAX is a required dependency — check "
            "your installation.",
            ImportWarning, stacklevel=3,
        )


def _numba_is_global_default():
    """True when the process-wide default engine is numba (SL_ENGINE/env)."""
    try:
        try:
            from .numba_engine import numba_as_default as _nad
        except ImportError:
            try:
                from numba_engine import numba_as_default as _nad
            except ImportError:
                _nad = None
        if _nad is not None:
            return bool(_nad())
    except Exception:
        pass
    try:
        import os as _os
        return str(_os.environ.get('SL_ENGINE', '')).strip().lower() == 'numba'
    except Exception:
        return False


def resolve_jax_backend(requested=None):
    """Resolve the array backend for ``_jax=<requested>``.

    Returns ``(use_jax, backend_module)``. ``None`` (the default) follows
    the global default engine: ``False``/numpy when numba is the global
    default (``SL_ENGINE=numba`` or ``numba_engine.set_default_engine``),
    ``True``/jax.numpy otherwise (legacy JAX-first behaviour). Explicit
    ``True``/``False`` is honoured verbatim. When JAX is requested but not
    installed this degrades to ``(False, numpy)`` with a one-time warning
    instead of raising.
    """
    if requested is None:
        requested = not _numba_is_global_default()
    if requested and JAX_AVAILABLE:
        return True, jnp
    if requested:
        _warn_jax_missing()
    return False, np

# Utility function to select the backend
def get_backend(jax=True):
    """
    Return the appropriate backend (jax.numpy or numpy).

    Args:
        jax (bool): If True, use JAX. Otherwise, use NumPy.

    Returns:
        module: The selected backend module.
    """
    return BACKENDS["jax"] if jax else BACKENDS["numpy"]


''' ---------------------------------------------------------- '''
''' CLASS FOR ESTIMATION OF DISCRETE CHOICE MODEL              '''
''' ---------------------------------------------------------- '''
class DiscreteChoiceModel(ABC):
# {
    """ Docstring """

    # ===================
    # CLASS PARAMETERS
    # ===================

    """
    coeff_est:  Coefficient estimates
    """

    # ===================
    # CLASS FUNCTIONS
    # ===================

    """
    1. void __init__(self);
    2. void fit(self);
    3. void reset_attributes(self);
    4.  set_asarray(self, X, y, varnames, alts, isvars, transvars, ids, weights, panels, avail);
    5. void pre_process(self, alts, varnames, isvars, transvars, base_alt, fit_intercept, transformation,
                maxiter, panels=None, correlated_vars=None, randvars=None);
    6. void post_process(self, result, coeff_names, sample_size, hess_inv=None);
    7. X, names <-- setup_design_matrix(self, X);
    8.  check_long_format_consistency(self, ids, alts, sorted_idx);
    9. X, y, panels <-- arrange_long_format(self, X, y, ids, alts, panels=None);
    10. void validate_inputs(self, X, y, alts, varnames, isvars, ids, weights,
                         panels, base_alt, fit_intercept, maxiter);
    11. loglik <-- get_loglik_null(self);
    12. void summarise(self);
    13. void print_matrix(self, str_mat, descr);
    14. str_mat <-- setup_print(self, mat);
    15. void  print_mat(self, mat, descr);
    16. pch_res <-- fitted(self, type="parameters");
    17. void  print_stdev(self, stdevs, names);
    18. void  compute_stddev(self);
    """

    ''' ---------------------------------------------------------- '''
    ''' Function                                                   '''
    ''' ---------------------------------------------------------- '''
    def reset_attributes(self): # {
        self.coeff_names, self.coeff_est  = None, None
        self.stderr, self.zvalues = None, None
        self.pvalues, self.loglik = None, None
        self.total_fun_eval = 0
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function                                                   '''
    ''' ---------------------------------------------------------- '''
    def __init__(self, jax = None):
    # {
        # jax=None follows the global default engine (JAX-first unless
        # SL_ENGINE=numba / set_default_engine('numba')); explicit
        # True/False is honoured verbatim.

        self.reset_attributes()
        self.fit_intercept = False
        self.reg_penalty = 0.00  # L2 penalty strength (ridge)
        self.l1_penalty  = 0.1   # L1 penalty strength (lasso)
        self.pval_penalty = 5
        # p-value threshold above which a coefficient counts as "non-significant"
        # for the log-likelihood penalty applied in post_process.
        self.pval_threshold = 0.05
        logging.info(f'pval penalty set to {self.pval_penalty}')
        # NOTE: The reg_penalty value is tricky to define. If too high, convergence is restricted.
        #  Set to zero to turn off. A value of 1 seems too high.

        # Variables used in derived classes and were previously not defined in this class:
        self.obs_prob = 0
        self.Xnames = None
        self.ordered_varnames = None
        self.covariance_matrix, self.betas = None, None

        # Define constants:
        self.ftol, self.gtol = 1e-7, 1e-5
        self.maxiter = 2000

        # Define boolean flags:
        self.converged = False
        self.return_grad, self.return_hess, self.fit_intercept = True, True, False
        self.scipy_optimisation = True
        self.method, self.transformation = "slsqp", "boxcox"

        self.trans_func = None      # NEW. CHECK VALIDITY!
        self.varnames, self.isvars, self.transvars = None, None, None
        self.base_alt, self.alts, self.panels = None, None, None
        self.bic, self.aic, self.mae = None, None, None  # Metrics
        self.loglik = None

        # Initialise empty arrays
        self.fxidx, self.fxtransidx = [], []
        self.X, self.y = [], []
        self.X_original, self.y_original = [], []
        self.weights, self.avail = [], []
        self.init_coeff = []
        self._jax, self.backend = resolve_jax_backend(jax)
        self.descr = ""
    # }

    def __getstate__(self):
        state = self.__dict__.copy()
        state.pop("backend", None)
        state["_backend_jax"] = bool(state.get("_jax", True))
        return state

    def __setstate__(self, state):
        backend_jax = bool(state.pop("_backend_jax", True))
        self.__dict__.update(state)
        self.backend = get_backend(backend_jax)

    ''' ---------------------------------------------------------- '''
    ''' Function. Virtual                                          '''
    ''' ---------------------------------------------------------- '''
    #@abstractmethod
    def fit(self): # {
        pass
    # }

    @staticmethod
    def add_single_intercept(data, varnames = None):
        # Check if data is a NumPy array
        if isinstance(data, np.ndarray):
            # Add intercept as a new column (prepend or append)
            intercept_col = np.ones((data.shape[0], 1))  # Column of ones
            if "intercept" not in varnames:  # Handle both DataFrame and ndarray
                data = np.hstack([intercept_col, data])  # Append intercept for NumPy arrays
        elif isinstance(data, pd.DataFrame):
            # Check and add intercept for DataFrames
            if "intercept" not in data.columns:
                data.insert(0, "intercept",1)  # Add intercept column

        else:
            raise TypeError("Data must be a NumPy array or Pandas DataFrame")


        return data

    ''' ---------------------------------------------------------- '''
    ''' Function. Convert to numpy arrays                          '''
    ''' ---------------------------------------------------------- '''
    def set_asarray(self, X, y, varnames, alts, isvars, transvars, ids, weights, panels, avail): # {
        if self.fit_intercept:
            X = self.add_single_intercept(X, varnames)

        X = np.asarray(X)
        y = np.asarray(y)
        varnames = np.asarray(varnames, dtype="<U64") if varnames is not None else None
        if self.fit_intercept:
            if varnames is not None:
                if "intercept" not in varnames:
                    varnames = np.insert(varnames, 0, "intercept")  # Insert '_inter' into the first


            else:
                # Initialize varnames with only "_inter" if varnames is None
                varnames = np.array(["intercept"], dtype="<U64")
                #print("'_inter' added as the first item in varnames.")
        alts = np.asarray(alts) if alts is not None else None
        # NB: an empty np.array([]) defaults to float64 and cannot hold 'intercept'
        isvars = np.asarray(isvars, dtype=object) if isvars is not None else np.array([], dtype=object)
        if self.fit_intercept and "intercept" not in isvars:
            isvars = np.insert(isvars, 0, "intercept")
        transvars = np.asarray(transvars, dtype="<U64") if transvars is not None else []
        ids = np.asarray(ids) if ids is not None else None
        weights = np.asarray(weights) if weights is not None else None
        panels = np.asarray(panels) if panels is not None else None
        avail = np.asarray(avail) if avail is not None else None
        return X, y, varnames, alts, isvars, transvars, ids, weights, panels, avail
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function to assign the penalty of the regularisation       '''
    ''' ---------------------------------------------------------- '''
    def reassign_penalty(self, penalty = 0):
        self.reg_penalty = penalty

    ''' ---------------------------------------------------------- '''
    ''' Function. Initialise member variables                      '''
    ''' ---------------------------------------------------------- '''
    def pre_process(self, alts, varnames, isvars, transvars, base_alt, fit_intercept, transformation,
                maxiter = 2000, panels=None, correlated_vars=None, randvars=None):
    # {
        self.reset_attributes()
        self.fit_start_time = time()  # Set the start time for runtime calculation
        self.isvars = [] if isvars is None else isvars
        self.transvars = [] if transvars is None else transvars
        self.randvars = [] if randvars is None else randvars

        
        self.asvars = [v for v in varnames if ((v not in self.isvars) and 
                                               #(v not in self.transvars) and 
                                               (v not in self.randvars))] 

        #todo check asvars, if asvars

        # old definition of asvars used to make datasets
        self.asvars_construct_matrix = [v for v in varnames if v not in self.isvars]
        self.randtransvars, self.fixedtransvars = [], []


        _, idx = np.unique(alts, return_index=True)
        self.alts = alts[np.sort(idx)]   # Extract unique alternatives from the data # but keep the order of the actual data.


        self.varnames = list(varnames)  # Easier to handle with lists
        self.fit_intercept = fit_intercept

        self.transformation = transformation
        self.base_alt = self.alts[0] if base_alt is None else base_alt
        self.correlated_vars = False if correlated_vars is None else correlated_vars
        self.maxiter = maxiter

        # Assign panels to self.panels if self.panels attribute does not exist
        self.panels = getattr(self, 'panels', panels) # i.e., if not hasattr(self, 'panels'): self.panels = panels
    # }




    ''' ---------------------------------------------------------- '''
    ''' Function                                                   '''
    ''' convert hess inverse for L-BFGS-B optimisation method      '''
    ''' ---------------------------------------------------------- '''
    def post_process(self, result, coeff_names, sample_size, hess_inv=None):
    # {
        self.converged = _result_get(result, 'success', False)
        self.coeff_est = _result_get(result, 'x')
        self.loglik = -_result_get(result, 'fun', np.nan)
        self.total_iter = _result_get(result, 'nit', 0)

        self.estim_time_sec = time() - self.fit_start_time
        self.sample_size = sample_size
        self.num_params = self.Kbw + self.Kchol + self.Kf + self.Kftrans + self.Kr + self.Krtrans

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Compute stderr
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        self.stderr = np.zeros_like(self.coeff_est)
        std_err_estimated = False

        _stderr = _result_get(result, 'stderr')
        if _stderr is not None:  # {
            std_err_estimated = True
            self.stderr = _stderr
        # }



        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Define coeff_names
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        self.coeff_names = coeff_names

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Compute stderr
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Hinv_exists = (hasattr(self,'Hinv') and not self.Hinv is None)
        if Hinv_exists:
        # {
            if dev.using_gpu:
                self.stderr = np.sqrt(np.abs(np.diag(self.Hinv)))
            else:
            # {
                diag_arr_tmp = np.diag(np.array(self.Hinv))

                # stop runtime warnings from (very small) negative values
                # assume these occur from some floating point error and are 0.

                pos_vals_idx = [ii for ii, el in enumerate(diag_arr_tmp) if el > 0]
                diag_arr = np.zeros(len(diag_arr_tmp))
                diag_arr[pos_vals_idx] = diag_arr_tmp[pos_vals_idx]
                self.stderr = np.sqrt(np.abs(diag_arr))
            # }

            std_err_estimated = not np.isnan(self.stderr).any()
        # }

        if not std_err_estimated:
        # {
            if self.method == "bfgs":
                _hess = _result_get(result, 'hess_inv')
                if _hess is not None:
                    self.stderr = np.sqrt(np.abs(np.diag(np.array(_hess))))
                    std_err_estimated = True

            if self.method == "l-bfgs-b":
                _hess = _result_get(result, 'hess_inv')
                if _hess is not None:
                    _hess = _hess.todense() if hasattr(_hess, 'todense') else _hess
                    self.stderr = np.sqrt(np.abs(np.diag(np.array(_hess))))
                    std_err_estimated = True
        # }

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Fallback: some models (e.g. MixedLogit with the default
        # "slsqp" method) compute and stash a numerical Hessian inverse
        # directly on the result dict (result['hess_inv']) instead of
        # setting self.Hinv or using scipy's bfgs/l-bfgs-b machinery.
        # The two checks above only recognise "bfgs"/"l-bfgs-b", so without
        # this fallback self.stderr silently stays all-zero for every other
        # method even though a usable Hessian was already computed.
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        hess_inv = _result_get(result, 'hess_inv')
        if not std_err_estimated and hess_inv is not None:
        # {
            hess_inv = hess_inv.todense() if hasattr(hess_inv, 'todense') else hess_inv
            diag_arr_tmp = np.diag(np.array(hess_inv))
            pos_vals_idx = [ii for ii, el in enumerate(diag_arr_tmp) if el > 0]
            diag_arr = np.zeros(len(diag_arr_tmp))
            diag_arr[pos_vals_idx] = diag_arr_tmp[pos_vals_idx]
            self.stderr = np.sqrt(np.abs(diag_arr))
            std_err_estimated = not np.isnan(self.stderr).any()
        # }

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Compute lambda_mask (for nested logit models)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Lambda parameters are tested against H0=1 (not H0=0)
        # because lambda represents nesting strength (1=standard logit)
        lambda_mask = [1 if "lambda" in x else 0 for x in coeff_names]

        # If length mismatch, pad with 0s (assume non-lambda params for extras)
        if len(lambda_mask) != len(self.coeff_est):
            lambda_mask = np.concatenate([
                lambda_mask,
                np.zeros(len(self.coeff_est) - len(lambda_mask))
            ])



        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Compute z-values
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        with np.errstate(divide='ignore', invalid='ignore'):
            self.zvalues = np.nan_to_num((self.coeff_est - lambda_mask) / self.stderr)
        self.zvalues = truncate(self.zvalues, -1e+5, 1e+5)  # Set maximum (and minimum) limits

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Compute pvalues
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if sample_size < 100:  # arbitrary ... could do standard 30
            self.pvalues = 2 * (1 - ss.t.cdf(np.abs(self.zvalues), df=sample_size))
        else:
            self.pvalues = 2 * (1 - ss.norm.cdf(np.abs(self.zvalues)))

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Compute Number of Non-Significant pvalues
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        non_sigs = self.num_of_exceeding_pvalues(self.pvalues, getattr(self, 'pval_threshold', 0.05))
        #print('log like is before', self.loglik)
        self.loglik -= non_sigs*self.pval_penalty # penalise the non-sigs
        logging.info('applying pval')
        #print('log like is', self.loglik)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Compute aic and bic
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        num_params = len(self.coeff_est)



        self.aic = 2 * num_params - 2 * self.loglik
        self.bic = np.log(sample_size) * num_params - 2 * self.loglik

        # ── Singularity penalty ──────────────────────────────────────────
        # When the Hessian is near-singular (near-constant or collinear
        # variables), standard errors collapse to ~zero.  Penalise
        # proportionally to BIC so the search can still rank these models
        # against each other rather than rejecting them outright.
        if not std_err_estimated or np.all(np.abs(self.stderr) < 1e-8):
            sv_penalty = max(200.0, min(0.05 * abs(self.bic), 2000.0))
            self.aic += sv_penalty
            self.bic += sv_penalty
            self._singularity_penalised = True
            zero_se_vars = [
                n for n, s in zip(self.coeff_names, self.stderr)
                if abs(s) < 1e-8
            ]
            if zero_se_vars:
                global _SINGULARITY_WARNED
                if not _SINGULARITY_WARNED:
                    _SINGULARITY_WARNED = True
                    logging.warning(
                        "[singularity] design matrix ill-conditioned — "
                        "SE≈0 for: %s — BIC penalised by %.0f",
                        ', '.join(zero_se_vars[:12]), sv_penalty,
                    )


    # }

    def cov_params(self, robust=False):
        """Parameter covariance matrix aligned to ``coeff_names``.

        Mediation/path analysis (e.g. SEM-style direct + indirect effects)
        needs off-diagonal covariances, not just standard errors.  Returns a
        ``pandas.DataFrame`` (p x p) with ``coeff_names`` as index/columns.

        Parameters
        ----------
        robust : bool, default False
            If True, prefer the sandwich ``robust_varcov`` when present and
            shape-consistent; otherwise fall back to the inverse Hessian.

        Notes
        -----
        Uses ``self.robust_varcov`` (if ``robust=True``) else ``self.Hinv``.
        Both are stored by ``fit()``/``post_process()``.  Raises ValueError
        when no p x p finite covariance is available (e.g. the model was fit
        with ``return_hess=False``).
        """
        import numpy as _np
        import pandas as _pd
        est = _np.asarray(getattr(self, 'coeff_est', []), dtype=float).ravel()
        p = int(est.size)
        if p == 0:
            raise ValueError("cov_params: model has no estimated coefficients "
                             "(was fit() called?)")
        _V = None
        if robust:
            _V = getattr(self, 'robust_varcov', None)
        if _V is None:
            _V = getattr(self, 'Hinv', None)
        if _V is None:
            raise ValueError("cov_params: no covariance available "
                             "(missing Hinv/robust_varcov — refit with "
                             "return_hess=True)")
        try:
            _V = _np.asarray(_V, dtype=float)
        except Exception as _e:
            raise ValueError(f"cov_params: stored covariance not array-like "
                             f"({_e!r})")
        if _V.shape != (p, p) or not _np.all(_np.isfinite(_V)):
            raise ValueError(f"cov_params: stored covariance has shape "
                             f"{tuple(_V.shape)}, expected ({p}, {p}) with "
                             f"finite entries")
        _raw_names = getattr(self, 'coeff_names', None)
        _names = (list(_raw_names) if _raw_names is not None else [])
        if len(_names) != p:
            _names = [str(_n) for _n in _names[:p]]
            _names += [f"param_{i}" for i in range(len(_names), p)]
        _V = (_V + _V.T) / 2.0  # enforce symmetry against float noise
        return _pd.DataFrame(_V, index=_names, columns=_names)

    def num_of_exceeding_pvalues(self, pvalues, threshold):
        """
        :param pvalues: array of pvalues
        :type pvalues:float
        :param threshold: signficant values for hypothesis testing
        :type threshold: float
        :return: int
        """
        return len([p for p in pvalues if p > threshold])


    ''' ------------------------------------------------------------------------ '''
    ''' Function. Setup and reshape input data after adding isvars and intercept '''
    ''' ------------------------------------------------------------------------ '''
    def setup_design_matrdix(self, X):
    # {
        """ Setup the design matrix by adding the intercept when necessary and
        converting the isvars to a dummy representation that removes the base alternative """

        self.J = getattr(self, 'J', len(self.alts)) # i.e., if not hasattr(self, 'J'): self.J = len(self.alts)
        self.N = int(len(X) / self.J)
        self.P = 0

        P_N = self.N
        J = self.J
        N = self.N

        if self.panels is not None:
        # {
            # Identify and count unique values. Return two arrays
            unique_values, counts = np.unique(self.panels, return_counts=True)

            self.N = len(unique_values) # Set N as the number of unique values
            normalized_counts = counts / self.J # Normalize counts by dividing by self.J
            self.P_i = normalized_counts.astype(int) # Convert scaled counts to integers

            # Assumption of itegrality. Should check if any element is not an integer!

            self.P = np.max(self.P_i)   # Identify and store maximum element
        # }
        else:
        # {
            self.P = 1
            self.P_i = np.ones([self.N]).astype(int)
        # }

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # MAKE COPIES
        isvars = self.isvars.copy()
        asvars = self.asvars.copy()
        asvars_construct_matrix = self.asvars_construct_matrix.copy()
        randvars = self.randvars.copy()
        randtransvars = self.randtransvars.copy()
        fixedtransvars = self.fixedtransvars.copy()
        varnames = self.varnames.copy()
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        self.varnames = np.array(varnames, dtype="<U64")
        lst = self.varnames.tolist()
        #print(lst)
        ispos = [lst.index(str) for str in self.isvars if str in lst]  # Position of IS vars
        #print('is pos is ', ispos)
        #print('and X is', X)
        ispos_old = [self.varnames.tolist().index(i) for i in self.isvars]  # Position of IS va
        # adjust index array to include isvars
        if len(self.isvars) > 0 and not hasattr(self, 'ispos'):  # check not done before...
        # {


            nbFalse = len(self.isvars) * (J - 1)  # Calculate the number of False values to insert

            # Creates a masked version of the boolean array fxidx_bool based on indices not present in the array ispos
            fxidx_bool = np.array(self.fxtransidx, dtype="bool") # Convert elements to booleans
            indices = np.arange(len(fxidx_bool)) # Array of indices from 0 to len(fxidx_bool) - 1.
            mask = np.isin(indices, ispos) # True indicates that the element from indices is in ispos, and False indicates it is not.
            fxidx_bool_masked = fxidx_bool[~mask] # negated_mask = ~mask
            self.fxidx = np.insert(fxidx_bool_masked, 0, np.repeat(True, nbFalse))# Insert True values

            fxtransidx_bool = np.array(self.fxtransidx, dtype="bool")  # Convert elements to booleans
            indices= np.arange(len(fxtransidx_bool))
            mask = np.isin(indices, ispos)
            fxtransidx_bool_masked = fxtransidx_bool[~mask]
            self.fxtransidx = np.insert(fxtransidx_bool_masked, 0, np.repeat(False, nbFalse)) # Insert False values

            if hasattr(self, 'rvidx'):
            # {
                rvidx_bool = np.array(self.rvidx, dtype=bool) # Convert self.rvidx to boolean array if it's not already
                indices = np.arange(len(rvidx_bool))
                mask = np.isin(indices, ispos)
                rvidx_bool_masked = rvidx_bool[~mask]
                self.rvidx = np.insert(rvidx_bool_masked, 0, np.repeat(False, nbFalse)) # Insert False values
            # }

            if hasattr(self, 'rvtransidx'):
            # {
                rvtransidx_bool = np.array(self.rvtransidx, dtype=bool)  # Convert self.rvidx to boolean array if it's not already
                indices = np.arange(len(rvtransidx_bool))
                mask = np.isin(indices, ispos)
                rvtransidx_bool_masked = rvtransidx_bool[~mask]
                self.rvtransidx = np.insert(rvtransidx_bool_masked, 0, np.repeat(False, nbFalse))  # Insert False values
            # }
        # }

        if self.transformation == "boxcox": # {
            self.trans_func = boxcox_transformation
            self.transform_deriv = boxcox_param_deriv
        # }

        S = np.zeros((self.N, self.P, self.J))
        for i in range(self.N):
            S[i, 0:self.P_i[i], :] = 1

        self.S = S

        lst = self.varnames.tolist()
        self.ispos = [lst.index(str) for str in self.isvars if str in lst]  # Position of isvars in varnames
        self.aspos = [lst.index(str) for str in asvars_construct_matrix if str in lst]  # Position of asvars in varnames
        randpos = [lst.index(str) for str in randvars if str in lst]  # Position of randvars
        randtranspos = [lst.index(str) for str in randtransvars if str in lst]  # bc transformed variables with random coeffs
        fixedtranspos = [lst.index(str) for str in fixedtransvars if str in lst]  # bc transformed variables with fixed coeffs

        self.correlationpos = []
        if randvars:
            self.correlationpos = [lst.index(str) for str in self.varnames if str in self.randvars]  # Position of correlated variables within randvars

        if (isinstance(self.correlated_vars, list)):
        #{
            self.correlationpos = [lst.index(str) for str in self.varnames if str in self.correlated_vars]
            self.uncorrelatedpos = [lst.index(str) for str in self.varnames if str not in self.correlated_vars]
        #}

        self.Kf = sum(self.fxidx)           # Set number of fixed coeffs from idx
        self.Kr = len(randpos)              # Number of random coefficients
        self.Kftrans = len(fixedtranspos)   # Number of fixed coefficients of bc transformed vars
        self.Krtrans = len(randtranspos)    # Number of random coefficients of bc transformed vars
        self.Kchol = 0                      # Number of random beta cholesky factors
        self.correlationLength = 0
        self.Kbw = self.Kr

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # set up length of betas required to estimate correlation and/or
        # random variable standard deviations, useful for cholesky matrix
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        if (self.correlated_vars):
        # {
            if (isinstance(self.correlated_vars, list)):
            # {
                nb_corvars = len([v for v in self.correlated_vars if v in randvars])
                self.correlationLength = nb_corvars
                self.Kbw = self.Kr - nb_corvars
                self.Kchol = int((nb_corvars * (nb_corvars + 1)) / 2)
                # i.e., Kchol => # permutations of specified params in correlation list
            # }
            else: # {
                self.correlationLength = self.Kr
                self.Kbw = 0
                nb_randvars = len(self.randvars)
                self.Kchol = int((nb_randvars * (nb_randvars + 1)) / 2)
                # i.e., correlated_vars = True, Kchol => permutations of rand vars
            # }
        # }

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Create design matrix for individual specific variables
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Xis = None
        if len(self.isvars):
        # {
            # Create a dummy individual specific variables for the alts
            dummy = np.tile(np.eye(J), reps=(P_N, 1))

            # Remove base alternative
            dummy = np.delete(dummy, np.where(self.alts == self.base_alt)[0], axis=1)
            Xis = X[:, self.ispos]


            if Xis.dtype == np.object_:
                Xis_numeric = pd.to_numeric(Xis.flatten(), errors='coerce').reshape(Xis.shape)
                Xis = Xis_numeric


            # Multiply dummy representation by the individual specific data
            try:

                Xis = np.einsum('nj,nk->njk', Xis, dummy, dtype="float64")
            except:
                Xis_numeric = pd.to_numeric(Xis.flatten(), errors='coerce').reshape(Xis.shape)
                Xis = Xis_numeric
                Xis = np.einsum('nj,nk->njk', Xis, dummy, dtype="float64")
                # Example of filtering out non-numeric data
                #Xis = np.array([x for x in Xis if isinstance(x, (int, float))], dtype='float64')
            nbOf = (self.J - 1) * len(self.ispos)
            Xis = Xis.reshape((P_N, self.J, nbOf)) # ERROR: UNEXPECTED ARGUMENT?

        # }
        else: # {
            Xis = np.array([])
        # }

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # For alternative specific variables
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        Xas = None
        if asvars_construct_matrix:
        # {
            Xas = X[:, self.aspos]
            Xas = Xas.reshape(N, J, -1)
        # }

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Set design matrix based on existence of asvars and isvars
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        """
        NEW CODE:
        if asvars_construct_matrix:     # There are vars that are not isvars
            X = np.dstack((Xis, Xas)) if self.isvars else Xas
        elif self.isvars:
            X = Xis
        else: # {
            length = len(self.varnames)
            if self.fit_intercept: length += (J - 1) - 1
            X = X.reshape(-1, len(self.alts), length)
        # }"""

        # OLD CODE:
        if len(asvars_construct_matrix) and len(self.isvars):
            X = np.dstack((Xis, Xas))
        elif len(asvars_construct_matrix):
            X = Xas
        elif (len(self.isvars)):
            X = Xis
        else:
            x_varname_length = len(self.varnames)
            X = X.reshape((-1, len(self.alts), x_varname_length))
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


        intercept_names = []

        names = ["{}.{}".format(isvar, j) for isvar in isvars for j in self.alts if j != self.base_alt]

        lambda_names_fixed = ["lambda.{}".format(transvar) for transvar in fixedtransvars]

        lambda_names_rand = ["lambda.{}".format(transvar) for transvar in randtransvars]

        randvars = [x for x in self.varnames if x in self.randvars]
        randvars = np.array(randvars, dtype='<U64')

        asvars_names = [x for x in asvars if (x not in self.randvars) and
                        (x not in fixedtransvars) and (x not in randtransvars)]

        chol = ["chol." + self.varnames[self.correlationpos[i]] + "." +
                self.varnames[self.correlationpos[j]] for i
                in range(self.correlationLength) for j in range(i + 1)]

        br_w_names = []

        # three cases for corr. varnames: no corr, corr list, corr Bool (All)
        if not (self.correlated_vars is True or isinstance(self.correlated_vars, list)):
            if hasattr(self, "rvidx"):  # avoid errors with multinomial logit
                br_w_names = np.char.add("sd.", randvars)

        if (isinstance(self.correlated_vars, list)):  # if not all r.v.s correlated
        # {
            sd_uncorrelated_pos = [lst.index(str) for str in self.varnames
                    if str not in self.correlated_vars and str in randvars]
            br_w_names = np.char.add("sd.", self.varnames[sd_uncorrelated_pos])
        # }

        sd_rand_trans = np.char.add("sd.", self.varnames[randtranspos])

        names = np.concatenate((intercept_names, names, asvars_names, randvars,
                                chol, br_w_names, fixedtransvars,
                                lambda_names_fixed, randtransvars,
                                sd_rand_trans, lambda_names_rand))

        names = np.array(names, dtype="<U64")
        return X, names
    # }


    def check_instance(self, obj):

        if "MultinomialLogit" in obj.__class__.__name__:
            
            return True
        elif "OrderedLogitLong" in obj.__class__.__name__:
            return True
        elif "MultinomialProbit" in obj.__class__.__name__:
            return True
        elif "NestedLogit" in obj.__class__.__name__:
            return True
        else:
           
            return False
        #return isinstance(self, MultinomialLogit)

    def restate_idx(self, ispos, isvar, asvars):
        #todo check if i isvar and aasvars can both be present, otherwise not needed
        if self.check_instance(self):


            return
        else:
            
            #I BELIEVE THIS IS REDUNDANT NOW

            if len(self.fxidx) and len(ispos) and max(ispos) < len(self.fxidx):
                self.fxidx = np.delete(self.fxidx, ispos)

            if len(self.fxtransidx) and len(ispos) and max(ispos) < len(self.fxtransidx):
                self.fxtransidx = np.delete(self.fxtransidx, ispos)
            # self.fxtransidx = np.insert(np.array(self.fxtransidx, dtype="bool_"),
            #  0, np.repeat(False, len(self.isvars)*(J - 1)))
            if hasattr(self, 'rvidx') and len(self.rvidx) and len(ispos) and max(ispos) < len(self.rvidx):
                self.rvidx = np.delete(self.rvidx, ispos)
            if hasattr(self, 'rvtransidx') and len(self.rvtransidx) and len(ispos) and max(ispos) < len(self.rvtransidx):
                self.rvtransidx = np.delete(self.rvtransidx, ispos)
        
               


    def setup_design_matrix(self, X):
        """Setups and reshapes input data after adding isvars and intercept.

        Setup the design matrix by adding the intercept when necessary and
        converting the isvars to a dummy representation that removes the base
        alternative.
        """

        J = getattr(self, 'J', len(self.alts))
        #print(X)
        N = P_N = int(len(X)/J)
        self.P = 0
        self.N = N
        self.J = J
        if self.panels is not None:
            # panels size
            self.P_i = ((np.unique(self.panels, return_counts=True)[1])/J).astype(int)
            self.P = np.max(self.P_i)
            self.N = len(self.P_i)
        else:
            self.P = 1
            self.P_i = np.ones([N]).astype(int)
        isvars = self.isvars.copy()
        asvars = self.asvars.copy()
        asvars_construct_matrix = self.asvars_construct_matrix.copy()
        randvars = self.randvars.copy()
        randtransvars = self.randtransvars.copy()
        fixedtransvars = self.fixedtransvars.copy()
        varnames = self.varnames.copy()
        self.varnames = np.array(varnames, dtype="<U64")
        #print('varnames', varnames)
        lst = varnames
        lst = np.array(lst, dtype='<U64')

        lst = lst.tolist()

        ispos = [lst.index(str) for str in self.isvars if str in lst]  # Position of IS vars
        #print(ispos)
        #ispos = [self.varnames.tolist().index(i) for i in self.isvars]  # Position of IS vars

        # adjust index array to include isvars
        # Initialised up front: the repeat-call branch below skips the block
        # that (re)assigns it, so this guarantees it is always bound.
        where_h = 0
        
        if len(self.isvars) > 0 and not hasattr(self, 'ispos'):  # check not done before...
            #self.fxidx = np.insert(np.array(self.fxidx, dtype="bool_"), 0,
                                #   np.repeat(True, len(self.isvars)*(J - 1)))
            where_h = ispos
            where_h =0


            self.restate_idx(ispos, isvars, asvars)
            # Each individual-specific variable expands into (J-1) alternative-specific
            # columns. Decide, per expanded column, whether it is a FIXED or a RANDOM
            # coefficient based on whether the isvar was requested in randvars. The
            # column order matches the isvar design block below: for isvar in isvars,
            # for each non-base alternative. This enables random coefficients on
            # individual-specific variables and on the ASCs (intercept).
            # Per-alternative random coefficients on individual-specific vars.
            # A column ``isvar.alt`` is RANDOM when either the exact per-alt key
            # ``"{isvar}.{alt}"`` is present in randvars (random on JUST that
            # alternative), or the base-name key ``isvar`` is present (random on
            # EVERY alternative -- the legacy behaviour, kept for backward
            # compatibility). Column order matches the isvar design block below:
            # for each isvar, for each non-base alternative (in self.alts order).
            _nonbase_alts = [j for j in self.alts if j != self.base_alt]
            _rand_keys = set(str(k) for k in self.randvars)
            isvar_rand_block = np.array(
                [(str(iv) in _rand_keys) or ("{}.{}".format(iv, j) in _rand_keys)
                 for iv in isvars for j in _nonbase_alts],
                dtype="bool_")
            isvar_fix_block = ~isvar_rand_block
            self.fxidx =np.insert(np.array(self.fxidx, dtype="bool_"), where_h, isvar_fix_block)
            self.fxtransidx = np.insert(np.array(self.fxtransidx, dtype="bool_"), where_h, np.repeat(False, len(self.isvars)*(J - 1)))
            #self.fxtransidx = np.insert(np.array(self.fxtransidx, dtype="bool_"),
                                      #  0, np.repeat(False, len(self.isvars)*(J - 1)))
            if hasattr(self, 'rvidx'):
                self.rvidx = np.insert(np.array(self.rvidx, dtype="bool_"), where_h,
                                       isvar_rand_block)
            if hasattr(self, 'rvtransidx'):
                self.rvtransidx = np.insert(np.array(self.rvtransidx, dtype="bool_"),
                                            0, np.repeat(False, len(self.isvars)*(J - 1)))
        else:
            self.restate_idx(ispos, isvars, asvars)
            # Repeat call on an already-fitted model (e.g. prediction): the
            # index arrays were NOT re-expanded above (guarded by 'ispos'),
            # which desynced them from the expanded design matrix. Top up the
            # isvar/intercept block when it is missing. Idempotent.
            if len(self.isvars) > 0 and hasattr(self, 'fxidx') \
                    and len(self.fxidx) == len(self.asvars):
                _nonbase_alts = [j for j in self.alts if j != self.base_alt]
                _rand_keys = set(str(k) for k in getattr(self, 'randvars', []) or [])
                _rand_block = np.array(
                    [(str(iv) in _rand_keys) or ("{}.{}".format(iv, j) in _rand_keys)
                     for iv in self.isvars for j in _nonbase_alts],
                    dtype="bool_")
                self.fxidx = np.insert(np.array(self.fxidx, dtype="bool_"), 0, ~_rand_block)
                self.fxtransidx = np.insert(np.array(self.fxtransidx, dtype="bool_"), 0,
                                            np.repeat(False, len(self.isvars) * (J - 1)))
                if hasattr(self, 'rvidx'):
                    self.rvidx = np.insert(np.array(self.rvidx, dtype="bool_"), 0, _rand_block)
                if hasattr(self, 'rvtransidx'):
                    self.rvtransidx = np.insert(np.array(self.rvtransidx, dtype="bool_"), 0,
                                                np.repeat(False, len(self.isvars) * (J - 1)))



        if self.transformation == "boxcox":
            self.trans_func = boxcox_transformation
            self.transform_deriv = boxcox_param_deriv

        S = np.zeros((self.N, self.P, self.J))
        for i in range(self.N):
            S[i, 0:self.P_i[i], :] = 1
        self.S = S
   
        #ispos = [self.varnames.tolist().index(i) for i in self.isvars[self.isvars != '_inter']]  # Position of IS vars
        aspos = [self.varnames.tolist().index(i) for i in asvars_construct_matrix]  # Position of AS vars
        self.aspos = np.array(aspos) # saved for later use
        self.ispos = np.array(ispos)

        # **Add Validation for asvars**
        '''
        if asvars_construct_matrix:

            for asvar in asvars_construct_matrix:
                asvar_data = X[:, lst.index(asvar)].reshape(N, J)
                if np.all(asvar_data == asvar_data[0, :]):  # Check if all rows are identical
                    raise ValueError(
                        f"Alternative-specific variable '{asvar}' has the same data "
                        f"for all individuals across alternatives. This will prevent "
                        f"capturing alternative-specific effects."
                    )
                '''




        _vn_list = self.varnames.tolist()
        randpos = [_vn_list.index(i) for i in randvars if i in _vn_list]  # Position of random vars (per-alt keys like 'var.alt' aren't base varnames -> skipped)
        randtranspos = [self.varnames.tolist().index(i) for i in randtransvars]  # bc transformed variables with random coeffs
        fixedtranspos = [self.varnames.tolist().index(i) for i in fixedtransvars]  # bc transformed variables with fixed coeffs


        self.correlationpos = []
        self.uncorrelatedpos = []
        if randvars:
            self.correlationpos = [lst.index(str) for str in self.varnames if
                                   str in self.randvars]  # Position of correlated variables within randvars

        if (isinstance(self.correlated_vars, list)):
            # {
            self.correlationpos = [lst.index(str) for str in self.varnames if str in self.correlated_vars]
            self.uncorrelatedpos = [lst.index(str) for str in self.varnames if str not in self.correlated_vars and str in randvars]
        # }

        self.Kf = sum(self.fxidx)  # set number of fixed coeffs from idx
        # Number of random coefficients. Count directly from the (expanded) rvidx
        # mask so that random coefficients on individual-specific variables / ASCs,
        # which expand into (J-1) alternative-specific columns each, are counted
        # once per column rather than once per compact variable name.
        self.Kr = int(np.sum(self.rvidx)) if hasattr(self, 'rvidx') else len(randpos)  # was: len(randpos)
        self.Kftrans = len(fixedtranspos)  # Number of fixed coefficients of bc transformed vars
        self.Krtrans = len(randtranspos)  # Number of random coefficients of bc transformed vars
        self.Kchol = 0  # Number of random beta cholesky factors
        self.correlationLength = 0
        self.Kbw = self.Kr

        # set up length of betas required to estimate correlation and/or
        # random variable standard deviations, useful for cholesky matrix
        if (self.correlated_vars):
            if (isinstance(self.correlated_vars, list)):
                nb_corvars = len([v for v in self.correlated_vars if v in randvars])
                self.correlationLength = nb_corvars
                self.Kbw = self.Kr - nb_corvars
                self.Kchol = int((nb_corvars * (nb_corvars + 1)) / 2)
            else:
                self.correlationLength = self.Kr
                self.Kbw = 0
                nb_randvars = len(self.randvars)
                self.Kchol = int((nb_randvars * (nb_randvars + 1)) / 2)


        # Create design matrix
        # For individual specific variables
        Xis = None
        if len(self.isvars) or len(self.ispos):
            # {
            # Create a dummy individual specific variables for the alts
            dummy = np.tile(np.eye(J), reps=(P_N, 1))

            # Remove base alternative
            #print(self.alts)
            dummy = np.delete(dummy, np.where(self.alts == self.base_alt)[0], axis=1)
            Xis = X[:, self.ispos]

            if Xis.dtype == np.object_:
                Xis_numeric = pd.to_numeric(Xis.flatten(), errors='coerce').reshape(Xis.shape)
                Xis = Xis_numeric

            # Multiply dummy representation by the individual specific data
            try:

                Xis = np.einsum('nj,nk->njk', Xis, dummy, dtype="float64")
            except:
                Xis_numeric = pd.to_numeric(Xis.flatten(), errors='coerce').reshape(Xis.shape)
                Xis = Xis_numeric
                Xis = np.einsum('nj,nk->njk', Xis, dummy, dtype="float64")
                # Example of filtering out non-numeric data
                # Xis = np.array([x for x in Xis if isinstance(x, (int, float))], dtype='float64')
            nbOf = (self.J - 1) * len(self.ispos)
            try: #TODO this falls over for base alt
                Xis = Xis.reshape((P_N, self.J, nbOf))  # ERROR: UNEXPECTED ARGUMENT?
            except Exception as e:
                nbOf = (self.J) * len(self.ispos)
                Xis = Xis.reshape((P_N, self.J, nbOf))  # ERROR:TODO BASE ?


        # }
        else:  # {
            Xis = np.array([])
        # }
        # For alternative specific variables
        Xas = None
        if asvars_construct_matrix:
            Xas = X[:, aspos]
            Xas = Xas.reshape(N, J, -1)

        # Set design matrix based on existance of asvars and isvars
        if len(asvars_construct_matrix) and len(self.isvars):
            X = np.dstack((Xis, Xas))
        elif len(asvars_construct_matrix):
            X = Xas
        elif (len(self.isvars)):
            X = Xis
        else:
            x_varname_length = len(self.varnames)
            X = X.reshape(-1, len(self.alts), x_varname_length)

        intercept_names = [] #toddo remove

        names = ["{}.{}".format(isvar, j) for isvar in isvars for j in self.alts if j != self.base_alt]

        lambda_names_fixed = ["lambda.{}".format(transvar) for transvar in fixedtransvars]

        lambda_names_rand = ["lambda.{}".format(transvar) for transvar in randtransvars]

        randvars = [x for x in self.varnames if x in self.randvars]
        randvars = np.array(randvars, dtype='<U64')

        asvars_names = [x for x in asvars if (x not in self.randvars) and
                        (x not in fixedtransvars) and (x not in randtransvars)]


        chol = ["chol." + self.varnames[self.correlationpos[i]] + "." +
                self.varnames[self.correlationpos[j]] for i
                in range(self.correlationLength) for j in range(i + 1)]

        br_w_names = []

        # three cases for corr. varnames: no corr, corr list, corr Bool (All)
        if not (self.correlated_vars is True or isinstance(self.correlated_vars, list)):
            if hasattr(self, "rvidx"):  # avoid errors with multinomial logit
                br_w_names = np.char.add("sd.", randvars)

        if (isinstance(self.correlated_vars, list)):  # if not all r.v.s correlated
            # {


            names_for_p = self.varnames
            sd_uncorrelated_pos = [lst.index(str) for str in names_for_p
                                   if str not in self.correlated_vars and str in randvars]
            br_w_names = np.char.add("sd.", names_for_p[sd_uncorrelated_pos])
        # }

        sd_rand_trans = np.char.add("sd.", self.varnames[randtranspos])
        
        #if isvars then isvars gets positionemed to fromt
        if len(self.isvars) >0:
            #print('ordered names. DEBUG PRINT')

            inter_o = []

            names_o = [isvar for isvar in isvars for j in self.alts if j != self.base_alt]
            restvars = [var for var in self.varnames if var not in names_o and var not in inter_o]
            self.ordered_varnames = names_o + restvars




            
        else:
            self.ordered_varnames = self.varnames
        #np.insert(np.array(self.varnames, dtype="<U64"), 0, '_inter')

        # ------------------------------------------------------------------
        # Random coefficients on individual-specific variables / ASCs.
        # When any isvar is random, its (J-1) alternative-specific columns move
        # from the fixed block (Bf) to the random-mean block (Br_b), so the
        # coefficient-name vector must follow the beta layout
        # [fixed | random-mean | sd] in expanded design-column order rather than
        # the compact isvar-name order used by the legacy path below. This branch
        # covers the uncorrelated, untransformed case; correlated/Box-Cox models
        # keep the original construction.
        _rk_simple = set(str(k) for k in self.randvars)
        has_rand_isvar = any(
            (str(iv) in _rk_simple) or any(k.startswith(str(iv) + ".") for k in _rk_simple)
            for iv in isvars)
        simple_case = (has_rand_isvar and not self.correlated_vars
                       and len(fixedtransvars) == 0 and len(randtransvars) == 0)
        if simple_case:
            isvar_block_names = ["{}.{}".format(isvar, j)
                                 for isvar in isvars for j in self.alts
                                 if j != self.base_alt]
            asvar_col_names = list(asvars_construct_matrix)
            col_names = list(isvar_block_names) + asvar_col_names  # length K, design order
            fxidx = np.asarray(self.fxidx, dtype=bool)
            rvidx = np.asarray(self.rvidx, dtype=bool)
            fixed_names = [col_names[i] for i in range(len(col_names)) if fxidx[i]]
            rand_mean_names = [col_names[i] for i in range(len(col_names)) if rvidx[i]]
            sd_names = ["sd." + col_names[i] for i in range(len(col_names)) if rvidx[i]]
            names = np.array(fixed_names + rand_mean_names + sd_names, dtype="<U64")
            # Align the random-coefficient distribution list with the expanded
            # random columns (one entry per random column, in design order) so
            # that each alternative-specific random coefficient's Halton draws
            # are transformed to its correct distribution. Previously self.rvdist
            # carried one entry per *base* varname, so with a random isvar
            # spanning multiple alternatives only the first column was
            # distribution-transformed (the rest stayed uniform); with
            # per-alternative keys every random var is a single column and relies
            # on this alignment being correct.
            _rvd = getattr(self, "randvarsdict", None) or {}
            def _dist_for_col(_cn):
                _cn = str(_cn)
                if _cn in _rvd:                       # exact per-alt key, e.g. 'alone.bike'
                    return _rvd[_cn]
                return _rvd.get(_cn.split(".")[0], "n")  # base-name key, e.g. 'alone'
            self.rvdist = [_dist_for_col(col_names[i])
                           for i in range(len(col_names)) if rvidx[i]]
            return X, names

        names = np.concatenate((intercept_names, names, asvars_names, randvars,
                                chol, br_w_names, fixedtransvars,
                                lambda_names_fixed, randtransvars,
                                sd_rand_trans, lambda_names_rand))

        names = np.array(names, dtype="<U64")
        return X, names

    ''' ---------------------------------------------------------- '''
    ''' Function. Check data is in long format                     '''
    ''' ---------------------------------------------------------- '''
    def check_long_format_consistency(self, ids, alts, sorted_idx):
    # {
        alts = alts[sorted_idx]
        uq_alt = np.unique(alts)

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # Unused code:
        # expect_alt = np.tile(uq_alt, int(len(ids)/len(uq_alt)))
        # if not np.array_equal(alts, expect_alt):
        #     raise ValueError('inconsistent alts values in long format')
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        _, obs_by_id = np.unique(ids, return_counts=True)

        """ An error is raised if the array of alternative indexes is incomplete. """
        if np.any(obs_by_id % len(uq_alt) != 0):  # Multiple of J
            raise ValueError('inconsistent alts and ids values in long format')
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function. Check for data consistency.Set to lonf format    '''
    ''' ---------------------------------------------------------- '''
    def arrange_long_format(self, X, y, ids, alts, panels=None):
    # {
        if ids is not None:
        # {
            pnl = panels if panels is not None else np.ones(len(ids))
            alts = alts.astype(str)
            alts = alts if len(alts) == len(ids) else np.tile(alts, int(len(ids) / len(alts)))
            cols = np.zeros(len(ids), dtype={'names': ['panels', 'ids', 'alts'], 'formats': ['<f4', '<f4', '<U64']})
            cols['panels'], cols['ids'], cols['alts'] = pnl, ids, alts  # Record

            # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            # Unused code:
            # sorted_idx = np.argsort(cols, order=['panels', 'ids', 'alts'])
            # X, y = X[sorted_idx], y[sorted_idx]
            # if panels is not None: panels = panels[sorted_idx]
            # self._check_long_format_consistency(ids, alts, sorted_idx)
        # }
        return X, y, panels
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function. Validate potential mistakes in the input data    '''
    ''' ---------------------------------------------------------- '''
    def validate_inputs(self, X, y, alts, varnames):
    # {
        if varnames is None:
            raise ValueError('The parameter varnames is required')
        if alts is None:
            raise ValueError('The parameter alternatives is required')
        if X.ndim != 2:
            raise ValueError("X must be an array of two dimensions in long format")
        if y.ndim != 1:
            raise ValueError("y must be an array of one dimension in long format")
        if len(varnames) != X.shape[1]:
            raise ValueError("The length of varnames must match the number of columns in X")
    # }

    ''' ------------------------------------------------------------- '''
    ''' Function. Regularization of the loglike                       '''
    ''' Flag affects whether penalty is added or subtracted           '''
    ''' ------------------------------------------------------------- '''
    def regularize_loglik(self, betas, negative=False):
    # {
        penalty = self.reg_penalty * np.sum(np.square(betas))
        return -penalty if negative else penalty
    # }

    ''' ------------------------------------------------------------- '''
    ''' Function. L1 (lasso) regularization of the loglike            '''
    ''' Matches MetaCount regularise_l1 (corrected: uses abs not sq)  '''
    ''' ------------------------------------------------------------- '''
    def regularize_l1_loglik(self, betas, negative=False):
    # {
        penalty = self.l1_penalty * np.sum(np.abs(betas))
        return -penalty if negative else penalty
    # }

    def regularize_l1_grad(self, betas):
        """Gradient of the L1 penalty w.r.t. betas: l1_penalty * sign(betas)."""
        return self.l1_penalty * np.sign(betas)



    ''' ---------------------------------------------------------- '''                                                                       
    ''' Function. Compute the log-likelihood of the null model     '''
    ''' |y| = #samples * #choices                                  '''
    ''' ---------------------------------------------------------- '''
    def get_loglik_null(self):  # {
        y_arr = np.asarray(self.y)
        if y_arr.ndim == 1:
            # 1D chosen-alternative indices (e.g. regret models store argmax
            # choices, not one-hot rows). Equal-share null: -N*log(J).
            n = int(y_arr.shape[0])
            j = int(getattr(self, 'J', 0) or 0)
            if j < 1:
                j = int(getattr(self, 'nb_alt', 0) or 0)
            if j < 1:
                return float('-inf')
            return float(-n * np.log(float(j)))
        factor = 1.0 / self.J
        y_ = self.y * factor  # Scale each element by 1/J
        lik = np.sum(y_, axis=1)  # Compute row sums => |lik| = #samples
        lik =np.clip(lik, 0.00001, None)
        y_ = np.clip(y_, 0.00001, None)
        loglik = np.log(lik)  # Log each element
        loglik = np.sum(loglik)  # Sum the elements => LL of the null (equal-share) model
        return loglik
    # }

    '''Gets the estimated coefficients of the model.'''
    def get_coeff(self):

        if self.coeff_est is None:  # {
            warnings.warn("The current model has not been yet estimated", UserWarning)
            return
        else:
            return self.coeff_est
# }

    ''' ------------------------------------------------------------------
    Function. Out-of-sample calibration metrics computed directly from the
    estimated coefficient vector (no .predict() required).  Utilities are
    rebuilt on a long-format hold-out dataframe and top-1 accuracy plus
    aggregate share RMSE are returned.

    Supported coefficient-name forms:
        'var'          -> AS-dummy / plain column `var`
        'var.alt'      -> column `var` active on rows of alternative `alt`
        'intercept.a'  -> constant on rows of alternative `a`
    sd.*/lambda.*/chol.* prefixed names are ignored (they parameterise the
    mixing distribution, not the utility level).
    ------------------------------------------------------------------ '''
    def oos_metrics(self, df_test, alt_col="alt", choice_col="choice",
                    id_col="ind_id"):
        # {
        import numpy as _np

        if self.coeff_est is None:
            warnings.warn("The current model has not been yet estimated",
                          UserWarning)
            return None
        cn = [str(x) for x in _np.asarray(
            getattr(self, "coeff_names",
                    getattr(self, "labels", []))).ravel()]
        bv = _np.asarray(getattr(self, "coeff_est",
                                 getattr(self, "beta", [])),
                         dtype=float).ravel()
        if not cn or len(cn) != len(bv):
            return None

        df = df_test
        alt_v = df[alt_col].values
        U = _np.zeros(len(df), dtype=float)
        for c, b in zip(cn, bv):
            if c.startswith(("sd.", "lambda.", "chol.")):
                continue
            if c.startswith("intercept"):
                a = c.split(".", 1)[1] if "." in c else ""
                U = U + b * (alt_v == a)
            elif "." in c:
                v, a = c.rsplit(".", 1)
                if v in df.columns:
                    U = U + b * df[v].values * (alt_v == a)
            elif c in df.columns:
                U = U + b * df[c].values

        grp = df[id_col].values
        order = _np.argsort(grp, kind="stable")
        U_s, g_s = U[order], grp[order]
        ch = df[choice_col].values[order]
        alt_sorted = alt_v[order]
        bounds = _np.flatnonzero(
            _np.r_[True, g_s[1:] != g_s[:-1]]).tolist() + [len(g_s)]

        alt_names = list(dict.fromkeys(alt_v.tolist()))
        aidx = {a: i for i, a in enumerate(alt_names)}
        n_alts = len(alt_names)
        acc_hits, n_obs = 0, 0
        pred_sh = _np.zeros(n_alts)
        obs_sh = _np.zeros(n_alts)
        for s0, s1 in zip(bounds[:-1], bounds[1:]):
            u = U_s[s0:s1]
            c_blk = ch[s0:s1]
            k = int(_np.argmax(c_blk))
            acc_hits += 1 if int(_np.argmax(u)) == k else 0
            e = _np.exp(u - u.max())
            p = e / e.sum()
            for j in range(len(p)):
                pred_sh[aidx[alt_sorted[s0 + j]]] += p[j]
                if j == k:
                    obs_sh[aidx[alt_sorted[s0 + j]]] += 1
            n_obs += 1

        acc = acc_hits / max(n_obs, 1)
        obs_sh /= max(n_obs, 1)
        pred_sh /= max(n_obs, 1)
        share_rmse = float(_np.sqrt(_np.mean((pred_sh - obs_sh) ** 2)))
        return dict(acc=float(acc), test_mae=float(1.0 - acc),
                    share_rmse=share_rmse,
                    observed_share=dict(zip(alt_names,
                                            obs_sh.round(6).tolist())),
                    predicted_share=dict(zip(alt_names,
                                             pred_sh.round(6).tolist())),
                    n_obs=int(n_obs))
    # }


    def summarise(self, file=None, dashboard=True):
    # {
        LINE = "-" * 70
        LINE2 = "-" * 20

        def p(text=""):
            print(text, file=file)

        def section(title):
            p(LINE)
            p(f"  {title}")
        
        def to_set(attr):
            val = getattr(self, attr, None)
            if val is None:
                return set()
            if hasattr(val, '__len__') and len(val) == 0:
                return set()
            if isinstance(val, np.ndarray):
                return set(val.tolist())
            if isinstance(val, dict):
                return set(val.keys())
            return set(val)

        # Models that never set coeff_names crashed below with
        # TypeError: 'NoneType' object is not iterable. Derive from
        # labels/varnames so every fitted model can summarise.
        if getattr(self, 'coeff_names', None) is None:
            _lbl = getattr(self, 'labels', None)
            if _lbl is None:
                _lbl = getattr(self, 'varnames', []) or []
            try:
                self.coeff_names = [str(v) for v in list(_lbl)]
            except Exception:
                self.coeff_names = []

        is_latent_class = hasattr(self, 'n_classes') and hasattr(self, 'class_betas')

        # ── Header ──────────────────────────────────────────────────────────
        p(LINE)
        # Model name + time
        time_str = f"  Time: {self.estim_time_sec:.1f}s"
        n_draws = getattr(self, 'n_draws', None)
        if n_draws:
            time_str += f"  |  Draws: {n_draws}"
        p(f"  Model Summary: {self.descr}")
        if time_str:
            p(time_str)

        # Sample info
        N = getattr(self, 'N', None)
        if N is None:
            # Models such as RandomRegret track the sample size as nb_samples
            # and never set N/P/panel_info. Fall back so summarise() is generic.
            N = getattr(self, 'nb_samples', None)
        P = getattr(self, 'P', None)
        if getattr(self, "panel_info", None) is not None:
            obs = self.panel_info.sum(axis=1).astype(int)
            mn, mx = int(obs.min()), int(obs.max())
        else:
            mn = mx = 1
        if N is not None:
            if P is not None and P > 1:
                total = getattr(self, 'sample_size', N * P)
                p(f"  Individuals: {N}  |  Choices per Individual: {mx if mn == mx else f'{mn}-{mx}'}  |  Total Choices: {total}")
            else:
                p(f"  Individuals: {N}")

        # Convergence warning
        if not self.converged:
            p(LINE)
            p("  WARNING: Convergence was not reached. Estimates may not be reliable.")
            if is_latent_class:
                p(f"  EM iterations: {self.total_iter}  (maxiter reached)")
            elif hasattr(self, "gtol_res") and hasattr(self, "ftol_res"):
                gtol_ok = "OK" if self.gtol_res < self.gtol else "X"
                ftol_ok = "OK" if self.ftol_res < self.ftol else "X"
                p(f"  gtol: {self.gtol}  |  Final gradient norm: {self.gtol_res:.2e}  {gtol_ok}")
                p(f"  ftol: {self.ftol}  |  Final function value: {self.ftol_res:.2e}  {ftol_ok}")
                if gtol_ok == "X" and hasattr(self, "grad_vector") and self.coeff_names is not None:
                    failing = [(self.coeff_names[k], self.grad_vector[k])
                            for k in range(len(self.coeff_names))
                            if abs(self.grad_vector[k]) > self.gtol]
                    if failing:
                        p(f"  Parameters not meeting gtol threshold:")
                        for name, gval in failing:
                            p(f"    {name:<30}  grad = {gval:.4e}")

        # ── Proportion of Alternatives ───────────────────────────────────────
        if hasattr(self, 'pred_prob') and hasattr(self, 'obs_prob'):
            p(LINE)
            p("  Proportion of Alternatives")
            alts = getattr(self, 'alts', [f"alt{i+1}" for i in range(len(self.obs_prob))])
            label_w = 12
            col_w   = 9
            alt_header = " " * (label_w + 2) + "".join(f"{str(a):>{col_w}}" for a in alts)
            obs_row    = f"  {'Observed:':<{label_w}}" + "".join(f"{v:>{col_w}.3f}" for v in self.obs_prob)
            pred_row   = f"  {'Predicted:':<{label_w}}" + "".join(f"{v:>{col_w}.3f}" for v in self.pred_prob)
            p(alt_header)
            p(obs_row)
            p(pred_row)

        if is_latent_class:
            p(LINE)
            p("  Estimated Proportion of Classes")
            p(f"  {np.round(self.class_probs, 3)}")
        elif hasattr(self, 'class_freq'):
            p(LINE)
            p("  Estimated Proportion of Classes")
            p(f"  {np.round(self.class_freq, 3)}")

        # ── Coefficient classification ───────────────────────────────────────
        if self.coeff_est is None:
            p(LINE)
            p("  Model has not been estimated.")
            return

        # ── Shared table format (both branches) ───────────────────────────────
        sig_map = {0.001: "(***)", 0.01: "(**)", 0.05: "(*)", 0.1: "(.)", 1.01: "(-)"}
        fmt = "  {:<16} {:<6} {:>10.4f} {:>10.4f} {:>9.3f} {:>9.3f} {:<4}"
        hdr = "  {:<16} {:<6} {:>9} {:>9} {:>10} {:>12}".format("Variable", "Distr", "Coeff", "SE", "z-val", "p-val")

        def sig(pv):
            try:
                return next(s for thr, s in sig_map.items() if pv < thr)
            except StopIteration:
                return ""

        # ══════════════════════════════════════════════════════════════════
        # LATENT CLASS BRANCH 
        # ══════════════════════════════════════════════════════════════════
        if is_latent_class:
            C  = self.n_classes
            Km = getattr(self, 'K_membership', 0)

            se_error = getattr(self, 'se_computation_error', None)
            if se_error is not None:
                p(f"  [WARNING] Standard errors could not be computed: {se_error}")

            if se_error is not None or self.pvalues is None:
                p("  Class Shares:")
                for idx, share in enumerate(self.class_probs, start=1):
                    p(f"    class_{idx}: {share:.6f}")
                p("  Coefficients:")
                for c_idx, beta in enumerate(self.class_betas, start=1):
                    idx = self._class_specs[c_idx - 1] if self._class_specs is not None else range(len(beta))
                    for k, value in zip(idx, beta):
                        name = self.varnames[k]
                        p(f"    class_{c_idx}_{name}: {value:.6f}")
                
                if self.class_gammas is not None and self._has_membership and self.optimise_membership:
                    gammas_arr = np.asarray(self.class_gammas)
                    p("  Membership Parameters:")
                    for c in range(self.n_classes - 1):
                        for k in range(gammas_arr.shape[1]):
                            label = f"gamma_{c + 1}_{self.membership_vars[k]}"
                            p(f"    {label}: {gammas_arr[c, k]:.6f}")
                return

            params   = self.se_params
            se       = self.stderr
            t_stats  = self.zvalues
            p_values = self.pvalues
            n_phi    = C - 1
            has_gamma = self.gamma_params is not None and len(self.gamma_params) > 0

            p(LINE)
            p(hdr)

            offset_cum = n_phi
            for c in range(C):
                K_c = self._Ks[c]
                is_base = (c == C - 1)
                p("")
                label = f"CLASS {c + 1}   (share = {self.class_probs[c]:.3f})"
                if is_base:
                    label += "   (Base)"
                section(label)
                p(LINE)

                p("  Class Parameters")
                p(LINE2)
                idx = self._class_specs[c]
                for k in range(K_c):
                    vname = self.varnames[idx[k]]
                    pi = offset_cum + k
                    p(fmt.format(vname[:16], "", params[pi], se[pi], t_stats[pi], p_values[pi], sig(p_values[pi])))
                offset_cum += K_c
            
                if not is_base and has_gamma:
                    p("")
                    p("  Membership Parameters")
                    g0 = c * Km
                    for k in range(Km):
                        gi = g0 + k
                        gname = self.gamma_names[gi]
                        p(fmt.format(gname[:16], "", self.gamma_params[gi], self.gamma_se[gi],
                                    self.gamma_t_stats[gi], self.gamma_p_values[gi],
                                    sig(self.gamma_p_values[gi])))
            p()
            section("GOODNESS OF FIT")
            p(LINE)
            
            loglik_null = self.get_loglik_null()
            adjlik = 1 - (self.loglik / loglik_null)
            self.adjust_lik_ratio = adjlik

            p("  In-Sample")
            p(f"  LOGLIK = {self.loglik:.0f}  |  AIC = {self.aic:.0f}  |  BIC = {self.bic:.0f}  |  McFadden Adj.R²: = {adjlik:.3f}")
            mae = getattr(self, 'mae', None)
            if mae is not None:
                p("")
                p("  Out-of-Sample")
                p(f"  MAE = {mae:.4f}")

            p(LINE)
            p("  Significance:  0 '(***)' 0.001 '(**)' 0.01 '(*)' 0.05 '(.)' 0.1 '(-)' 1")
            p(LINE)
            return

        # ══════════════════════════════════════════════════════════════════
        #  MNL / MXL 
        # ══════════════════════════════════════════════════════════════════
        randvars_dict     = getattr(self, 'randvarsdict', None) or {}
        if isinstance(randvars_dict, np.ndarray):
            randvars_dict = {}
        transvars_set     = to_set('transvars')
        randtransvars_set = to_set('randtransvars')
        randvars_set      = set(randvars_dict.keys())

        # Recognise per-alternative expansions of random individual-specific
        # variables / ASCs (e.g. "male.bicycling") as random parameters, so their
        # means and matching sd.* terms are reported under RANDOM PARAMETERS
        # rather than misclassified as fixed.
        if randvars_dict and getattr(self, 'coeff_names', None) is not None:
            base_dists = dict(randvars_dict)
            expanded = {}
            for nm in self.coeff_names:
                s = str(nm)
                if s in base_dists or s.startswith(('sd.', 'chol.', 'lambda.')):
                    continue
                base = s.rsplit('.', 1)[0] if '.' in s else s
                if base in base_dists:
                    expanded[s] = base_dists[base]
            if expanded:
                randvars_dict = {**randvars_dict, **expanded}
                randvars_set = set(randvars_dict.keys())

        # Build ordered output: group coefficients by type
        # Each group is a list of (display_name, coeff_idx)
        intercept_rows   = []
        fixed_rows       = []
        random_rows      = []   # mean + sd paired
        trans_rows       = []   # var + lambda paired
        rand_trans_rows  = []   # mean + sd + lambda grouped

        # Track which indices have been assigned
        assigned = set()

        # Helper: find sd. index for a variable
        def find_sd(var):
            for i, n in enumerate(self.coeff_names):
                if n == f"sd.{var}":
                    return i
            
            for i, n in enumerate(self.coeff_names):
                if n == f"chol.{var}.{var}":
                    return i
            return None

        # Helper: find lambda. index for a variable
        def find_lambda(var):
            for i, n in enumerate(self.coeff_names):
                if n == f"lambda.{var}":
                    return i
            return None

        for i, name in enumerate(self.coeff_names):
            if i in assigned:
                continue

            # Intercepts
            if 'intercept' in name.lower():
                intercept_rows.append((name, "", i))
                assigned.add(i)

            # chol. => belongs to random section, added later with its variable
            elif name.startswith('chol.'):
                pass  # handled separately in correlation matrix

            # sd. of random variable => handled when processing the mean
            elif name.startswith('sd.'):
                pass  # handled with mean

            # lambda. of fixed transformed => handled with its variable
            elif name.startswith('lambda.'):
                pass

            # Random transformed variable mean
            elif name in randtransvars_set:
                distr = randvars_dict.get(name, '')
                row = [(name, distr, i)]
                assigned.add(i)
                sd_i = find_sd(name)
                if sd_i is not None:
                    row.append((f"sd.{name}", "", sd_i))
                    assigned.add(sd_i)
                lm_i = find_lambda(name)
                if lm_i is not None:
                    row.append((f"lambda.{name}", "", lm_i))
                    assigned.add(lm_i)
                rand_trans_rows.extend(row)

            # Random variable mean
            elif name in randvars_set:
                distr = randvars_dict.get(name, '')
                random_rows.append((name, distr, i))
                assigned.add(i)
                sd_i = find_sd(name)
                if sd_i is not None:
                    random_rows.append((f"sd.{name}", "", sd_i))
                    assigned.add(sd_i)

            # Fixed transformed variable
            elif name in transvars_set:
                trans_rows.append((name, "", i))
                assigned.add(i)
                lm_i = find_lambda(name)
                if lm_i is not None:
                    trans_rows.append((f"lambda.{name}", "", lm_i))
                    assigned.add(lm_i)

            # Fixed
            else:
                fixed_rows.append((name, "", i))
                assigned.add(i)
                
        for i, name in enumerate(self.coeff_names):
            if name.startswith('chol.'):
                assigned.add(i)

        p(LINE)
        p(hdr)

        def print_rows(title, rows):
            if not rows:
                return
            section(title)
            p(LINE2)
            for name, distr, idx in rows:
                signif = sig(self.pvalues[idx])
                active = getattr(self, 'active_bounds', {}).get(idx)
                bound_flag = " (A.B)" if active else ""
                p(fmt.format(
                    name[:16],
                    distr,
                    #self.coeff_est[idx],
                    abs(self.coeff_est[idx]) if name.startswith('sd.') or (name.startswith('chol.') and name.split('.')[1] == name.split('.')[2]) else self.coeff_est[idx],
                    self.stderr[idx],
                    _clip_zval(self.zvalues[idx]),
                    self.pvalues[idx],
                    signif + bound_flag
                ))
        print_rows("INTERCEPTS",              intercept_rows)
        print_rows("FIXED PARAMETERS",        fixed_rows)
        print_rows("RANDOM PARAMETERS",       random_rows)
        print_rows("TRANSFORMED PARAMETERS",  trans_rows)
        print_rows("RANDOM TRANSFORMED PARAMETERS", rand_trans_rows)

        # ── Correlation Matrix ───────────────────────────────────────────────
        corr_mat = getattr(self, 'corr_mat', None)
        corr_pos = getattr(self, 'correlationpos', [])
        has_correlation = (
            corr_mat is not None and
            len(corr_pos) >= 2 and
            getattr(self, 'Kchol', 0) > 0 and
            getattr(self, 'correlationLength', 0) >= 2 )
        
        if has_correlation:
            section("CORRELATION MATRIX")
            p(LINE)
            corr_names = [str(self.varnames[p_]) for p_ in corr_pos]
            K = len(corr_names)

            sig_map_corr = {0.001: " (***)", 0.01: " (**)", 0.05: " (*)", 0.1: " (.)", 1.01: " (-)"}
            chol_pval = {}
            for ii in range(K):
                for jj in range(ii):
                    key = f"chol.{corr_names[ii]}.{corr_names[jj]}"
                    for ci, cn in enumerate(self.coeff_names):
                        if cn == key:
                            chol_pval[(ii, jj)] = self.pvalues[ci]
                            break

            p("  " + " " * 14 + "".join(f"{n:>14}" for n in corr_names))
            for i in range(K):
                row_str = f"  {corr_names[i]:<14}"
                for j in range(K):
                    if j < i:
                        val = corr_mat[i, j]
                        pv  = chol_pval.get((i, j), 1.0)
                        sigc = next(s for thr, s in sig_map_corr.items() if pv < thr)
                        row_str += f"{val:>8.3f}{sigc:<6}"
                    elif j == i:
                        row_str += f"{'1.000':>8}    "
                    else:
                        row_str += " " * 12
                p(row_str)

        # ── Goodness of Fit ──────────────────────────────────────────────────
        section("GOODNESS OF FIT")
        p(LINE)
        
        loglik_null = self.get_loglik_null()
        adjlik = 1 - (self.loglik / loglik_null)
        self.adjust_lik_ratio = adjlik
        
        
        p("  In-Sample")
        p(f"  LOGLIK = {self.loglik:.0f}  |  AIC = {self.aic:.0f}  |  BIC = {self.bic:.0f}  |  McFadden Adj.R²: = {adjlik:.3f}")
        
        if self.mae is not None:
            p("")
            p("  Out-of-Sample")
            p(f"  MAE = {self.mae:.4f}")

        p(LINE)
        p("  Significance:  0 '(***)' 0.001 '(**)' 0.01 '(*)' 0.05 '(.)' 0.1 '(-)' 1")
        p(LINE)
        #if file is None and dashboard:         
            #generate_est_dashboard(model=self)
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function. Print the coefficients and estimation outputs    '''
    ''' ---------------------------------------------------------- '''
    def summarise_Zeke(self, file=None):
    # {
        print("", file=file)
        print(f"Choice Model: {self.descr}", file=file)

        if self.coeff_est is None: # {
            warnings.warn("The current model has not been yet estimated", UserWarning)
            return
        # }

        if not self.converged: # {
            print("-" * 50, file=file)
            print("WARNING: Convergence was not reached during estimation. "
                  "The given estimates may not be reliable", file=file)
            if hasattr(self, "gtol_res"):
                print("gtol:", self.gtol, file=file)
                print("Final gradient norm:", self.gtol_res, file=file)
            print('*' * 50, file=file)
        # }

        print("Estimation time= {:.1f} seconds".format(self.estim_time_sec), file=file)

        if hasattr(self, 'pred_prob'):
        # {
            print("", file=file)
            print("Proportion of alternatives: observed choice", file=file)
            print(self.obs_prob, file=file)

            # CONCEPTUAL ERROR: obs_prob is not defined

            print("", file=file)
            print("Proportion of alternatives: predicted choice", file=file)
            print(self.pred_prob, file=file)
        # }

        if hasattr(self, 'class_freq'): # {
            print("", file=file)
            print("Estimated proportion of classes", file=file)
            print(self.class_freq, file=file)
        # }

        print("", file=file)
        print("Table.", file=file)
        COL_NAME = 32
        fmt = f"{{:{COL_NAME}}} {{:13.6f}} {{:13.6f}} {{:10.4f}} {{:11.4g}} {{:3}}"
        SEP = "-" * (COL_NAME + 13 + 13 + 10 + 11 + 8)

        print(SEP, file=file)
        print(f"{'Coefficient':{COL_NAME}} {'Estimate':>13} {'Std.Err.':>13} {'z-val':>10} {'P>|z|':>11}",
              file=file)
        print(SEP, file=file)

        significance_symbols = {0.001: "***", 0.01: "**", 0.05: "*", 0.1: ".", 1.01: ""}

        pvalues  = self.pvalues  if self.pvalues  is not None else [float("nan")] * len(self.coeff_est)
        stderr   = self.stderr   if self.stderr   is not None else [float("nan")] * len(self.coeff_est)
        zvalues  = self.zvalues  if self.zvalues  is not None else [float("nan")] * len(self.coeff_est)

        for i, coeff in enumerate(self.coeff_est):
            pv = float(pvalues[i])
            signif = next(
                (sym for thr, sym in significance_symbols.items() if pv < thr),
                ""
            )
            name = str(self.coeff_names[i])[:COL_NAME]
            se   = float(stderr[i])
            zv   = _clip_zval(zvalues[i])
            print(fmt.format(name, float(coeff), se, zv, pv, signif), file=file)

        print(SEP, file=file)
        print("Significance:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1", file=file)
        print("", file=file)

        text = f"LOGLIK = {self.loglik:0.3f}; AIC = {self.aic:0.3f}; BIC = {self.bic:0.3f};"

        if self.mae is not None:
            text += f"MAE= {self.mae:0.3f};"

        loglik_null = self.get_loglik_null()
        num_params = len(self.coeff_est) if self.coeff_est is not None else 0
        mcfadden_adj_r2 = 1 - ((self.loglik - num_params) / loglik_null)   # equiv. 1-(LL-k)/LL_null
        self.adjust_lik_ratio = mcfadden_adj_r2

        text += f" McFadden Adj.R²: {mcfadden_adj_r2:.4f}"
        print(text, file=file)
    # }


    ''' ---------------------------------------------------------- '''
    ''' Function.                                                  '''
    ''' ---------------------------------------------------------- '''
    def print_matrix(self, str_mat, descr): # {
        print(descr)
        fmt = "{:11}"
        for row in str_mat:
            for el in row: print(fmt.format(el), end='  ')
            print('')
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function.                                                  '''
    ''' ---------------------------------------------------------- '''
    def setup_print(self, mat):
    # {
        corr_varnames = [self.varnames[pos] for pos in self.correlationpos]
        K = len(corr_varnames)
        str_mat = np.array([], dtype="<U64")
        str_mat = np.append(str_mat, np.array([''] + corr_varnames))  # top row of coeff names
        mat = np.round(mat[0:K, 0:K], 8)

        # ____________________________________________________
        if dev.using_gpu: mat = dev.convert_array_cpu(mat)
        # ____________________________________________________

        for ii, row in enumerate(mat): # {
            str_mat = np.append(str_mat, corr_varnames[ii])
            str_mat = np.append(str_mat, np.array(row))
        # }
        str_mat = str_mat.reshape((K + 1, K + 1))  # + 1 for coeff names row/col
        return str_mat
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function. Print  matrix                                    '''
    ''' ---------------------------------------------------------- '''
    def print_mat(self, mat, descr): # {
        str_mat = self.setup_print(mat)
        self.print_matrix(str_mat, descr)
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function. Return fitted values                             '''
    ''' ---------------------------------------------------------- '''
    def fitted(self, type="parameters"): # {
        if type == "parameters" and hasattr(self, 'pch2_res'):
            return self.pch2_res
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function                                                   '''
    ''' ---------------------------------------------------------- '''
    def print_stdev(self, stdevs, names): # {
        fmt = "{:11}"
        print('Standard Deviations')
        for name in names: print(fmt.format(name), end='  ')
        print('')
        for std in stdevs: print(fmt.format(std), end='  ')
        print('')
    # }

    ''' ---------------------------------------------------------- '''
    ''' Function. Print standard deviations for randvars           '''
    ''' ---------------------------------------------------------- '''
    def compute_stddev(self):
    # {
        # CONCEPTUAL ERROR: covariance_matrix is undefined - it is a member of class mixed_logit
        diags = np.diag(self.covariance_matrix)  # Grab the diagonals of the covariance_matrix matrix
        diags = np.sqrt(diags)
        diags = np.round(diags, 8)

        # CHECK: self.covariance_matrix = [0:n, 0:n] where n = len(corr_varnames)

        ''' QUERY: CAN THESE OPERATIONS BE DONE ONCE ON CLASS INITIALISATION? WHY DO THIS OVER AND OVER?'''
        self.corr_varnames = [self.varnames[pos] for pos in self.correlationpos]
        self.rv_names_noncorr = list(set(self.varnames) & set(self.randvars) - set(self.corr_varnames))
        self.rvtrans_names = list(set(self.varnames) & set(self.randtransvars))
        self.rv_names_all = self.corr_varnames + self.rv_names_noncorr + self.rvtrans_names

        # ERROR: randvarsdict is undefined!
        self.distributions_corr = [self.randvarsdict[name] for name in self.corr_varnames]
        self.distributions_rv = [self.randvarsdict[name] for name in self.rv_names_noncorr]
        self.distributions_rvtrans = [self.randvarsdict[name] for name in self.rvtrans_names]
        self.distributions = self.distributions_corr + self.distributions_rv + self.distributions_rvtrans

        stdevs = np.zeros(len(diags))  # Initialise an array of length len(diags) with zero

        # CONCEPTUAL ERROR: betas is undefined - from multinomial_logit.py and mixed_logit.py
        means = self.betas[self.Kf: self.Kf + self.Kr]
        for ii, val in enumerate(diags):
        # {
            distr = self.distributions[ii]
            if distr in ('n', 't'):
                stdev = val
            elif distr in ('ln', 'nln'):
                stdev = np.sqrt(np.exp(val ** 2) - 1) * np.exp(means[ii] + 0.5 * val ** 2)
            elif distr == 'u':
                stdev = (val ** 2) / 3
            else:
                stdev = -1  # ERROR NO DISTRIBUTION CHOSEN
            stdevs[ii] = np.round(stdev, 8)
        # }

        self.print_stdev(stdevs, self.rv_names_all)
    # }
# }