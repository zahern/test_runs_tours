import warnings
import argparse
import csv
import faulthandler
import sys
import timeit
from collections import namedtuple
import numpy as np
import pandas as pd
from addicty import Dict
#print('loading devices')

import os

# ---------------------------------------------------------------------------
# Console encoding safety net: the library's dashboards use box-drawing and
# arrow characters that crash print() outright when stdout uses a non-UTF-8
# codec (e.g. cp1252 Windows consoles / redirected output). Degrade gracefully
# to '?' replacements instead of raising UnicodeEncodeError mid-search.
# ---------------------------------------------------------------------------
try:
    import sys as _sys
    _enc = getattr(_sys.stdout, "encoding", None)
    if _sys.stdout is not None and _enc and _enc.lower().replace("-", "") not in ("utf8", "utf"):
        if hasattr(_sys.stdout, "reconfigure"):
            _sys.stdout.reconfigure(errors="replace")
except Exception:
    pass

try:
    from . import misc
except ImportError:
    import misc

try:
    from .banditsa import BanditSA, PerturbationBandit
except ImportError:
    from banditsa import BanditSA, PerturbationBandit

def new_features():
    '''ADDICTY DICT'''
    '''vars you want to ensure are included'''
    pre_spec_constraints = Dict({
        'ps_nest_vars': ['var_NMT_1', 'var_IPT_3'],
        'ps_alt_vars': ['var_ICT_1'],
        'force_include': ['TIME', 'COST'],  # Variables that must always be included
        'force_exclude': [],  # Variables that must never be included
        'force_random': {'TIME': 'n', 'COST': 'ln'},  # Variables that must have random parameters
        'never_random': [],  # Variables that must never have random parameters
        'latent_class_constraints': {
            'class_specific_vars': {
                'class_0': ['TIME'],  # Variables that appear only in class 0
                'class_1': ['COST'],  # Variables that appear only in class 1
            }
        },
        'mixed_model_constraints': {
            # Additional mixed model specific constraints
        }
    })
    print("""
           ADDICTY DICT FUNCTION
           ---------------------
           Defines pre-specified constraints used in this package.

           Returns:
               Dict with keys:
                   ps_nest_vars: variables always included in nests
                   ps_alt_vars: alternative optional variables
                   force_include -> variables that must always be included
                   force_exclude -> variables that must never be included
                   force_random -> dict of variables that must have random parameters with distributions
                   never_random -> variables that must never have random parameters
                   latent_class_constraints -> constraints for latent class models
                   mixed_model_constraints -> constraints for mixed models

           Example usage:
               from yourpackage import new_features
               constraints = new_features()
               print(constraints.force_include)
           """)

def get_version_from_pkg_info():
    """Reads the installed package version via importlib.metadata."""
    try:
        from importlib.metadata import version as _pkg_version
        return _pkg_version("SearchLibrium")
    except Exception:
        pass
    # Fallback: read from egg-info PKG-INFO (editable installs)
    pkg_info_path = os.path.join(os.path.dirname(__file__), "../SearchLibrium.egg-info/PKG-INFO")
    try:
        with open(pkg_info_path, "r") as f:
            for line in f:
                if line.startswith("Version:"):
                    return line.split(":")[1].strip()
    except FileNotFoundError:
        pass
    return "unknown"

__version__ = get_version_from_pkg_info()

def print_version():
    """Print the current version of the package."""
    print(f"Current version: {__version__}")

try:
    from . import _device as dev
except Exception:
    try:
        import _device as dev
    except Exception:
        dev = None

def _import_relative(module_name, names, fallback_globals=None):
    """Try relative import first, then bare import as fallback."""
    try:
        mod = __import__(f'.{module_name}', fromlist=names, package=__name__)
        return {name: getattr(mod, name) for name in names}
    except Exception:
        try:
            mod = __import__(module_name, fromlist=names)
            return {name: getattr(mod, name) for name in names}
        except Exception:
            return None

_core_imports = _import_relative('_choice_model', ['DiscreteChoiceModel'])
if _core_imports:
    DiscreteChoiceModel = _core_imports['DiscreteChoiceModel']

try:
    from .multinomial_logit import MultinomialLogit
    from .logistic_regression import LogisticRegression
    from .MixedLogit import MixedLogit
    from .coupled_solver import CoupledMXLMinimiser, make_coupled_minimiser
    from .multinomial_nested import NestedLogit, MultiLayerNestedLogit
    from .mixed_nested import MixedNested
    from .Halton import Halton
    from .rrm import RandomRegret
    from .mixedrrm import MixedRandomRegret
    from .ordered_logit import OrderedLogit, OrderedLogitLong, ExplodedLogit, MixedExplodedLogit
    from .selection_models import BinaryProbit, HeckmanTwoStep
    from .zero_inflated_ordered_probit import ZeroInflatedOrderedProbit, ZeroInflatedProbit
    from .latent_class import LatentClassMixedLogit
    from .latent_spec import (vip_table, near_unidentified_report,
                              align_classes, propose_class_params_spec)
    from .mdcev import MDCEVFitResult, MDCEVModel
    from .multinomial_probit import MultinomialProbit
    from .MixedLogitGSE import MixedLogitGSE
    from .RandomP import RandomParameters
    from .constraints_builder import ConstraintBuilder, create_constraints
    from .search import Parameters
    from .sapbil import SAPBIL, ProbabilityMatrix
    from .hspbil import HSPBIL
    from .sparseea_agds import SparseEAAGDS
    from .call_meta import call_harmony, call_harmony_pbil, call_siman, call_parsa, call_search, call_sapbil, call_banditsa, call_parcopsa, call_agds, estimate_ctrl
    from .predict import DestinationPredictor, predict_destination_components, predict_aggregate_destination_flows
    from .sample_data import load_electricity_data, load_travel_mode_data, load_swiss_metro_data, preview_datasets
    from .regularization import elasticnet_objective, elasticnet_penalty_and_grad, nl_identification_priors
    from .jax_utils import ensure_jax_environment, is_large_model, estimate_row_guard, check_gradient_health
    from .larch_compat import apply_larch_patches
    from .larch_models import LarchMNL, LarchNestedLogit, LarchMixedLogit
    from .skims import omx_to_dataframe, read_omx_skims, prepare_skims_from_omx, merge_skim_component
    from .destination_distances import (
        haversine_km, pick_skim_matrices, load_skim_matrices,
        build_case_alt_distances, summarize_distance_sources,
    )
    from .accessibility import gravity_accessibility, compute_accessibility, logsum_accessibility
    from .abm import available_stages, stage_search_config
    from .mh_choice_estimator import (
        ChoiceEstimate, ChoiceEstimateResult, ChoiceSetFrame,
        GaussianRandomWalkProposal,
        BlockRandomWalkProposal, HHTSCompetingPrior,
        chain_diagnostics, effective_sample_size, split_rhat, r_hat,
        estimate_dest_choice, estimate_stage_choice,
    )
except Exception:
    try:
        from multinomial_logit import MultinomialLogit
        from logistic_regression import LogisticRegression
        from MixedLogit import MixedLogit
        from coupled_solver import CoupledMXLMinimiser, make_coupled_minimiser
        from multinomial_nested import NestedLogit, MultiLayerNestedLogit
        from mixed_nested import MixedNested
        from Halton import Halton
        from rrm import RandomRegret
        from mixedrrm import MixedRandomRegret
        from ordered_logit import OrderedLogit, OrderedLogitLong, ExplodedLogit
        from selection_models import BinaryProbit, HeckmanTwoStep
        from zero_inflated_ordered_probit import ZeroInflatedOrderedProbit, ZeroInflatedProbit
        from latent_class import LatentClassMixedLogit
        from latent_spec import (vip_table, near_unidentified_report,
                                 align_classes, propose_class_params_spec)
        from mdcev import MDCEVFitResult, MDCEVModel
        from multinomial_probit import MultinomialProbit
        from MixedLogitGSE import MixedLogitGSE
        from RandomP import RandomParameters
        from constraints_builder import ConstraintBuilder, create_constraints
        from search import Parameters
        from sapbil import SAPBIL, ProbabilityMatrix
        from hspbil import HSPBIL
        from sparseea_agds import SparseEAAGDS
        from call_meta import call_siman, call_harmony, call_harmony_pbil, call_search, call_sapbil, call_banditsa, call_parsa, call_parcopsa, call_agds, estimate_ctrl
        from predict import DestinationPredictor, predict_destination_components, predict_aggregate_destination_flows
        from sample_data import load_electricity_data, load_travel_mode_data, load_swiss_metro_data, preview_datasets
        from regularization import elasticnet_objective, elasticnet_penalty_and_grad, nl_identification_priors
        from jax_utils import ensure_jax_environment, is_large_model, estimate_row_guard, check_gradient_health
        from larch_compat import apply_larch_patches
        from larch_models import LarchMNL, LarchNestedLogit, LarchMixedLogit
        from skims import omx_to_dataframe, read_omx_skims, prepare_skims_from_omx, merge_skim_component
        from destination_distances import (
            haversine_km, pick_skim_matrices, load_skim_matrices,
            build_case_alt_distances, summarize_distance_sources,
        )
        from accessibility import gravity_accessibility, compute_accessibility, logsum_accessibility
        from abm import available_stages, stage_search_config
        from mh_choice_estimator import (
            ChoiceEstimate, ChoiceEstimateResult, ChoiceSetFrame,
            GaussianRandomWalkProposal,
            BlockRandomWalkProposal, HHTSCompetingPrior,
            chain_diagnostics, effective_sample_size, split_rhat, r_hat,
            estimate_dest_choice, estimate_stage_choice,
        )
    except Exception as e:
        warnings.warn(f"SearchLibrium: some modules failed to import: {e}")

try:
    from .main import print_ascii_art_logo
except Exception:
    print_ascii_art_logo = None


__all__ = [
    "__version__", "print_version", "new_features",
    "DiscreteChoiceModel",
    "MultinomialLogit", "LogisticRegression", "MixedLogit",
    "CoupledMXLMinimiser", "make_coupled_minimiser",
    "NestedLogit", "MultiLayerNestedLogit", "MixedNested", "Halton",
    "RandomRegret", "MixedRandomRegret", "OrderedLogit", "OrderedLogitLong", "ExplodedLogit", "MixedExplodedLogit",
    "BinaryProbit", "HeckmanTwoStep",
    "ZeroInflatedOrderedProbit", "ZeroInflatedProbit",
    "LatentClassMixedLogit", "vip_table", "near_unidentified_report",
    "align_classes", "propose_class_params_spec", "MDCEVFitResult", "MDCEVModel", "MultinomialProbit",
    "MixedLogitGSE", "RandomParameters", "ConstraintBuilder", "create_constraints",
    "Parameters", "misc",
    "ChoiceEstimate", "ChoiceEstimateResult", "ChoiceSetFrame",
    "GaussianRandomWalkProposal",
    "BlockRandomWalkProposal", "HHTSCompetingPrior",
    "chain_diagnostics", "effective_sample_size", "split_rhat", "r_hat",
    "estimate_dest_choice", "estimate_stage_choice",
    "SAPBIL", "ProbabilityMatrix", "HSPBIL", "SparseEAAGDS", "BanditSA", "PerturbationBandit",
    "call_search", "call_siman", "call_harmony", "call_harmony_pbil", "call_sapbil",
    "call_banditsa", "call_parsa", "call_parcopsa", "call_agds", "estimate_ctrl",
    "DestinationPredictor", "predict_destination_components", "predict_aggregate_destination_flows",
    "load_electricity_data", "load_travel_mode_data", "load_swiss_metro_data", "preview_datasets",
    "elasticnet_objective", "elasticnet_penalty_and_grad", "nl_identification_priors",
    "ensure_jax_environment", "is_large_model", "estimate_row_guard", "check_gradient_health",
    "apply_larch_patches", "LarchMNL", "LarchNestedLogit", "LarchMixedLogit",
    "omx_to_dataframe", "read_omx_skims", "prepare_skims_from_omx", "merge_skim_component",
    "haversine_km", "pick_skim_matrices", "load_skim_matrices",
    "build_case_alt_distances", "summarize_distance_sources",
    "gravity_accessibility", "compute_accessibility", "logsum_accessibility",
    "available_stages", "stage_search_config",
]







