"""
SparseEA-AGDS search algorithm for SearchLibrium.

Implements the *Evolution algorithm with Adaptive Genetic operator and Dynamic
Scoring mechanism* of Wang et al. (Scientific Reports, 2025, "Evolution
algorithm with adaptive genetic operator and dynamic scoring mechanism for
large-scale sparse many-objective optimization").

SparseEA represents an individual as ``X = dec x mask``: a real vector ``dec``
and a binary ``mask`` controlling sparsity.  Mapped onto the choice-model
specification search this becomes:

    mask_d  ->  whether candidate variable ``d`` (``param.asvarnames``) is in
                the specification.
    dec_d   ->  the distribution / transform / correlation choice that variable
                carries once selected.

Three stackable strategies from the paper are implemented on top of the shared
``Search`` base class:

    (A) Adaptive genetic operator - per-individual crossover / mutation
        probabilities scale with the non-dominated rank
        ``P_s,i = (maxr - r_i + 1)/maxr`` (Eq. 5), ``P_c,i = pc0 * P_s,i``
        (Eq. 6), ``P_m,i = pm0 * P_s,i`` (Eq. 7).
    (B) Dynamic scoring mechanism - each generation the decision-variable score
        is recomputed from the current layers: ``S_i_r = maxr - r_i + 1``
        (Eq. 8), ``sumS_d = sum_i S_i_r * mask_{i,d}`` (Eq. 9),
        ``S_d = maxS - sumS_d + 1`` (Eq. 10); a binary tournament on ``S_d``
        chooses which mask bit to flip (Figs. 3-4).
    (C) Reference-point-based environmental selection (NSGA-III niching) keeps
        selection pressure under many objectives (``param.nb_crit > 1``); the
        single-objective case degenerates to best-N-by-first-objective.

The class mirrors ``HarmonySearch`` / ``SA``: construct with a ``Parameters``
object and call ``run()`` (which dispatches to ``run_search``).
"""

import copy
import datetime
import gc as _gc
import logging
import os

import numpy as np

try:
    from .search import *          # Search, Solution, get_unique, BOUND, ...
except ImportError:                # running as a top-level module
    from search import *

logger = logging.getLogger(__name__)

# ``spec_key`` / ``get_unique_spec`` (de-duplicate a population by model
# SPECIFICATION rather than by objective value) now live in search.py so every
# algorithm shares them. The originals were defined here; _agds_spec_key is kept
# as an alias for backwards compatibility.
_agds_spec_key = spec_key


# ---------------------------------------------------------------------- #
#  Memory reclamation                                                      #
# ---------------------------------------------------------------------- #
# A long AGDS run re-fits one model per evaluated individual - tens of
# thousands over a 500-generation search.  Each fit materialises a full
# case x alternative design frame (and, under a JAX backend, a freshly
# compiled executable), so the transient peak per fit is orders of magnitude
# larger than the live population.  Those objects *are* released, but glibc
# retains the freed spans in its arenas, so RSS ratchets steadily upward and a
# process holding only a few hundred MB of live data still walks into a
# cgroup memory limit and gets OOM-killed.
#
# Calling collect() + malloc_trim() once per generation returns those spans to
# the OS so RSS tracks the live set instead of the high-water mark.  Every
# CLEAR_JAX_EVERY generations (and every force=True release) the JAX
# compilation cache is dropped as well: one executable per distinct spec is
# retained there beyond the reach of gc/malloc_trim (+24.3 MB/fit measured
# Oct-2026 on a 1016-trip x 233-destination larch workload, identical across
# three runs, OOM-killing two 128 GB jobs in the refit that follows the
# search).  Recompile cost is bounded: only re-visited specs recompile, and
# an evolutionary search rarely revisits.
#
#   SEARCHLIBRIUM_RECLAIM_EVERY=<n>  reclaim every <n> generations (default 1)
#   SEARCHLIBRIUM_RECLAIM=0          disable entirely
#   SEARCHLIBRIUM_CLEAR_JAX=1        also drop JAX's cache on EVERY call
#   SEARCHLIBRIUM_CLEAR_JAX_EVERY=<n>
#                                    ... otherwise drop it every <n>
#                                    generations (default 5) and on every
#                                    force=True release

def _env_int(name, default):
    try:
        return int(str(os.environ.get(name, "")).strip())
    except (TypeError, ValueError):
        return default


RECLAIM_EVERY = max(1, _env_int("SEARCHLIBRIUM_RECLAIM_EVERY", 1))
RECLAIM_ENABLED = str(os.environ.get("SEARCHLIBRIUM_RECLAIM", "1")).strip().lower() \
    not in {"0", "false", "no", "off"}
CLEAR_JAX = str(os.environ.get("SEARCHLIBRIUM_CLEAR_JAX", "0")).strip().lower() \
    in {"1", "true", "yes", "on"}
CLEAR_JAX_EVERY = max(1, _env_int("SEARCHLIBRIUM_CLEAR_JAX_EVERY", 5))


def _malloc_trim():
    """Return free glibc heap arenas to the OS.  No-op on non-glibc platforms."""
    try:
        import ctypes
        libc = ctypes.CDLL("libc.so.6")
        malloc_trim = libc.malloc_trim
        malloc_trim.argtypes = [ctypes.c_size_t]
        malloc_trim.restype = ctypes.c_int
        malloc_trim(0)
    except Exception:
        pass


def reclaim_memory(force=False, clear_jax=False):
    """Collect search-local garbage and hand freed heap back to the OS.

    ``force=True`` releases (one-off phase transitions) always also drop
    JAX's compiled-executable cache; in-loop callers pass ``clear_jax=True``
    every ``CLEAR_JAX_EVERY`` generations; ``SEARCHLIBRIUM_CLEAR_JAX=1``
    clears on every call.
    """
    if not (force or RECLAIM_ENABLED):
        return
    _gc.collect()
    if clear_jax or force or CLEAR_JAX:
        try:
            import jax
            jax.clear_caches()
        except Exception:
            pass
    _malloc_trim()


# ---------------------------------------------------------------------- #
#  NSGA-III reference-point helpers (numpy, self-contained)               #
# ---------------------------------------------------------------------- #
def reference_points(n_obj, divisions):
    """Das-Dennis structured reference points on the (n_obj-1)-simplex."""
    def _recurse(left, depth):
        if depth == n_obj - 1:
            return [[left]]
        pts = []
        for i in range(left + 1):
            for tail in _recurse(left - i, depth + 1):
                pts.append([i] + tail)
        return pts
    if n_obj == 1:
        return np.array([[1.0]])
    raw = _recurse(divisions, 0)
    return np.array(raw, dtype=float) / float(divisions)


def associate(points, ref):
    """Associate each point with the nearest reference line (index into ref)."""
    if len(points) == 0:
        return np.array([], dtype=int)
    ref_norm = ref / (np.linalg.norm(ref, axis=1, keepdims=True) + 1e-12)
    out = np.empty(len(points), dtype=int)
    for i, p in enumerate(points):
        proj = points[i] @ ref_norm.T
        perp = np.linalg.norm(p[None, :] - proj[:, None] * ref_norm, axis=1)
        out[i] = int(np.argmin(perp))
    return out


def perp_distance(points, ref, assoc):
    """Perpendicular distance of each point to its associated reference line."""
    d = np.empty(len(points))
    for i, p in enumerate(points):
        w = ref[assoc[i]]
        wn = w / (np.linalg.norm(w) + 1e-12)
        proj = np.dot(p, wn) * wn
        d[i] = np.linalg.norm(p - proj)
    return d


class SparseEAAGDS(Search):
    """SparseEA-AGDS evolutionary search (see module docstring)."""

    # ------------------------------------------------------------------ #
    #  construction                                                       #
    # ------------------------------------------------------------------ #
    def set_control_parameters(self, pop_size=20, maxiter=30, pc0=0.9,
                               pm0=None, ref_divisions=12, generate_plots=False):
        self.pop_size = int(pop_size)
        self.maxiter = int(maxiter)
        self.pc0 = float(pc0)
        D = max(len(getattr(self.param, 'asvarnames', []) or []), 1)
        self.pm0 = float(pm0) if pm0 is not None else 1.0 / D
        self.ref_divisions = int(ref_divisions)
        self.generate_plots = generate_plots

    def __init__(self, param, ctrl=None, idnum=None, **kwargs):
        super().__init__(param, **kwargs)
        self.idnum = idnum or 'AGDS'

        if ctrl is not None:
            pop_size, maxiter, pc0, pm0 = (tuple(ctrl) + (20, 30, 0.9, None))[:4]
            self.set_control_parameters(pop_size=int(pop_size), maxiter=int(maxiter),
                                        pc0=float(pc0), pm0=pm0)
        else:
            self.set_control_parameters()

        # Respect control kwargs (generate_plots, ref_divisions, ...) passed
        # by call_meta / call_search instead of silently dropping them.
        _known = {'pop_size', 'maxiter', 'pc0', 'pm0',
                  'ref_divisions', 'generate_plots'}
        _fwd = {k: v for k, v in kwargs.items() if k in _known}
        if _fwd:
            try:
                self.set_control_parameters(**_fwd)
            except TypeError:
                pass

        self.memory = []
        self.best_sol = None
        self.start = None

    # ------------------------------------------------------------------ #
    #  dec x mask helpers                                                 #
    # ------------------------------------------------------------------ #
    def _candidate_vars(self):
        return list(getattr(self.param, 'asvarnames', []) or [])

    @staticmethod
    def _active_vars(sol):
        """The mask: the set of candidate variables present in the solution."""
        return set(sol.get('asvars', []) or [])

    def _sort_mem(self, mem):
        if self.nb_crit > 1:
            return self.non_dominant_sorting(mem)
        return sorted(mem, key=lambda s: s.obj(0))

    # ------------------------------------------------------------------ #
    #  non-dominated ranking (r_i, maxr)  -- Eq. 5 / Eq. 8               #
    # ------------------------------------------------------------------ #
    def _compute_ranks(self, mem):
        n = len(mem)
        if n == 0:
            return [], 1
        if self.nb_crit > 1:
            try:
                fronts = self.get_fronts(mem)
                ranks = [1] * n
                for layer, idxs in enumerate(fronts.values(), start=1):
                    for idx in idxs:
                        ranks[idx] = layer
                return ranks, max(ranks)
            except Exception:
                pass
        order = sorted(range(n), key=lambda i: mem[i].obj(0))
        ranks = [1] * n
        layer, prev = 1, None
        for i in order:
            val = mem[i].obj(0)
            if prev is not None and val > prev:
                layer += 1
            ranks[i] = layer
            prev = val
        return ranks, max(ranks)

    # ------------------------------------------------------------------ #
    #  (B) dynamic decision-variable score  -- Eqs. 8-10                 #
    # ------------------------------------------------------------------ #
    def _dynamic_scores(self, mem, ranks, maxr):
        cand = self._candidate_vars()
        si_r = [maxr - r + 1 for r in ranks]                   # Eq. 8
        sumS = {v: 0.0 for v in cand}
        for i, sol in enumerate(mem):
            active = self._active_vars(sol)
            for v in cand:
                if v in active:
                    sumS[v] += si_r[i]                          # Eq. 9
        maxS = max(sumS.values()) if sumS else 0.0
        return {v: maxS - sumS[v] + 1 for v in cand}           # Eq. 10 (lower = better)

    def _tournament_var(self, scores, candidates):
        """Binary tournament on the dynamic score - smaller S_d wins."""
        if not candidates:
            return None
        a = self.random_choice(candidates)
        b = self.random_choice(candidates)
        return a if scores.get(a, 0.0) <= scores.get(b, 0.0) else b

    # ------------------------------------------------------------------ #
    #  (A) adaptive genetic operator + (B) mask operator -> offspring    #
    # ------------------------------------------------------------------ #
    def _make_offspring(self, parent, partner, ps_i, scores):
        pc_i = self.pc0 * ps_i                                 # Eq. 6
        pm_i = self.pm0 * ps_i                                 # Eq. 7
        child = copy.deepcopy(parent)

        # ---- dec crossover: adopt some of the partner's variable draws -----
        if self.param.generator.rand() < pc_i:
            shared = self._active_vars(child) & self._active_vars(partner)
            p_rand = partner.get('randvars', {}) or {}
            c_rand = child.get('randvars', {}) or {}
            for v in shared:
                if v in p_rand and self.param.generator.rand() < 0.5:
                    c_rand[v] = p_rand[v]
            child['randvars'] = {k: val for k, val in c_rand.items()
                                 if k in self._active_vars(child)}

        # ---- dec mutation: redraw one variable's distribution --------------
        if self.param.generator.rand() < max(pm_i, self.pm0):
            rands = list((child.get('randvars', {}) or {}).keys())
            if rands and getattr(self.param, 'distr', None):
                v = self.random_choice(rands)
                child['randvars'][v] = self.param.generator.choice(self.param.distr)

        # ---- (B) mask crossover: adopt a differing variable from partner ---
        cand = self._candidate_vars()
        differing = [v for v in cand
                     if (v in self._active_vars(child)) != (v in self._active_vars(partner))]
        if differing and self.param.generator.rand() < pc_i:
            v = self._tournament_var(scores, differing)
            if v is not None:
                if v in self._active_vars(partner):
                    child = self.add_asvar(v, child)
                else:
                    child = self.remove_asvar(v, child)

        # ---- (B) mask mutation: invert a tournament-chosen dimension -------
        if cand and self.param.generator.rand() < max(pm_i, self.pm0):
            v = self._tournament_var(scores, cand)
            if v is not None:
                if v in self._active_vars(child):
                    child = self.remove_asvar(v, child)
                else:
                    child = self.add_asvar(v, child)

        child = self.repair_solution(child)
        return child

    def _reproduce(self, mem):
        ranks, maxr = self._compute_ranks(mem)
        scores = self._dynamic_scores(mem, ranks, maxr)
        n = len(mem)
        children = []
        for i in range(n):
            ps_i = (maxr - ranks[i] + 1) / maxr                # Eq. 5
            j = int(self.param.generator.choice(n)) if n > 1 else 0
            while j == i and n > 1:
                j = int(self.param.generator.choice(n))
            child = self._make_offspring(mem[i], mem[j], ps_i, scores)
            child, converged = self.evaluate_solution(child)
            children.append(child if converged else mem[i])
        return children

    # ------------------------------------------------------------------ #
    #  (C) reference-point-based environmental selection (NSGA-III)       #
    # ------------------------------------------------------------------ #
    def _obj_vector(self, sol):
        return [float(sol.obj(k)) for k in range(self.nb_crit)]

    def _environmental_selection(self, combined, n_select):
        # De-duplicate by *specification*: the old get_unique(combined, 0)
        # collapsed everything sharing an obj(0) value (nsig integers),
        # destroying population diversity every generation.
        combined = get_unique_spec(combined, 0)
        if len(combined) <= n_select:
            return combined
        if self.nb_crit <= 1:
            return sorted(combined, key=lambda s: s.obj(0))[:n_select]

        fronts = self.get_fronts(combined)
        selected, critical = [], None
        for idxs in fronts.values():
            if len(selected) + len(idxs) <= n_select:
                selected.extend(idxs)
            else:
                critical = idxs
                break
        if len(selected) >= n_select or critical is None:
            return [combined[i] for i in selected[:n_select]]

        F = np.array([self._obj_vector(combined[i]) for i in range(len(combined))],
                     dtype=float)
        M = F.shape[1]
        ideal = F.min(axis=0)
        Fn = F - ideal
        nadir = Fn.max(axis=0)
        nadir[nadir == 0] = 1.0
        Fn = Fn / nadir

        ref = reference_points(M, self.ref_divisions)
        sel_assoc = associate(Fn[selected], ref) if selected else np.array([], dtype=int)
        niche = np.zeros(len(ref), dtype=int)
        for a in sel_assoc:
            niche[a] += 1
        crit_assoc = associate(Fn[critical], ref)
        crit_dist = perp_distance(Fn[critical], ref, crit_assoc)

        chosen = list(selected)
        available = list(range(len(critical)))
        while len(chosen) < n_select and available:
            rmin = None
            for k in set(crit_assoc[c] for c in available):
                if rmin is None or niche[k] < niche[rmin]:
                    rmin = k
            members = [c for c in available if crit_assoc[c] == rmin]
            if niche[rmin] == 0:
                pick = min(members, key=lambda c: crit_dist[c])
            else:
                pick = int(self.random_choice(members))
            chosen.append(critical[pick])
            niche[rmin] += 1
            available.remove(pick)
        return [combined[i] for i in chosen[:n_select]]

    # ------------------------------------------------------------------ #
    #  initial population                                                 #
    # ------------------------------------------------------------------ #
    def _initialize(self, existing_sols=None):
        mem = []
        if existing_sols:
            for sol in existing_sols:
                sol, converged = self.evaluate_solution(sol)
                if converged:
                    mem.append(sol)
        attempts = 0
        while len(mem) < self.pop_size and attempts < 30000:
            attempts += 1
            sol = self.generate_solution()
            sol, converged = self.evaluate_solution(sol)
            if converged and abs(sol.obj(0)) < BOUND:
                mem.append(sol)
            # De-duplicate by *specification*, not obj(0): nsig takes only a
            # handful of integer values, so get_unique(mem, 0) caps the
            # initial population at ~distinct-nsig members and _initialize
            # spins through all 30000 attempts without filling pop_size.
            mem = get_unique_spec(mem, 0)
        if not mem:
            raise RuntimeError(
                "AGDS initial population is empty: none of the candidate "
                "specifications converged. Check Parameters (n_draws/maxiter), "
                "model setup, and run with verbose_convergence=True to print "
                "per-fit failures.")
        return self._sort_mem(mem)[:self.pop_size]

    # ------------------------------------------------------------------ #
    #  main entry point                                                   #
    # ------------------------------------------------------------------ #
    def run_search(self, existing_sols=None):
        import os, time as _time
        self.start = datetime.datetime.now()

        # Open progress CSV
        crit_names = [c[0] for c in self.param.criterions[:self.nb_crit]]
        try:
            run_id = self.idnum or 'agds'
            ts = _time.strftime("%Y%m%d_%H%M%S")
            pf = open(f"agds_{run_id}_{ts}_progress.csv", "w")
        except Exception:
            pf = open("agds_progress.csv", "w")
        print("iteration," + ",".join(crit_names), file=pf)
        pf.flush()

        memory = self._initialize(existing_sols)
        for sol in memory:
            sol.data['is_initial_sol'] = True

        # Per-model-type convergence history: model_n -> list of (gen, best BIC
        # seen so far for that model type). Used to overlay one convergence line
        # per model type (e.g. multinomial / random_regret / mixed_random_regret).
        # NOTE: display only — the search itself still ranks/updates on obj(0).
        _lower = [str(c).lower() for c in crit_names]
        _plot_idx = _lower.index('bic') if 'bic' in _lower else 0
        model_hist = {}
        model_best = {}

        def _record_model_history(gen, mem):
            for sol in mem:
                try:
                    mn = sol.get('model_n', '') or 'unknown'
                    if isinstance(mn, (list, tuple)):
                        mn = mn[0] if mn else 'unknown'
                    mn = str(mn)
                    v = float(sol.obj(_plot_idx))
                except Exception:
                    continue
                if mn not in model_best or v < model_best[mn]:
                    model_best[mn] = v
            for mn, v in model_best.items():
                model_hist.setdefault(mn, []).append((gen, v))

        try:
            for gen in range(self.maxiter):
                children = self._reproduce(memory)
                memory = self._environmental_selection(memory + children, self.pop_size)
                best = self._sort_mem(memory)[0]
                if self.best_sol is None or best.obj(0) < self.best_sol.obj(0):
                    self.best_sol = best
                logger.info("[AGDS] gen {}: best obj0 = {:.6g}".format(gen, best.obj(0)))
                _record_model_history(gen, memory)

                # Log per-generation best values
                try:
                    _best = {}
                    for sol in memory:
                        for ci, cn in enumerate(crit_names):
                            try:
                                v = float(sol.obj(ci))
                            except Exception:
                                v = float('inf')
                            if cn not in _best or abs(v) < abs(_best[cn]):
                                _best[cn] = v
                    _vals = ','.join(str(_best.get(cn, '')) for cn in crit_names)
                    print(f"{gen},{_vals}", file=pf)
                    pf.flush()
                except Exception:
                    pass

                # Return the per-generation fit garbage to the OS.  Without
                # this RSS follows the high-water mark of the transient fit
                # buffers and a long search is OOM-killed despite a small live
                # set.  Every CLEAR_JAX_EVERY generations also drop JAX's
                # global compilation cache (see reclaim_memory).
                if (gen + 1) % RECLAIM_EVERY == 0:
                    reclaim_memory(
                        clear_jax=((gen + 1) % (RECLAIM_EVERY * CLEAR_JAX_EVERY) == 0))
        finally:
            pf.close()

        self.memory = self._sort_mem(memory)
        logger.info("[AGDS] search complete; best obj0 = {:.6g}"
                    .format(self.memory[0].obj(0)))

        # Generate convergence plot: one line per model type explored, showing
        # the best BIC seen so far for that model at each generation
        # ("convergence history across models"). Display only; the optimizer
        # still compares on obj(0).
        if self.generate_plots:
            try:
                import matplotlib
                matplotlib.use('Agg')
                import matplotlib.pyplot as plt
                obj_label = crit_names[_plot_idx] if crit_names else 'Objective Value'
                # Persist the per-model history as a CSV alongside the plot.
                try:
                    base = os.path.splitext(pf.name)[0]
                    csv_path = base + "_by_model.csv"
                except Exception:
                    base, csv_path = "convergence_agds", "convergence_agds_by_model.csv"
                if model_hist:
                    try:
                        with open(csv_path, "w") as mf:
                            mf.write("model_n,generation," + str(obj_label) + "\n")
                            for mn in sorted(model_hist):
                                for g, v in model_hist[mn]:
                                    mf.write(f"{mn},{g},{v}\n")
                    except Exception as _csv_exc:
                        logger.warning(f"by-model CSV failed: {_csv_exc}")

                    fig, ax = plt.subplots(figsize=(10, 6))
                    for mn in sorted(model_hist):
                        pts = model_hist[mn]
                        if pts:
                            xs, ys = zip(*pts)
                            ax.plot(xs, ys, label=mn, linewidth=1.5, marker='.',
                                    markersize=4)
                    ax.set_xlabel('Generation')
                    ax.set_ylabel(f'Best {obj_label} so far')
                    ax.legend(title='Model type')
                    ax.grid(True, alpha=0.3)
                    fig.savefig("convergence_agds.png", dpi=150, bbox_inches='tight')
                    plt.close(fig)
                    logger.info("[AGDS] convergence plot saved: convergence_agds.png "
                                "(%d model types)", len(model_hist))
                else:
                    logger.warning("[AGDS] no per-model history recorded; "
                                   "skipping convergence plot")
            except Exception as exc:
                logger.warning(f"Convergence plot failed: {exc}")

        return self.memory

    # ------------------------------------------------------------------ #
    #  interface parity with HarmonySearch / SA (used by call_meta)       #
    # ------------------------------------------------------------------ #
    def return_best(self):
        """Return the best solution found (mirrors HarmonySearch.return_best)."""
        if self.best_sol is not None:
            return self.best_sol
        if self.memory:
            return self._sort_mem(self.memory)[0]
        return None

    def close_files(self):
        """No log files are opened by AGDS; provided for call_meta parity."""
        return None
